update cards set identifier = '007681729' where id = 1832827;
update cardholders set identifier = '007681729' where id = 1438655;

update cards set
number_truncated = '522157******0023',
updated_at = now(),
card_id = '5367316',
origin_card_id = '4988520'
where id = 1898441;









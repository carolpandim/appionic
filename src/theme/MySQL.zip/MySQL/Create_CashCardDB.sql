CREATE DATABASE `cashcard` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;

CREATE TABLE `arquivo` (
  `idarquivo` varchar(50) NOT NULL,
  `nomearquivo` varchar(255) DEFAULT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `dataarquivo` datetime DEFAULT NULL,
  `linhas` int(11) DEFAULT NULL,
  `import` tinyint(4) DEFAULT NULL,
  `dataimport` datetime DEFAULT NULL,
  `recharge` tinyint(4) DEFAULT NULL,
  `datarecharge` datetime DEFAULT NULL,
  `export` tinyint(4) DEFAULT NULL,
  `dataexport` datetime DEFAULT NULL,
  `email` tinyint(4) DEFAULT NULL,
  `dataemail` datetime DEFAULT NULL,
  PRIMARY KEY (`idarquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `arquivoitem` (
  `idarquivoitem` varchar(50) NOT NULL,
  `idarquivo` varchar(50) DEFAULT NULL,
  `descricaoprocessamento` varchar(1000) DEFAULT NULL,
  `recharge` tinyint(4) DEFAULT NULL,
  `idaccount` bigint(20) DEFAULT NULL,
  `cardid` varchar(255) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `vlrecarga` decimal(18,2) DEFAULT NULL,
  `identificador` varchar(255) DEFAULT NULL,
  `limite` decimal(18,2) DEFAULT NULL,
  `saldo` decimal(18,2) DEFAULT NULL,
  `codsituacao` int(11) DEFAULT NULL,
  `idaccountparent` bigint(20) DEFAULT NULL,
  `regionid` varchar(255) DEFAULT NULL,
  `companyid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idarquivoitem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




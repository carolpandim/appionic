ALTER TABLE `arquivo` 
CHANGE COLUMN `responseorder` `responseorder` LONGTEXT NULL DEFAULT NULL ;

ALTER TABLE `arquivo` 
ADD COLUMN `orderid` INT(11) NULL DEFAULT NULL AFTER `datarecharge`;
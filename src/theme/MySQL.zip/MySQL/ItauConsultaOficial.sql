select * 
from cards as c inner join cardholders as ch on c.cardholder_id = ch.id
where c.account_id in (
select id 
from accounts as a 
where a.company_id = 1142 and a.product_id = 30
) 
and c.number_truncated is not null and c.deleted_at is null
and date(c.created_at) < '2018-06-01'
and c.identifier not like '%REEMITIDO%'
and c.identifier not like '%CANCELADO%'
and c.identifier in (
'007681729'
);
/*and c.identifier like '%7681729';*/

/*JULIANA E M GARCIA*/
select * from cards where id = 1832827;
select * from cardholders where id = 1438655;


select c.* 
from cards as c inner join cardholders as ch on c.cardholder_id = ch.id
where c.identifier like '%987297982'

/*https://accounts-api.hubcard.com.br/accounts/{hubcard_account_id}/cards */
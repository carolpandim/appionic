select * from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
where a.idarquivo = (select idarquivo from arquivo order by dataarquivo desc limit 1);

select * from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
where a.idarquivo = (select idarquivo from arquivo order by dataarquivo desc limit 1) and ai.recharge=0;

select sum(ai.vlrecarga) as total from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
where a.idarquivo in ('c037e690-825a-4949-ae61-bb14f8ae9cbc') and ai.recharge = 0;

select * from arquivo a where a.idarquivo = 'e545d3f3-0569-40b1-984c-09d63e4fc1bd';

select * from log where date >=now() - interval 1 hour order by date asc;

select * from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
where idcliente = 1 order by dataarquivo desc


/*
dac9f867-f5e8-4d65-9208-1e89b27f299d - 6183.19
e545d3f3-0569-40b1-984c-09d63e4fc1bd - 273.84

delete from arquivoitem where idarquivo ='cabe01ab-6878-4a21-8725-ef09c90cf3ef';
delete from arquivo where idarquivo ='cabe01ab-6878-4a21-8725-ef09c90cf3ef'; 

update arquivoitem set recharge = 0 where idarquivoitem = '60cfbca8-4862-4423-9e56-68e3342259c6';
*/

select 
a.idarquivo as `Id Arquivo`,
a.nomearquivo as `Nome Arquivo`,
a.dataarquivo as `Data do Arquivo`,
ai.identificador as `Identificador`,
ai.cardid as `Card Id`,
ai.cpf as `CPF`,
ai.idaccount as `Account Id`,
ai.idaccountparent as `Account Id Matriz`,
ai.limite as `Limite`,
ai.saldo as `Saldo`,
ai.vlrecarga as `Recarga`,
ai.recharge as `Status Recarga`,
ai.descricaoprocessamento as `Descrição`
from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
where a.idarquivo = 'c037e690-825a-4949-ae61-bb14f8ae9cbc' 
order by dataarquivo desc

ai.vlrecarga as `Valor da Recarga`
SUBSTRING(a.responseorder, 12, 7) as `Id do Pedido`,
a.order as `Status Pedido`,
a.dataorder as `Data do Pedido`,
a.databoleto as `Data do Boleto`,
a.totalorder as `Total do Pedido`








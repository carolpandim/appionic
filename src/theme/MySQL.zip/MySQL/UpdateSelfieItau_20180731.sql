update cards set identifier='987290268' where id=1193620;
update cards set identifier='987298932' where id=1832826;
update accounts set product_id='31' where id=6171
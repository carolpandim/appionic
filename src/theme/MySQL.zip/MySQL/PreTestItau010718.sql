
select *
from cards c
	inner join accounts a on a.id = c.account_id
	inner join cardholders cc on cc.id = c.cardholder_id
where c.identifier like '%987290268%' and a.company_id = 1142 and a.product_id = 30 and c.card_id is not null and c.deleted_at is null
order by c.card_id desc;


 987298932

in
('007681729'
'987290268',
'987298932'
)


'987295438'
ALTER TABLE `cashcard_production`.`arquivo` 
ADD COLUMN `order` TINYINT(4) NULL DEFAULT NULL AFTER `datarecharge`,
ADD COLUMN `dataorder` DATETIME NULL DEFAULT NULL AFTER `order`,
ADD COLUMN `databoleto` DATETIME NULL DEFAULT NULL AFTER `dataoder`,
ADD COLUMN `responseorder` VARCHAR(6000) NULL DEFAULT NULL AFTER `databoleto`,
ADD COLUMN `totalorder` VARCHAR(45) NULL DEFAULT NULL AFTER `responseorder`;





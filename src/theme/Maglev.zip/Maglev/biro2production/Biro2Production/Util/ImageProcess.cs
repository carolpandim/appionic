﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Biro2Production.Util
{
    public class ImageProcess
    {
        private static ImageProcess oImageProcess;

        public static ImageProcess Instance { get { oImageProcess = oImageProcess ?? new ImageProcess(); return oImageProcess; } }

        public void SaveImage( string filePath, List<string> images, ImageFormat format)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(filePath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }

            Object locked = new object();

            Parallel.ForEach(images, image =>
            {
                lock (locked)
                {
                    try
                    {
                        var imageDownloaded = Util.Imagem.Instance.DownloadImageFromUrl(image);

                        if (imageDownloaded != null)
                        {
                            var imageName = image.Substring(image.LastIndexOf("/") + 1);

                            imageDownloaded.Save(String.Concat(filePath, "\\", imageName));
                        }

                    }
                    catch (Exception ex)
                    {

                    }
                }
            });
                
        }

        public MemoryStream SaveImagexxx(String Path, List<String> images)
        {
            MemoryStream zipStream;

            using (zipStream = new MemoryStream())
            {
                using (ZipArchive zip = new ZipArchive(zipStream))
                {
                    foreach (var imageUrl in images)
                    {
                        var imageName = imageUrl.Substring(imageUrl.LastIndexOf("/") + 1);
                        var image = Util.Imagem.Instance.DownloadImageFromUrl(imageUrl);

                        ZipArchiveEntry entry = zip.CreateEntry(imageName);
                        using (Stream entryStream = entry.Open())
                        {
                            image.Save(entryStream, ImageFormat.Png);
                        }
                    }
                }

                zipStream.Position = 0;
            }

            return zipStream;
        }
    }
}

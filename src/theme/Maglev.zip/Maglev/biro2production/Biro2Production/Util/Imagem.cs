﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Text;

namespace Biro2Production.Util
{
    public class Imagem
    {
        private static Imagem oImagem = null;

        public static Imagem Instance { get { oImagem = oImagem ?? new Imagem(); return oImagem; } }


        public void SaveImage(String imageUrl, string filePath, string fileName, ImageFormat format)
        {
            System.Drawing.Image image = DownloadImageFromUrl(imageUrl.Trim());

            DirectoryInfo dirInfo = new DirectoryInfo(filePath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }


            if (image != null)
                image.Save(String.Concat(filePath, "\\", fileName));
        }

        public System.Drawing.Image DownloadImageFromUrl(string imageUrl)
        {
            System.Drawing.Image image = null;

            try
            {
                System.Net.HttpWebRequest webRequest = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(imageUrl);
                webRequest.AllowWriteStreamBuffering = true;
                webRequest.Timeout = 30000;

                System.Net.WebResponse webResponse = webRequest.GetResponse();

                System.IO.Stream stream = webResponse.GetResponseStream();

                image = System.Drawing.Image.FromStream(stream);

                webResponse.Close();
            }
            catch (Exception ex)
            {
                BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao fazer o download da imagem" , "DownloadImageFromUrl", "Imagem: " + imageUrl);
                return null;
            }

            return image;
        }
    }
}

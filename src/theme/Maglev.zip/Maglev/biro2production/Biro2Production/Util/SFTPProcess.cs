﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;

namespace Biro2Production.Util
{
    public class SFTPProcess
    {
        private static SFTPProcess oSFTPProcess;

        public static SFTPProcess Instance { get { oSFTPProcess = oSFTPProcess ?? new SFTPProcess(); return oSFTPProcess; } }
        

        public SftpClient CreateClient()
        {
            string ftpURL = ConfigurationManager.AppSettings["ftpURL"];
            string ftpUser = ConfigurationManager.AppSettings["ftpUser"];
            string ftpPwd = ConfigurationManager.AppSettings["ftpPwd"];
            int ftpPort = Convert.ToInt32(ConfigurationManager.AppSettings["ftpPort"]);

            KeyboardInteractiveAuthenticationMethod kauth = new KeyboardInteractiveAuthenticationMethod(ftpUser);

            PasswordAuthenticationMethod pauth = new PasswordAuthenticationMethod(ftpUser, ftpPwd);

            kauth.AuthenticationPrompt += new EventHandler<Renci.SshNet.Common.AuthenticationPromptEventArgs>((obj, args) => HandleKeyEvent(obj, args, ftpPwd));

            ConnectionInfo connectionInfo = new ConnectionInfo(ftpURL, ftpPort, ftpUser, pauth, kauth);

            return new SftpClient(connectionInfo);
        }

        public void UploadFiles(String idOs, List<Model.FileInfo> fileInfo, String RemoteDirectory)
        {
         

            using (SftpClient sftp = CreateClient())
            {
                try
                {

                    sftp.Connect();

                    foreach (var file in fileInfo)
                    {
                        string remotePath = RemoteDirectory + "/" + file.name;

                        sftp.UploadFile(file.data, remotePath);
                    }
                }
                catch (Exception ex)
                {
                    BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao subir arquivos no SFTP", "UploadFiles", "OS: " + idOs);
                }
                finally
                {
                    sftp.Disconnect();
                    sftp.Dispose();
                }
            }
        }


        public void UploadDirectory(SftpClient client, string folderPath, string localPath, string remotePath)
        {
            Console.WriteLine("Upload directory {0} to {1}", localPath, remotePath);

            string dirPath = remotePath + "/" + folderPath;

            using (SftpClient sftp = CreateClient())
            {
                try
                {

                    sftp.Connect();
                    if (!sftp.Exists(dirPath))
                    {
                        sftp.CreateDirectory(dirPath);
                    }

                    IEnumerable<FileSystemInfo> infos = new DirectoryInfo(localPath).EnumerateFileSystemInfos();
                    foreach (FileSystemInfo info in infos)
                    {
                        try
                        {
                            using (Stream fileStream = new FileStream(info.FullName, FileMode.Open))
                            {
                                Console.WriteLine("Upload {0} ({1:N0} bytes)", info.FullName, ((FileInfo)info).Length);

                                sftp.UploadFile(fileStream, dirPath + "/" + info.Name);
                            }
                        }
                        catch (Exception ex)
                        {
                            BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao subir o arquivo no SFTP", "UploadDirectory", "Arquivo: " + info.Name);
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }


        public void HandleKeyEvent(Object sender, Renci.SshNet.Common.AuthenticationPromptEventArgs e, string ftpPwd)
        {
            foreach (Renci.SshNet.Common.AuthenticationPrompt prompt in e.Prompts)
            {
                if (prompt.Request.IndexOf("Password:", StringComparison.InvariantCultureIgnoreCase) != -1)
                {
                    prompt.Response = ftpPwd;
                }
            }
        }

    }
}

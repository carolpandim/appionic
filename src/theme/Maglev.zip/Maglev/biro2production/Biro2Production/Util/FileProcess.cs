﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;

namespace Biro2Production.Util
{
    public class FileProcess
    {
        private static FileProcess oFileProcess = null;

        public static FileProcess Instance { get { oFileProcess = oFileProcess ?? new FileProcess(); return oFileProcess; } }

        public void SaveFile(String filePath, Model.DatInfo info)
        {
            var ansi = Encoding.GetEncoding(1252);

            if (ConfigurationManager.AppSettings["debug"] == "true")
            {
                try
                {
                    //----------Teste----------
                    using (StreamWriter outputFile = new StreamWriter(String.Concat(ConfigurationManager.AppSettings["fileDirectory"], "\\", info.FileName), false, ansi))
                    {
                        Int32 indexx = 1;
                        foreach (var item in info.Items)
                        {
                            outputFile.WriteLine(ParseDataFile(item, indexx));
                            outputFile.WriteLine();

                            indexx++;
                        }
                    }

                    DataBase.Procedure.Biro.Instance.UpdateStatus(Convert.ToInt64(info.OSId));
                }
                catch (Exception ex)
                {
                    BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao salvar o dat", "SaveFile", "OS: " + info.OSId);
                }
            }
            else
            {
                try
                {
                    //----------Produção----------
                    StringBuilder MyStringBuilder = new StringBuilder();

                    Int32 index = 1;
                    foreach (var item in info.Items)
                    {
                        MyStringBuilder.AppendLine(ParseDataFile(item, index));
                        MyStringBuilder.AppendLine("");
                        index++;
                    }

                    byte[] dataString = ansi.GetBytes(MyStringBuilder.ToString());


                    using (MemoryStream memStream = new MemoryStream())
                    {
                        memStream.Write(dataString, 0, dataString.Length);


                        memStream.Position = 0;

                        List<Model.FileInfo> fileInfo = new List<Model.FileInfo>();
                        fileInfo.Add(new Model.FileInfo()
                        {
                            data = memStream,
                            name = String.Concat(filePath, ".dat")
                        });

                        SFTPProcess.Instance.UploadFiles(info.OSId, fileInfo, ConfigurationManager.AppSettings["JallIn"]);

                        DataBase.Procedure.Biro.Instance.UpdateStatus(Convert.ToInt64(info.OSId));

                    }
                }
                catch(Exception ex)
                {
                    BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao salvar o dat no SFTP", "SaveFile", "OS: " + info.OSId);
                }
            }
        }


        private string ParseDataFile(Model.DatItems dat, Int32 index)
        {
            String dataReturn = String.Concat(
                    "\"", index, "\",",
                       "\"", dat.NumeroCartao, "\",",
                       "\"", dat.Nome, "\",",
                       "\"", dat.CardMessage, "\",",
                       "\"", dat.CartaoDigito, "\",",
                       "\"", dat.Vencimento, "\",",
                       "\"", dat.CodigoSeguranca, "\",",
                       "\"", dat.Trilha1, "\",",
                       "\"", dat.Trilha2, "\",",
                       "\"", dat.Imagem, "\",",
                       "\"", dat.Logo, "\",",
                       "\"", dat.ArquivoTemplate, "\",",
                       "\"", dat.BandejaFolheteria, "\",",
                       "\"", dat.QrCode, "\",",
                       "\"", dat.Mensagem, "\",",
                       "\"", dat.Titulo, "\",",
                       "\"", dat.Assinatura, "\",",
                       "\"", dat.Saldo, "\",",
                       "\"", dat.Senha, "\",",
                       "\"", dat.MensagemSenha, "\",",
                       "\"", dat.CdOrder, "\",",
                       "\"", dat.CodigoCartao, "\",",
                       "\"", dat.CodigoCartaoDigitoSeparado, "\",",
                       "\"", dat.Ultimos4DigitosCartao, "\",",
                       "\"", dat.CdOrderItem, "\",",
                       "\"", dat.CodigoBarraRastreio, "\",",
                       "\"", dat.RecipientName, "\",",
                       "\"", dat.RecipientAddress, "\",",
                       "\"", dat.RecipientComplement, "\",",
                       "\"", dat.RecipientZipCode, "\",",
                       "\"", dat.RecipientDistrict, "\",",
                       "\"", dat.RecipientCity, "\",",
                       "\"", dat.RecipientState, "\",",
                       "\"", dat.SenderName, "\",",
                       "\"", dat.SenderStreet, "\",",
                       "\"", dat.SenderComplement, "\",",
                       "\"", dat.SenderZipCode, "\",",
                       "\"", dat.SenderDistrict, "\",",
                       "\"", dat.SenderCity, "\",",
                       "\"", dat.SenderState, "\",",
                       "\"", dat.ChipCriptogram, "\",",
                       "\"", dat.Icvv, "\",",
                       "\"", dat.Custome_Shipping_Cost, "\",",
                       "\"", dat.Sales_Channel, "\",",
                       "\"", dat.Scheduled, "\",",
                       "\"", dat.Shipped_Date, "\",",
                       "\"", dat.Shipment_Order_Type, "\",",
                       "\"", dat.Delivery_Method_Id, "\",",
                       "\"", dat.Estimated_Delivery_Date, "\",",
                       "\"", dat.Email, "\",",
                       "\"", dat.Phone, "\",",
                       "\"", dat.CellPhone, "\",",
                       "\"", dat.Is_Company, "\",",
                       "\"", dat.Federal_Tax_Payer_Id, "\",",
                       "\"", dat.Shipping_Country, "\",",
                       "\"", dat.Shipment_Order_Volume_Number, "\",",
                       "\"", dat.Volume, "\",",
                       "\"", dat.Weight, "\",",
                       "\"", dat.Volume_Type_Code, "\",",
                       "\"", dat.Width, "\",",
                       "\"", dat.Height, "\",",
                       "\"", dat.Length, "\",",
                       "\"", dat.Products_Quantity, "\",",
                       "\"", dat.Is_Icms_Exempt, "\",",
                       "\"", dat.Invoice_Series, "\",",
                       "\"", dat.Invoice_Key, "\",",
                       "\"", dat.Invoice_Date, "\",",
                       "\"", dat.Invoice_Total_Value, "\",",
                       "\"", dat.Invoice_Cfop, "\",",
                       "\"", dat.Origin_WareHouse_Code, "\",",
                       "\"", dat.Plastico, "\",",
                       "\"", dat.Chip, "\",",
                       "\"", dat.DataBiro, "\",",
                       "\"", dat.Departamento, "\",",
                       "\"", dat.Unidade, "\""
                );

            return dataReturn;

        }
    }
}

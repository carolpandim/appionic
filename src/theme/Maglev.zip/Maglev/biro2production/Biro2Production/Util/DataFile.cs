﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biro2Production.Util
{
    public class DataFile
    {
        private static DataFile oDataFile = null;

        public static DataFile Instance { get { oDataFile = oDataFile ?? new DataFile(); return oDataFile; } }


        public Model.DatInfo ParseFile(DataBase.Model.OS os)
        {
            var datInfo = new Model.DatInfo();

            try
            {
                datInfo.FileName = String.Concat(os.IdOs,".dat");
                datInfo.OSId = os.IdOs.ToString();
                datInfo.Items = os.Items.Select(x => new Model.DatItems
                {
                    ArquivoTemplate = x.Template,
                    Assinatura = x.Assinatura,
                    CardMessage = x.Mensagem,
                    CartaoDigito = x.CardInfo.CartaoDigito,
                    CdOrder = x.IdPedido.ToString(),
                    CdOrderItem = x.IdPedidoItem.ToString(),
                    ChipCriptogram = "",
                    CodigoBarraRastreio = x.TrackingCode,
                    CodigoCartao = x.CodigoCartao.ToString(),
                    CodigoCartaoDigitoSeparado = x.CardInfo.CodigoCartaoDigitoSeparado,
                    CodigoSeguranca = x.CardInfo.CodigoSeguranca,
                    Icvv = x.CardInfo.Icvv,
                    Imagem = String.Concat(os.IdOs,"/", x.ImageName),
                    Linha = "",
                    Logo = String.Concat(os.IdOs, "/", x.LogoName),
                    Mensagem = x.Mensagem,
                    Nome = x.NomeCartao,
                    NumeroCartao = x.CardInfo.NumeroCartao,
                    RecipientAddress = x.EnderecoDestinatario,
                    RecipientCity = x.CidadeDestinatario,
                    RecipientComplement = x.ComplementoDestinatario,
                    RecipientDistrict = x.BairroDestinatario,
                    RecipientName = x.NomeDestinatario,
                    RecipientState = x.EstadoDestinatario,
                    RecipientZipCode = x.CepDestinatario,
                    Saldo = x.Saldo > 0 ? x.Saldo.ToString("N2").Replace(".", ",") : "0",
                    SenderCity = x.CidadeRemetente,
                    SenderComplement = x.ComplementoRemetente,
                    SenderDistrict = x.BairroRemetente,
                    SenderName = x.NomeRemetente,
                    SenderState = x.EstadoRemetente,
                    SenderStreet = x.EnderecoRemetente,
                    SenderZipCode = x.CepRemetente,
                    Senha = x.CardInfo.Senha,
                    Titulo = x.Titulo,
                    Trilha1 = x.CardInfo.Trilha1,
                    Trilha2 = x.CardInfo.Trilha2,
                    Ultimos4DigitosCartao = x.CardInfo.Ultimos4DigitosCartao,
                    Vencimento = x.CardInfo.Vencimento,
                    DataOS = x.Data_Biro.ToString("yyyy-MM-dd"),
                    Sales_Channel = x.Sales_Channel,
                    Scheduled = x.Scheduled.ToString(),
                    Shipped_Date = x.Shipped_Date.HasValue ? x.Shipped_Date.Value.ToString("yyyy-MM-dd") : "",
                    Shipment_Order_Type = x.Shipment_Order_Type,
                    Delivery_Method_Id = x.CoddigoMetodoTransporte.ToString(),
                    Estimated_Delivery_Date = x.Estimated_Delivery_Date.HasValue ? x.Estimated_Delivery_Date.Value.ToString("yyyy-MM-dd") : "",
                    Email = x.Email,
                    Phone = x.Phone,
                    CellPhone = x.CellPhone,
                    Is_Company = x.Is_Company.ToString(),
                    Federal_Tax_Payer_Id = x.Federal_Tax_Payer_Id,
                    Shipping_Country = x.Shipping_Country,
                    Shipment_Order_Volume_Number = x.Shipment_Order_Volume_Number.ToString(),
                    Volume = x.Volume_Name,
                    Weight = x.Weight > 0 ? x.Weight.ToString("0.##").Replace(".", ",") : "0",
                    Volume_Type_Code = x.Volume_Type_Code,
                    Width = x.Width > 0 ? x.Width.ToString("N2").Replace(".", ",") : "0",
                    Height = x.Height > 0 ? x.Height.ToString("N2").Replace(".", ",") : "0",
                    Length = x.Length > 0 ? x.Length.ToString("N2").Replace(".", ",") : "0",
                    Products_Quantity = x.Products_Quantity.ToString(),
                    Is_Icms_Exempt = x.Is_Icms_Exempt.ToString(),
                    Invoice_Series = x.Invoice_Series,
                    Invoice_Key = x.Invoice_Key,
                    Invoice_Date = x.Invoice_Date.HasValue ? x.Invoice_Date.Value.ToString() : "",
                    Invoice_Total_Value = x.Invoice_Total_Value > 0 ? x.Invoice_Total_Value.ToString("0.##").Replace(".", ",") : "0",
                    Invoice_Cfop = x.CFOP,
                    Origin_WareHouse_Code = x.Origin_WareHouse_Code,
                    Custome_Shipping_Cost = x.Customer_Shipping_Costs.ToString(),
                    Chip = x.Chip.ToString(),
                    Plastico = x.Plastico,
                    DataBiro = x.Data_Biro.ToString("dd/MM/yyyy HH:mm"),
                    Departamento = x.Departamento,
                    Unidade = x.Unidade
                }).ToList();
            }catch(Exception ex)
            {
                var s = ex.Message;
            }

            return datInfo;
        }
    }
}

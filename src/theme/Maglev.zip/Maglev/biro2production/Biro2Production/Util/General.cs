﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Biro2Production.Util
{
    public class General
    {
        private static General oGeneral = null;

        public static General Instance { get { oGeneral = oGeneral ?? new General(); return oGeneral; } }

        public int GeraDigitoVerificador(String pan)
        {

            int soma = 0, aux = 0, dv = 0, start = 0;

            if (pan.Length % 2 == 0)
                start = 1;

            for (int i = 0; i < pan.Length; i++)
            {
                aux = Convert.ToInt32(pan.Substring(i, 1));

                // faco isso pois deveria comecar da direita pra esquerda e estou começando da esquerda
                // para acertar isso, faço o seguinte:
                // se o tamanho é impar, entao devo comecar contando do primeiro digito a multiplicacao por 2;
                // se for par, começo do segundo digito
                if ((i + start) % 2 == 0)
                    aux *= 2;

                // esquema para somar de uma vez, caso um digito seja maior q 9
                soma += (aux / 10) + (aux % 10);
            }


            // vai somando até que encontre o próximo número em que mod 10 = 0;
            while (soma % 10 != 0)
            {
                dv++;
                soma++;
            }

            return dv;

        }



        public string FormatCardNumber(String numeroCartao)
        {
            var cartao = String.Concat(numeroCartao.Substring(0, 4), " ", numeroCartao.Substring(4, 4), " ", numeroCartao.Substring(8, 4), " ", numeroCartao.Substring(12, 4));

            return cartao;
        }

        public string FormatVencimento(String vencimento)
        {
            return String.Concat(vencimento.Substring(0, 2), "/", vencimento.Substring(2, 2));
        }


        public string RemoveDiacritics(string text)
        {

            if (!String.IsNullOrEmpty(text))
            {
                var normalizedString = text.Normalize(NormalizationForm.FormD);
                var stringBuilder = new StringBuilder();

                foreach (var c in normalizedString)
                {
                    var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                    if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                    {
                        stringBuilder.Append(c);
                    }
                }

                return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
            }
            else
            {
                return text;
            }
        }
    }
}

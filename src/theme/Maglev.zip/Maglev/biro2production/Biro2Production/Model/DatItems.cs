﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biro2Production.Model
{
    public class DatItems
    {
        //1
        public String Linha { get; set; }
        //2
        public String NumeroCartao { get; set; }
        //3
        public String Nome { get; set; }
        //4
        public String CardMessage { get; set; }
        //5
        public String CartaoDigito { get; set; }
        //6
        public String Vencimento { get; set; }
        //7
        public String CodigoSeguranca { get; set; }
        //8
        public String Trilha1 { get; set; }
        //9
        public String Trilha2 { get; set; }
        //10
        public String Imagem { get; set; }
        //11
        public String Logo { get; set; }
        //12
        public String ArquivoTemplate { get; set; }
        //13
        public String BandejaFolheteria { get { return "2"; } }
        //14
        public String QrCode { get { return ""; } }
        //15
        public String Mensagem { get; set; }
        //16
        public String Titulo { get; set; }
        //17
        public String Assinatura { get; set; }
        //18
        public String Saldo { get; set; }
        //19
        public String Senha { get; set; }
        //20
        public String MensagemSenha { get { return ""; } }
        //21
        public String CdOrder { get; set; }
        //22
        public String CodigoCartao { get; set; }
        //23
        public String CodigoCartaoDigitoSeparado { get; set; }
        //24
        public String Ultimos4DigitosCartao { get; set; }
        //25
        public String CdOrderItem { get; set; }
        //26
        public String CodigoBarraRastreio { get; set; }
        //27
        public String RecipientName { get; set; }
        //28
        public String RecipientAddress { get; set; }
        //29
        public String RecipientComplement { get; set; }
        //30
        public String RecipientZipCode { get; set; }
        //31
        public String RecipientDistrict { get; set; }
        //32
        public String RecipientCity { get; set; }
        //33
        public String RecipientState { get; set; }
        //34
        public String SenderName { get; set; }
        //35
        public String SenderStreet { get; set; }
        //36
        public String SenderComplement { get; set; }
        //37
        public String SenderZipCode { get; set; }
        //38
        public String SenderDistrict { get; set; }
        //39
        public String SenderCity { get; set; }
        //40
        public String SenderState { get; set; }
        //41
        public String ChipCriptogram { get; set; }
        //42
        public String Icvv { get; set; }
        //43
        public String DataOS { get; set; }
        //44
        public String Custome_Shipping_Cost { get; set; }
        //45
        public String Sales_Channel { get; set; }
        //46
        public String Scheduled { get; set; }
        //47
        public String Shipped_Date { get; set; }
        //48
        public String Shipment_Order_Type { get; set; }
        //49
        public String Delivery_Method_Id { get; set; }
        //50
        public String Estimated_Delivery_Date { get; set; }
        //51
        public String Email { get; set; }
        //52
        public String Phone { get; set; }
        //53
        public String CellPhone { get; set; }
        //54
        public String Is_Company { get; set; }
        //55
        public String Federal_Tax_Payer_Id { get; set; }
        //56
        public String Shipping_Country { get; set; }
        //57
        public String Shipment_Order_Volume_Number { get; set; }
        //58
        public String Volume { get; set; }
        //59
        public String Weight { get; set; }
        //60
        public String Volume_Type_Code { get; set; }
        //61
        public String Width { get; set; }
        //62
        public String Height { get; set; }
        //63
        public String Length { get; set; }
        //64
        public String Products_Quantity { get; set; }
        //65
        public String Is_Icms_Exempt { get; set; }
        //66
        public String Invoice_Series { get; set; }
        //67
        public String Invoice_Key { get; set; }
        //68
        public String Invoice_Date { get; set; }
        //69
        public String Invoice_Total_Value { get; set; }
        //70
        public String Invoice_Cfop { get; set; }
        //71
        public String Origin_WareHouse_Code { get; set; }
        //72
        public String Plastico { get; set; }
        //73
        public String Chip { get; set; }
        //74
        public String DataBiro { get; set; }
        //75
        public String Departamento { get; set; }
        //76
        public String Unidade { get; set; }
    }
}

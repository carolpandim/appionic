﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Biro2Production.Model
{
    public class FileInfo
    {
        public MemoryStream data { get; set; }
        public String name { get; set; }
    }
}

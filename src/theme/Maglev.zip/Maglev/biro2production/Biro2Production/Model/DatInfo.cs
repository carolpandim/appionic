﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biro2Production.Model
{
    public class DatInfo
    {
        public String FileName { get; set; }
        public String OSId { get; set; }

        public List<Model.DatItems> Items { get; set; }
    }
}

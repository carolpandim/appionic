﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Biro2Production
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();

            Console.WriteLine(DateTime.Now);

            var result = DataBase.Procedure.Biro.Instance.GetOS2Production();

            Console.WriteLine("Total OS" + result.Count);
            Console.WriteLine(DateTime.Now);

            List<Model.DatInfo> dataInfos = new List<Model.DatInfo>();

            Object locked = new object();

            //foreach(var os in result)
            Parallel.ForEach(result, os =>
            {
                try
                {
                    Console.WriteLine("Init Get Item: " + os.IdOs);
                    Console.WriteLine(DateTime.Now);
                    os.Items = DataBase.Procedure.Biro.Instance.GetItems(os.IdOs);
                    Console.WriteLine("End Get Item");
                    Console.WriteLine(DateTime.Now);
                    lock (locked)
                    {

                        List<String> images = new List<String>();
                        images.AddRange(os.Items.Where(x => !String.IsNullOrEmpty(x.Imagem)).GroupBy(x => x.Imagem).Select(x => x.Key).ToList());
                        images.AddRange(os.Items.Where(x => !String.IsNullOrEmpty(x.Logo)).GroupBy(x => x.Logo).Select(x => x.Key).ToList());


                        try
                        {
                            if (images.Count() > 0)
                            {
                                var imagePath = String.Concat(ConfigurationManager.AppSettings["fileDirectory"], "\\", os.IdOs);

                                Util.ImageProcess.Instance.SaveImage(imagePath, images, System.Drawing.Imaging.ImageFormat.Png);

                                if (ConfigurationManager.AppSettings["debug"] != "true")
                                {
                                    Util.SFTPProcess.Instance.UploadDirectory(Util.SFTPProcess.Instance.CreateClient(), os.IdOs.ToString(), imagePath, ConfigurationManager.AppSettings["JallOut"]);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }

                        Util.FileProcess.Instance.SaveFile(os.IdOs.ToString(), Util.DataFile.Instance.ParseFile(os));
                    }
                }
                catch(Exception ex)
                {
                    BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Erro ao gerar arquivo dat", "Biro2Production", "OS: " + os.IdOs);
                }
            }
           );

            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;

            Console.WriteLine(String.Format("Tempo de Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));
            Console.Read();
        }
    }
}

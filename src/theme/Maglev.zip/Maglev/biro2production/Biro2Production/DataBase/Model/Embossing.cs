﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biro2Production.DataBase.Model
{
    public class Embossing
    {
        public String Trilha1 { get; set; }
        public String Trilha2 { get; set; }
        public String Senha { get; set; }
        public String Vencimento { get; set; }
        public String NumeroCartao { get; set; }
        public String Nome { get; set; }
        public String Icvv { get; set; }
        public String CodigoCartaoDigitoSeparado { get; set; }
        public String CartaoDigito { get; set; }
        public String CodigoSeguranca { get; set; }
        public String Ultimos4DigitosCartao { get; set; }
    }
}

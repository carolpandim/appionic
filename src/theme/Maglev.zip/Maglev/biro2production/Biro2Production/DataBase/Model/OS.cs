﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biro2Production.DataBase.Model
{
    public class OS
    {
        public Int64 IdOs { get; set; }
        public String CodigoCanal { get; set; }
        public List<Item> Items { get; set; }
    }
}

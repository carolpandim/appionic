﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biro2Production.DataBase.Procedure
{
    public class Biro
    {
        private static Biro oBiro;

        public static Biro Instance { get { oBiro = oBiro ?? new Biro(); return oBiro; } }

        public List<Model.OS> GetOS2Production()
        {
            List<Model.OS> returnData = new List<Model.OS>();

            try
            {

                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroNewRead"].ConnectionString))
                {
                    conn.Open();

                    var query = "Select t1.IdOs, t1.CodigoCanal from Os t1 where t1.idStatus = 3 order by idOs";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            returnData.Add(new Model.OS()
                            {
                                IdOs = Convert.ToInt64(reader["idos"]),
                                CodigoCanal = reader["CodigoCanal"].ToString()
                            });
                        }

                    }

                    conn.Close();

                }
            }catch(Exception ex)
            {
                BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao Pegar as OS para Produção", "DataBase.Procedure.Biro.GetOS2Production", "");
            }

            return returnData;

        }

        public void UpdateStatus(Int64 idOs)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroNewProd"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand("update os set idstatus=4, dataenvio=getdate() where idos = @idOs", conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { Value = idOs, ParameterName= "@idOs", SqlDbType = System.Data.SqlDbType.BigInt });

                        comm.ExecuteScalar();
                    }

                    conn.Close();

                }

            }
            catch (Exception ex)
            {
                BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao atualizar a OS", "DataBase.Procedure.Biro.UpdateStatus", "OS: " + idOs);
            }
        }

        public List<Model.Item> GetItems(Int64 idOs)
        {
            var data = new List<Model.Item>();
            ConcurrentStack<Model.Item> results = new ConcurrentStack<Model.Item>();

            Int32 total = 0;
            Int32 totalPages = 0;
            Int32 pageSize = 1000;

            Object locked = new object();

            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroNewRead"].ConnectionString))
                {
                    conn.Open();

                    var queryTotal = "select count(1) from items(nolock) where idOs = " + idOs;
                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        total = (Int32)comm.ExecuteScalar();

                        totalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(total) / pageSize));
                    }



                    Console.WriteLine("Total Registro: "+ total);

                    //Parallel.For(1, totalPages +1 , pageIndex =>
                    for(var pageIndex = 1; pageIndex < totalPages + 1; pageIndex++)
                    {
                        Console.WriteLine("Row "+ pageIndex);

                        lock (locked)
                        {
                            var query = "Select * from Items where IdOs = " + idOs + " order by iditem OFFSET(({0} -1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        //var query = "Select * from Items where IdOs = " + idOs;

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        //using (SqlCommand comm = new SqlCommand(query, conn))
                        {
                                var reader = comm.ExecuteReader();

                                while (reader.Read())
                                {
                                    var item = new Model.Item();
                                    item.IdOs = Convert.ToInt64(reader["idos"]);
                                    item.IdPedido = Convert.ToInt64(reader["idpedido"]);
                                    item.IdPedidoItem = Convert.ToInt64(reader["idpedidoitem"]);
                                    item.TrackingCode = reader["trackingCode"].ToString();
                                    item.CodigoCartao = Convert.ToInt64(reader["codigocartao"]);
                                    if (!String.IsNullOrEmpty(reader["imagem"].ToString()))
                                    {
                                        item.Imagem = String.Concat(idOs,"/", reader["imagem"].ToString().Substring(reader["imagem"].ToString().LastIndexOf("/") + 1));
                                    }

                                    if (!String.IsNullOrEmpty(reader["logo"].ToString()))
                                    {
                                        item.Logo = String.Concat(idOs, "/", reader["logo"].ToString().Substring(reader["logo"].ToString().LastIndexOf("/") + 1));
                                    }

                                    item.EnderecoRemetente = Util.General.Instance.RemoveDiacritics(reader["enderecoremetente"].ToString());
                                    item.NumeroRemetente = Util.General.Instance.RemoveDiacritics(reader["numeroremetente"].ToString();
                                    item.ComplementoRemetente = Util.General.Instance.RemoveDiacritics(reader["complementoremetente"].ToString());
                                    item.BairroRemetente = Util.General.Instance.RemoveDiacritics(reader["bairroremetente"].ToString());
                                    item.CepRemetente = reader["cepremetente"].ToString();
                                    item.CidadeRemetente = Util.General.Instance.RemoveDiacritics(reader["cidaderemetente"].ToString());
                                    item.EstadoRemetente = Util.General.Instance.RemoveDiacritics(reader["estadoremetente"].ToString());
                                    item.EnderecoDestinatario = Util.General.Instance.RemoveDiacritics(reader["enderecodestinatario"].ToString());
                                    item.NumeroDestinatario = Util.General.Instance.RemoveDiacritics(reader["numerodestinatario"].ToString());
                                    item.ComplementoDestinatario = Util.General.Instance.RemoveDiacritics(reader["complementodestinatario"].ToString());
                                    item.BairroDestinatario = Util.General.Instance.RemoveDiacritics(reader["bairrodestinatario"].ToString());
                                    item.CepDestinatario = reader["cepdestinatario"].ToString();
                                    item.CidadeDestinatario = Util.General.Instance.RemoveDiacritics(reader["cidadedestinatario"].ToString());
                                    item.EstadoDestinatario = Util.General.Instance.RemoveDiacritics(reader["estadodestinatario"].ToString());
                                    item.Mensagem = reader["mensagem"].ToString();
                                    item.Titulo = reader["titulo"].ToString();
                                    item.Assinatura = reader["assinatura"].ToString();
                                    item.CoddigoMetodoTransporte = reader["codigometodotransporte"].ToString();
                                    item.NomeRemetente = reader["nomeremetente"].ToString();
                                    item.NomeDestinatario = reader["nomedestinatario"].ToString();
                                    item.NomeCartao = reader["nomecartao"].ToString();
                                    item.Data_Pedido = Convert.ToDateTime(reader["data_pedido"]);
                                    item.Data_Biro = Convert.ToDateTime(reader["data_biro"]);
                                    item.Customer_Shipping_Costs = Convert.ToInt32(reader["customer_shipping_costs"]);
                                    item.Sales_Channel = reader["sales_channel"].ToString();
                                    item.Scheduled = Convert.ToBoolean(reader["scheduled"]);
                                    if (!String.IsNullOrEmpty(reader["shipped_date"].ToString()))
                                    {
                                        item.Shipped_Date = Convert.ToDateTime(reader["shipped_date"]);
                                    }

                                    item.Shipment_Order_Type = reader["shipment_order_type"].ToString();
                                    if (!String.IsNullOrEmpty(reader["estimated_delivery_date"].ToString()))
                                    {
                                        item.Estimated_Delivery_Date = Convert.ToDateTime(reader["estimated_delivery_date"]);
                                    }
                                    item.Email = reader["email"].ToString();
                                    item.Phone = reader["phone"].ToString();
                                    item.CellPhone = reader["cellphone"].ToString();
                                    item.Is_Company = Convert.ToBoolean(reader["is_company"]);
                                    item.Federal_Tax_Payer_Id = reader["federal_tax_payer_id"].ToString();
                                    item.Shipping_Country = reader["shipping_country"].ToString();
                                    item.Shipment_Order_Volume_Number = Convert.ToInt32(reader["shipment_order_volume_number"]);
                                    item.Volume_Name = reader["volume_name"].ToString();
                                    item.Weight = Convert.ToDecimal(reader["weight"]);
                                    item.Volume_Type_Code = reader["volume_type_code"].ToString();
                                    item.Width = Convert.ToDecimal(reader["width"]);
                                    item.Height = Convert.ToDecimal(reader["height"]);
                                    item.Length = Convert.ToDecimal(reader["length"]);
                                    item.Products_Quantity = Convert.ToInt32(reader["products_quantity"]);
                                    item.Is_Icms_Exempt = Convert.ToBoolean(reader["is_icms_exempt"]);
                                    item.Invoice_Series = reader["invoice_series"].ToString();
                                    item.Invoice_Key = reader["invoice_key"].ToString();
                                    if (!String.IsNullOrEmpty(reader["invoice_date"].ToString()))
                                    {
                                        item.Invoice_Date = Convert.ToDateTime(reader["invoice_date"]);
                                    }
                                    item.Invoice_Total_Value = Convert.ToDecimal(reader["invoice_total_value"]);
                                    item.CFOP = reader["cfop"].ToString();
                                    item.Origin_WareHouse_Code = reader["origin_warehouse_code"].ToString();
                                    item.Plataforma = reader["plataforma"].ToString();
                                    if (!String.IsNullOrEmpty(reader["saldo"].ToString()))
                                    {
                                        item.Saldo = Convert.ToDecimal(reader["saldo"]);
                                    }
                                    item.Plastico = reader["plastico"].ToString();
                                    item.Template = reader["template"].ToString();
                                    item.Chip = Convert.ToBoolean(reader["chip"]);
                                    item.Unidade = reader["unidade"].ToString();
                                    item.Departamento = reader["departamento"].ToString();

                                    results.Push(item);
                                }
                            }
                        }

                    }
                    //);

                    conn.Close();
                }

                Parallel.ForEach(results, item =>
                {

                    lock (locked)
                    {
                        Console.WriteLine("Start Get Embossing " + item.CodigoCartao + " - " + DateTime.Now);
                        item.CardInfo = DataBase.Procedure.Processadora.Instance.GetEmbossing(item.CodigoCartao);
                        Console.WriteLine("End Get Embossing " + DateTime.Now);
                    }
                });

            }
            catch (Exception ex)
            {
                BiroUtils.Controllers.Logs.Instance.RegisterLog("Biro2Production", "error", "Ocorreu um erro ao pegar os itens da OS", "DataBase.Procedure.Biro.GetItems", "OS: " + idOs);
                throw ex;
            }

            return results.ToArray().ToList();
        }
    }
}

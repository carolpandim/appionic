﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;

namespace Biro2Production.DataBase.Procedure
{
    public class Processadora
    {
        private static Processadora oProcessadora;

        public static Processadora Instance { get { oProcessadora = oProcessadora ?? new Processadora(); return oProcessadora; } }

        public Model.Embossing GetEmbossing(Int64 codigoCartao)
        {
            return ProcessEmbossing(codigoCartao, 1);

        }

        private Model.Embossing ProcessEmbossing(Int64 codigoCartao, Int32 tentativa)
        {
            var data = new Model.Embossing();

            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Processadora"].ConnectionString))
                {
                    conn.Open();
                    var query = "exec  Cliente_ValePresente_RetornaDadosEmbossing " + codigoCartao;

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.CommandTimeout = 3000;
                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            data.Trilha1 = reader["trilha1"].ToString().Substring(0, reader["trilha1"].ToString().Length - 1).ToUpper();
                            data.Trilha2 = reader["trilha2"].ToString().Substring(0, reader["trilha2"].ToString().Length - 1).ToUpper();
                            data.Senha =reader["Senha"].ToString();
                            data.Vencimento = Util.General.Instance.FormatVencimento(reader["ValidadeMMAA"].ToString());
                            data.NumeroCartao = Util.General.Instance.FormatCardNumber(reader["Numero"].ToString());
                            data.Nome = reader["Nome"].ToString().ToUpper();
                            data.Icvv =  reader["CodigoSegurancaChip"].ToString();
                            data.CodigoCartaoDigitoSeparado = String.Concat(codigoCartao, "-", Util.General.Instance.GeraDigitoVerificador(reader["Numero"].ToString())).PadLeft(10, '0');
                            data.CartaoDigito = String.Concat(codigoCartao, Util.General.Instance.GeraDigitoVerificador(reader["Numero"].ToString()));
                            data.CodigoSeguranca = reader["CodigoSeguranca"].ToString();
                            data.Ultimos4DigitosCartao = reader["Numero"].ToString().Substring(12, 4);
                        }


                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                if(tentativa <= 3)
                {
                    tentativa++;
                    data = ProcessEmbossing(codigoCartao, tentativa);
                    
                }
                else
                {
                    throw ex;
                }
            }
            return data;
        }
    }
}

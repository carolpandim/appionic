export class CustomResult<T>  {
    public message: string;
    public data: T;
    public success: Boolean;
}
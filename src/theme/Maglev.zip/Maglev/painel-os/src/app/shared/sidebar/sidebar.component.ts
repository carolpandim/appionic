import { Component } from '@angular/core';
import { AuthenticationService } from '../../general/service/authentication.service';
import { Router } from '@angular/router';
import { AppComponent } from '../../app.component';
@Component({
    selector: 'shared-sidebar',
    templateUrl: 'sidebar.component.html',
    providers:[]
})
export class SideBarComponent {

    menu:any = [];

    user: any;

    constructor(
        private authenticationService: AuthenticationService,
        private appComponent: AppComponent,
        private router: Router
    ) 
    {         
        this.user = authenticationService.getUser();
    }

    logout(){
        this.authenticationService.clearSession();
        this.appComponent.ConfigPanel();
        this.router.navigate(['']);
    }
}
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AuthenticationService } from "../../general/service/authentication.service";
import { AppComponent } from "../../app.component";


@Component({
    selector: 'shared-navbar',
    templateUrl: 'navbar.component.html',
    providers:[]
})
export class NavBarComponent implements OnInit {

    user: any = {};

    statusWorkFlow:any = {};

    constructor(
        private appComponent: AppComponent,
        private authenticationService: AuthenticationService,
        private router: Router) { 
        }

    ngOnInit() {
    }        

    signOut() {
        this.authenticationService.clearSession();
        this.appComponent.ConfigPanel();
        this.router.navigate(['']);
    }
}
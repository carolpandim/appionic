import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class OrdemServicoProvider {

    user: UserModel;

    controllerName: String = "os";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }

    search(data: any,pageIndex: number, pageSize:number): Observable<any> {
        return this.httpService.post(`${this.controllerName}/list/${pageIndex}/${pageSize}`,data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    liberar(idOs: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/liberar/${idOs}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }        

}

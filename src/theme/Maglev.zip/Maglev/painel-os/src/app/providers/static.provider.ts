import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { HttpService } from '../general/service/http.service';
import { AuthenticationService } from '../general/service/authentication.service';


@Injectable()
export class StaticProvider {

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         

    }

    listMonths(startDate: Date) {

        var dtStart = new Date(startDate);
        var dtEnd = new Date(startDate);

        dtStart = new Date(dtStart.setMonth(dtStart.getMonth() - 2));
        dtEnd = new Date(dtEnd.setMonth(dtEnd.getMonth() + 2));

        var dts = [];
        while(dtStart <= dtEnd){
            dts.push(new Date(dtStart));

            dtStart = new Date(dtStart.setMonth(dtStart.getMonth() + 1));
        }

        return dts;

    }  

    getMonthName = function(isAbr : Boolean, date: Date){
        var monthNamesFull = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
        var monthNamesAbr = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun",  "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

        if(isAbr)
        {
            return monthNamesAbr[date.getMonth()];
        }
        else{
            return monthNamesFull[date.getMonth()];
        }
    }    

}
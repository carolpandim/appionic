import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";

@Injectable()
export class DownloadProvider {

    user: UserModel;

    controllerName: String = "download";

    constructor(
        private httpService: HttpService,
    ) {         
    }

    picking(idOs: any){        
        this.httpService.download(`${this.controllerName}/picking/${idOs}`);       
    }       

}

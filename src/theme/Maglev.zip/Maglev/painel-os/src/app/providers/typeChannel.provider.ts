import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class TypeChannelProvider {

    user: UserModel;

    controllerName: String = "typeChannel";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }


    list(idOsType:any, pageindex:number, pagesize:number): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list/${idOsType}/${pageindex}/${pagesize}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    // list(idOsType:any): Observable<any> {
    //     return this.httpService.get(`${this.controllerName}/list/${idOsType}`)
    //         .map((response) => {
    //             return response as CustomResult<Array<any>>;
    //         });
    // }    

    detail(idostypechannel: any): Observable<any> {
        return this.httpService.get(`${this.controllerName}/detail/${idostypechannel}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }

    save(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/save`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }

    remover(idostypechannel: any): Observable<any> {
        return this.httpService.delete(`${this.controllerName}/delete/${idostypechannel}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    
}

import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';

import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";

@Injectable()
export class AuthProvider {

    controllerName: String = "auth/login";

    constructor(
        private service: HttpService,
        private authenticationService: AuthenticationService
    ) { }

    signIn(request: any, erroHandler: (error: any)=> void): Observable<UserModel> {
        return this.service.post(`${this.controllerName}`, request, erroHandler)
            .map((response) => {
                let user = response as UserModel;                
                this.authenticationService.setToken(user.token as string);
                return response;
            });
    }
}

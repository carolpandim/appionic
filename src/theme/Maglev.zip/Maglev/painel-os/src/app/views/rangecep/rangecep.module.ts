import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule, TabViewModule, TooltipModule, KeyFilterModule, CheckboxModule  } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IndexComponent } from './index/index.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';
import {TableModule} from 'primeng/table';
import { DropdownModule } from 'primeng/components/dropdown/dropdown';
import { BsModalModule } from 'ng2-bs3-modal';
import { DetailComponent } from './detail/detail.component';


@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule,
        TabViewModule,
        ConfirmDialogModule,
        CheckPermissionModule,
        BsModalModule,
        TooltipModule,
        KeyFilterModule,
        MultiSelectModule,
        CalendarModule,
        CheckboxModule,
        TableModule,
        DropdownModule
    ],
    declarations: [
        IndexComponent,
        DetailComponent
    ],
    exports: [
        IndexComponent,
        DetailComponent
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})

export class RangeCepModule { }

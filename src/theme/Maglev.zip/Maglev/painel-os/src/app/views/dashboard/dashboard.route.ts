import { Routes } from '@angular/router';

import { IndexComponent } from './index/index.component';
import { AuthenticationGuard } from '../../general/authentication/authentication.guard';

export const DashBoardRoutes: Routes = [
   { path: 'dashboard', redirectTo: '/pedido', pathMatch: 'full' }
];

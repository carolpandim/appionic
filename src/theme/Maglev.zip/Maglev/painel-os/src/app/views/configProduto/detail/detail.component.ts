import { Component, OnInit, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { SelectItem } from 'primeng/primeng';
import { AppComponent } from "../../../app.component";
import { ConfigProdutoProvider } from '../../../providers/configProduto.provider';
import { CommonProvider } from '../../../providers/common.provider';

@Component({
    selector: 'configProduto-detail',
    templateUrl: './detail.component.html',
    providers: [ConfigProdutoProvider, CommonProvider]
})
export class DetailComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    rangeCep: any = [];
    loadingItens: boolean = false;
    btAlter: boolean = false;
    form: FormGroup;
    desabilitar: boolean = false;
    editData: any = {};
    metodos: SelectItem[] = [];

    constructor(
        private configProdutoProvider: ConfigProdutoProvider,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private commonProvider: CommonProvider
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            codigo: ['', Validators.required],
            codigometodotransporte: ['', Validators.required]
        });

        this.metodos.push({ label: "Selecione", value: "" });
        this.commonProvider.listMetodoTransporte().subscribe((response) => {
            if (response.success && response.data) {
                response.data.map(o => {
                    this.metodos.push({ label: o.label, value: o.value });
                });                
            }
        });     
    }

    ngAfterViewChecked() {
        //this.changeDetectorRef.detectChanges();
        
    }

    LoadData(codigo: any) {
        this.btAlter = false;
        this.form.reset();
        this.editData={};
        this.desabilitar = false;
        if (this.saveEmitter.observers.length > 1) {
            this.saveEmitter.observers.pop();
        }
        if (codigo) {
            this.configProdutoProvider.detail(codigo).subscribe((response) => {
                if (response.success) {
                    this.editData = response.data;
                    this.form.patchValue(response.data);
                }
            });
        }
    }

    Save() {
        if (this.form.valid) { 
            Object.assign(this.editData, this.form.value);
            this.configProdutoProvider.save(this.editData).subscribe((response) => {
                this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }
}


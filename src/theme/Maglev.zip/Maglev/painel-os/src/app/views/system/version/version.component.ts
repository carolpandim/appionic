import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AppComponent } from "../../../app.component";

@Component({
  selector: 'system-version',
  templateUrl: './version.component.html'
})
export class VersionComponent implements OnInit {

  constructor(
    private router: Router,
    private appComponent: AppComponent,
  ) {
  
  }

  ngOnInit() {
   
  }

}

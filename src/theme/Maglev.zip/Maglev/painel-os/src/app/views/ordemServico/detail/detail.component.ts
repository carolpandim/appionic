import { Component, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { ConfirmationService } from 'primeng/primeng';
import { AppComponent } from "../../../app.component";
import { ItemOsProvider } from '../../../providers/itemOs.provider';

@Component({
    selector: 'detail-os-item',
    templateUrl: './detail.component.html',
    providers: [ConfirmationService]
})
export class DetailComponent {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();
    
    form: FormGroup;
    editData: any = {};

    constructor(
        private itemOsProvider: ItemOsProvider
    ) {

    }

    LoadData(idItem: any)
    {        
        if(idItem)
        {
            this.itemOsProvider.detail(idItem).subscribe((response) =>{
                if(response.success)
                {
                    this.editData = response.data;
                }
            });
        }
        else{
            this.editData = {};
        }
    }   

    ngAfterViewChecked() {
    
    }
    

}

import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';

export const ConfigProdutoRoutes: Routes = [
   { path: 'configProduto', component: IndexComponent, canActivate: [AuthenticationGuard] }
];
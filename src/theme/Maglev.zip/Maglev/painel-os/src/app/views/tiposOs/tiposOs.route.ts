import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';

export const TiposOsRoutes: Routes = [
   { path: 'tiposOs', component: IndexComponent, canActivate: [AuthenticationGuard] }
];

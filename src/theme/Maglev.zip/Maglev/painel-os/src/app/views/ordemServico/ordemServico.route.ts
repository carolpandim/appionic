import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';
import { ItemsComponent } from './items/items.component';

export const OrdemServicoRoutes: Routes = [
   { path: 'os', component: IndexComponent, canActivate: [AuthenticationGuard] },
   { path: 'os/items/:idos', component: ItemsComponent, canActivate: [AuthenticationGuard] }
];

import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { ConfirmationService } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { AppComponent } from "../../../app.component";
import { TypeChannelProvider } from '../../../providers/typeChannel.provider';


@Component({
    selector: 'channel-typeOs',
    templateUrl: './channel-typeOs.html',
    providers: [TypeChannelProvider, ConfirmationService]
})
export class ChannelTypeOs implements OnInit {

    @ViewChild('ManutModal')
    manutModal: BsModalComponent;  
   
    @ViewChild('Table')
    table: Table;

    result: any = [];

    form: FormGroup;
    dataManut: any = {};

    firstPage: number = 0;
    totalRecords: number = 0;
    rows: number = 0;
    page: number = 1;  
    pageIndex: number = 1;
    pageSize: number = 5;
    totalRecord: number;
    loading: boolean = false ;
    showDismiss: boolean = false;
    manutData: any[];
    idOsType: any;
    idOsTypechannel: any;


    constructor(
        private typeChannelProvider: TypeChannelProvider,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private confirmationService: ConfirmationService,
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            idOsTypechannel: ['',],
            idOsType: [''],
            codigoCanal: ['', Validators.required],
            nome: ['', Validators.required]
        });
    }

    load(idOsType: any)
    {        
        this.idOsType = idOsType;
        this.search({});
    }

    search(page: any = {}) {

        if(this.idOsType){
            this.loading = true;
            if (page.first > 1) {
                this.pageIndex = (page.first / this.pageSize) + 1;
            }
            else {
                this.pageIndex = 1;
            }

            this.result = [];
            this.typeChannelProvider.list(this.idOsType,this.pageIndex, this.pageSize).subscribe((response) => {
                if (response.success) {                           
                this.result = response.data;
                this.rows = this.pageSize;
                this.totalRecords = response.totalResultado;        
                }
                else {
                this.notificationService.error("Atenção", response.Message, { clickToClose: true });
                }
            });
            this.loading = false;      
        }
    }
    
    Novo()
    {   
        this.form.reset();             
        this.manutModal.open();
        
    }

    ngAfterViewChecked() {
        this.changeDetectorRef.detectChanges();
    }
    
    Editar(Idostypechannel: any)
    {
        this.form.reset();
        this.typeChannelProvider.detail(Idostypechannel).subscribe((response) => {
            if (response.success) {
                this.dataManut = response.data;
                this.form.patchValue(response.data);
            }
        });
        this.manutModal.open();        
    }


    DialogRemover(item: any) {

        this.confirmationService.confirm({
            message: 'Deseja excluir o item ' + item.nome + '? ',
            header: 'Excluir Metodo!',
            icon: "fa fa-download",
            key: "excluir",
            accept: () => {
                this.loading = true;       
                this.typeChannelProvider.remover(item.idOsTypechannel).subscribe((response) => {
                    if (response.success) {          
                        this.notificationService.success("","Item excluído!", { clickToClose: true });
                        this.table.reset();
                        this.search({});                         
                        this.result.value = [];                    
                    }
                    else {
                    this.notificationService.error("Atenção", response.Message, { clickToClose: true });
                    }
                });  
                this.loading = false;     
            },
        });
        
    }

    Salvar() {        
        
        if(!this.form.value.idOsType)
        {
            this.form.value.idOsType=this.idOsType;
        }   
        
        if (this.form.valid) {
            this.loading = true;               
            this.result = [];        
            this.typeChannelProvider.save(this.form.value).subscribe((response) => {
                if (response.success) {          
                    this.notificationService.success("", "Dados Salvos!", { clickToClose: true });  
                    this.clearPage()                           
                    this.search();   
                }
                else {
                    this.notificationService.error("Atenção", response.Message, { clickToClose: true });
                }
            });
            this.result.value = [];                 
            this.manutModal.close();   
            this.table.reset();              
        }
            else{
                this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
        this.loading = false;          
    }

    Channel(id: any)
    {
        this.form.reset();
        this.typeChannelProvider.detail(id).subscribe((response) => {
            if (response.success) {
                this.dataManut = response.data;
                this.form.patchValue(response.data);
            }
        });
        this.manutModal.open();        
    }    

    clearPage()
    {        
        this.totalRecords = 0;
        this.firstPage = 0;
    }

}

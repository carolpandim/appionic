import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { AppComponent } from "../../../app.component";

declare var theme: {
    init() : void
    clean() : void
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './index.component.html',
    providers: []  
})
export class IndexComponent  implements OnInit {

  constructor(
        private router: Router,
        private appComponent: AppComponent
    ) { 

    }

 ngOnInit() {    
  }    
}

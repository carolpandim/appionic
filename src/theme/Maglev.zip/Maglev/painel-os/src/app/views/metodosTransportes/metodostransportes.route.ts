import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';

export const MetodosTransportesRoutes: Routes = [
   { path: 'metodos-transportes', component: IndexComponent, canActivate: [AuthenticationGuard] }
];

import { Component, OnInit, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { ConfirmationService } from 'primeng/primeng';
import { AppComponent } from "../../../app.component";
import { SafePipe } from '../../../shared/util/SafePipe';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { PedidoProvider } from '../../../providers/pedido.provider';

@Component({
    selector: 'remove-order',
    templateUrl: './remove.component.html',
    providers: [PedidoProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class RemoveComponent implements OnInit {

      @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    idOrderItem: any;
    idOrder: any;
    form: FormGroup;
    result: any;

    constructor(
        private formBuilder: FormBuilder,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private pedidoProvider: PedidoProvider
    ) {
    }

    ngAfterViewChecked() {
        this.changeDetectorRef.detectChanges();
    }

    ngOnInit() {

        this.form = this.formBuilder.group({
            description: ['', Validators.required]
        });
    }


    LoadData(idOrder: any, idOrderItem: any) {
        this.idOrder = idOrder;
        this.idOrderItem = idOrderItem;
    }

    Salvar() {
        if (this.form.valid) {
            var data = {IdPedido: this.idOrder, IdPedidoItem: this.idOrderItem, Description: this.form.controls["description"].value };

            this.pedidoProvider.delete(data).subscribe((response) => {

                if (response.success) {
                    this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
                }
                else {
                    this.saveEmitter.emit({ success: response.success, severity: 'alert', detail: response.message });
                }
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }

}

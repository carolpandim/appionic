import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { ConfirmationService, SelectItem } from 'primeng/primeng';
import { Table } from 'primeng/table';
import { AppComponent } from "../../../app.component";
import { PedidoProvider } from '../../../providers/pedido.provider';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { OsTypeProvider } from '../../../providers/osType.provider';
import { BsModalComponent } from 'ng2-bs3-modal';
import { ManutencaoTipoOsComponent } from '../manutencao/manutencao-tiposOs';
import { ChannelTypeOs } from '../channel/channel-typeOs';
import { CommonProvider } from '../../../providers/common.provider';


@Component({
  selector: 'app-pedido-index',
  templateUrl: './index.component.html',  
  providers: [PedidoProvider,SafePipe,ConfirmationService,OsTypeProvider,CommonProvider]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];

  @ViewChild('OsTypeEditModal')
  osTypeEditModal: BsModalComponent;

  @ViewChild('ChannelModal')
  channelModal: BsModalComponent;
  
  @ViewChild(ManutencaoTipoOsComponent)
  manutencaoTipoOsComponent: ManutencaoTipoOsComponent;
  
  @ViewChild(ChannelTypeOs)
  channelTypeOs: ChannelTypeOs;
  
  @ViewChild('Table')
  table: Table;

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;  
  pageIndex: number = 1;
  pageSize: number = 10;
  totalRecord: number;
  filterData: any = {};
  checkedAll: boolean = false;
  manutOs:boolean = false;
  loading: boolean = false ;
  showDismiss: boolean = false;
  manutData: any[];

  produtos: SelectItem[] =[];

  constructor(
    private formBuilder: FormBuilder,
    private notificationService: NotificationsService,
    private confirmationService: ConfirmationService,
    private osTypeProvider: OsTypeProvider,
    private commonProvider: CommonProvider    
  ) {
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      b2b:[null],
      idOsType:[''],
      ativo:[true]
    });

    Object.assign(this.filterData, this.form.value);    

    this.produtos.push({label: "Selecione uma Opção", value: ""});
    this.commonProvider.listOsType().subscribe((response) => {
      if (response.success) {
        response.data.map((item) =>{
          this.produtos.push({label: item.label, value: item.value})
        });
      }
    });
  }

  ApplyFilter() {   
      Object.assign(this.filterData, this.form.value);      
      this.result = [];
      this.search({ first: 0 });
      //this.authenticationService.setSearchCaixa(null);
  }

  ClearForm(){
    this.form.reset();    
  }

  search(page: any = {}) {
    this.loading = true;
    if (page.first > 1) {
      this.pageIndex = (page.first / this.pageSize) + 1;
    }
    else {
      this.pageIndex = 1;
    }
    this.result = [];
   
    this.osTypeProvider.list(this.filterData, this.pageIndex, this.pageSize).subscribe((response) => {
      if (response.success) {          
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        //this.authenticationService.setSearchCaixa({filter: this.filterData, data: response});                                           
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
    });
    this.loading = false;      
  }

  DialogRemover(id: any)
  {
   
    this.confirmationService.confirm({
      message: '<br> Deseja Inativar o tipo de OS selecionado?',
      header: 'Desativar OS!',
      icon: "fa fa-window-close-o",
      key: "desativar",
      accept: () => {
        this.Remover(id);
      },
    });
  }

  Editar(id: any)
  {
    this.Manutencao(id);
  }
 
  Novo()
  {
    this.Manutencao("");
  }  

  Manutencao(id: any)
  {       
    this.manutencaoTipoOsComponent.saveEmitter.subscribe((response) =>{
      this.notificationService
      if (response.success) {     
        this.osTypeEditModal.dismiss();                                 
        this.notificationService.success("Parabéns", response.detail);   
      }
      else {       
        this.notificationService.error("Atenção", response.detail);                            
      }                            
      this.table.reset();
      this.search({});
    });
    this.manutencaoTipoOsComponent.LoadData(id);
    this.osTypeEditModal.open();
  }
  
  Remover(id: any)
  {
    var dataPost = {};
    this.loading = true;

    this.osTypeProvider.remover(id).subscribe((response) => {
        if (response.success) { 
          this.notificationService.success("Item desativado!",response.Message, { clickToClose: true });         
        }
        else {
          this.notificationService.error("Atenção", response.Message, { clickToClose: true });
        }
        this.table.reset();
        this.ApplyFilter();
        this.loading = false;
    });
  
  }

  ManutChannel(id: any)
  {       

    this.channelTypeOs.load(id);
    this.channelModal.open();
  }
  
}

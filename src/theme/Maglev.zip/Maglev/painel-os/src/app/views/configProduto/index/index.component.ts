import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { ConfirmationService } from 'primeng/primeng';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AppComponent } from "../../../app.component";
import { AuthenticationService } from '../../../general/service/authentication.service';
import { ConfigProdutoProvider } from '../../../providers/configProduto.provider';
import { DetailComponent } from '../detail/detail.component';

@Component({
  selector: 'app-codigoProduto-index',
  templateUrl: './index.component.html',  
  providers: [ConfigProdutoProvider,SafePipe,ConfirmationService]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];

  @ViewChild('DetailModal')
  detailModal: BsModalComponent;  

  @ViewChild('Table')
  table: Table;

  @ViewChild(DetailComponent)
  detailComponent: DetailComponent;  

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;  
  pageIndex: number = 1;
  totalRecord: number;
  filterData: any = {};
  loading: boolean = false ;
  showDismiss: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private notificationService: NotificationsService,
    private confirmationService: ConfirmationService,
    private configProdutoProvider:ConfigProdutoProvider,
  ) {
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      codigo: ['']
    });

    Object.assign(this.filterData, this.form.value);   
  }

  ApplyFilter() {   
      Object.assign(this.filterData, this.form.value);      
      this.result = [];
      this.search({ first: 0 });
  }

  ClearForm(){
    this.filterData = {};
    this.form.reset();
  }

  search(page: any = {}) {
    this.loading = true;
    if (page.first > 1) {
      this.pageIndex = (page.first / AppConfig.ResultPerPage) + 1;
    }
    else {
      this.pageIndex = 1;
    }
    this.result = [];
   
    this.configProdutoProvider.list(this.pageIndex, AppConfig.ResultPerPage,this.filterData).subscribe((response) => {
      if (response.success) {          
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
    });
    this.loading = false;      
  }

  DialogRemover(item: any)
  {
    this.confirmationService.confirm({
      message: 'Deseja Remover o Produto ' + item.codigo + ' ?',
      header: 'Remover Produto!',
      key: "desativar",
      accept: () => {
        this.Remover(item.idconfiguracaoproduto);
      },
    });
  }

  Edit(idconfiguracaoproduto: any = '')
  {
    this.detailComponent.saveEmitter.subscribe((response) =>{
      if (response.success) {     
        this.detailModal.close();                                 
        this.notificationService.success("Parabéns", response.detail);   
      }
      else {       
        this.notificationService.error("Atenção", response.detail);                            
      }         

      this.table.reset();
      this.ApplyFilter();
    });

    this.detailComponent.LoadData(idconfiguracaoproduto);
    this.detailModal.open('lg');
  }

  Save(){
    this.detailComponent.Save();
  }

  
  Remover(id: any)
  {
    this.loading = true;
    this.configProdutoProvider.delete(id).subscribe((response) => {
        if (response.success) { 
          this.notificationService.success("Atenção",response.message, { clickToClose: true });         
        }
        else {
          this.notificationService.error("Atenção", response.message, { clickToClose: true });
        }
        this.table.reset();
        this.ApplyFilter();
        this.loading = false;
    });
  }

}

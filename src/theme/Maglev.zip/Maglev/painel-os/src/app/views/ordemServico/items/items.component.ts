import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { ConfirmationService } from 'primeng/primeng';
import { Table } from 'primeng/table';
import { BsModalComponent } from 'ng2-bs3-modal';
import { AppComponent } from "../../../app.component";
import { OrdemServicoProvider } from '../../../providers/ordemServico.provider';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { CommonProvider } from '../../../providers/common.provider';
import { ItemOsProvider } from '../../../providers/itemOs.provider';
import { DetailComponent } from '../detail/detail.component';

@Component({
  selector: 'app-ordemServico-items',
  templateUrl: './items.component.html',
  providers: [OrdemServicoProvider,ItemOsProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class ItemsComponent implements OnInit {

  form: FormGroup;
  result: any = [];

  @ViewChild('DetailModal')
  detailModal: BsModalComponent;  
  @ViewChild(DetailComponent)
  detailComponent: DetailComponent;
  

  @ViewChild('Table')
  table: Table;
  
  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;
  filterData: any = {};
  loading: boolean = false;

  idOs: number;

  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private notificationService: NotificationsService,
    private route: ActivatedRoute,
    private itemOsProvider: ItemOsProvider
  ) {
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
        this.idOs = params['idos'];
        this.search({});
     });
  }

  ApplyFilter() {
    if (this.form.valid) {
      Object.assign(this.filterData, this.form.value);
      
      this.result = [];
      this.search({ first: 0 });
    }
    else {
      this.notificationService.error("Atenção", "Por favor, informe os campos obrigatórios!", { clickToClose: true });
    }
  }

  ClearForm() {
    this.form.reset();
    this.filterData = {};
    this.table.reset();
    this.search({});
    this.result.value = [];   
  }

  
  search(page: any = {}) {

    if (page.first >= 0) {
      this.page = (page.first /AppConfig.ResultPerPage) + 1;
    }
    else {
      this.page = 1;
    }

    this.result = [];
    this.loading = true;
    this.itemOsProvider.list(this.idOs, this.page, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        this.changeDetectorRef.detectChanges();                 
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
      this.loading = false;
    });
  }

  View(idItem:number)
  {
      this.detailComponent.LoadData(idItem);
      this.detailModal.open('lg');
  }

}

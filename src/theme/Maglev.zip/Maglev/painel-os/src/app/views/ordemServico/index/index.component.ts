import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotificationsService } from 'angular2-notifications';
import { ConfirmationService, SelectItem  } from 'primeng/primeng';
import { Table } from 'primeng/table';
import { OrdemServicoProvider } from '../../../providers/ordemServico.provider';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { CommonProvider } from '../../../providers/common.provider';
import { DownloadProvider } from '../../../providers/download.provider';

@Component({
  selector: 'app-ordemServico-index',
  templateUrl: './index.component.html',
  providers: [OrdemServicoProvider, CommonProvider, SafePipe, ConfirmationService, DownloadProvider]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];
  osStatus: SelectItem[] = [];

  @ViewChild('Table')
  table: Table;


  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;
  filterData: any = {};
  loading: boolean = false;


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private ordemServicoProvider: OrdemServicoProvider,
    private changeDetectorRef: ChangeDetectorRef,
    private notificationService: NotificationsService,
    private confirmationService: ConfirmationService,
    private commonProvider: CommonProvider,
    private downloadProvider: DownloadProvider
  ) {
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
      this.form = this.formBuilder.group({
        idos: [''],
        idPedido: [''],
        dataInicio: [''],
        dataFim: [''],
        idStatus: ['']
    });

    this.commonProvider.listOsStatus().subscribe((response) => {
      if (response.success) {

        response.data.map((item) =>{
          this.osStatus.push({label: item.label, value: item.value});
        });

      }
    });    
  }

  ApplyFilter() {
    if (this.form.valid) {
      Object.assign(this.filterData, this.form.value);
      
      this.table.reset();
      this.totalRecords = 0;
      this.result.length = 0; 
      this.result = [];
      this.search({ first: 0 });
    }
    else {
      this.notificationService.error("Atenção", "Por favor, informe os campos obrigatórios!", { clickToClose: true });
    }
  }

  ClearForm() {
    this.filterData = {};
    this.form.reset();
    this.table.reset();
    this.result.length = 0;
    this.totalRecords = 0;
  }

  
  search(page: any = {}) {

    if (page.first >= 0) {
      this.page = (page.first /AppConfig.ResultPerPage) + 1;
    }
    else {
      this.page = 1;
    }

    this.result = [];
    this.loading = true;
    this.ordemServicoProvider.search(this.filterData, this.page, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        this.changeDetectorRef.detectChanges();
      }
      else
      {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
      this.loading = false;
    });
  }

  View(idOs: number){
    this.router.navigate(['/os/items/', idOs]);
  }

  Liberar(idOs: any) {

    this.confirmationService.confirm({
    message: 'Deseja Liberar a OS: ' + idOs + ' ?',
    header: 'Liberar OS!',
    key: "liberarDialog",
    accept: () => {
      this.loading = true;
      this.ordemServicoProvider.liberar(idOs).subscribe((response) => {
        if (response.success) {
          this.table.reset();
          this.search({});
          this.result.value = [];                  
          this.notificationService.success("", response.message, { clickToClose: true });
        }
        else {
          this.notificationService.error("Atenção", response.message, { clickToClose: true });
        }
        this.loading = false;
      });      
    },
    });
  }

  GeraPicking(idOs: any) {    
    this.downloadProvider.picking(idOs);
  }  
}

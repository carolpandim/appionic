export * from './index/index.component';
export * from './tiposOs.route';
export * from './tiposOs.module';
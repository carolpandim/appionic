import { Component, OnInit, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { NotificationsService } from 'angular2-notifications';
import { SelectItem } from 'primeng/primeng';
import { AppComponent } from "../../../app.component";
import { PedidoProvider } from '../../../providers/pedido.provider';
import { CommonProvider } from '../../../providers/common.provider';

@Component({
    selector: 'transporte-order',
    templateUrl: './transporte.component.html',
    providers: [PedidoProvider, CommonProvider]
})
export class TransporteComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    idOrderItem: any;
    idOrder: any;
    result: any;

    form: FormGroup;
    metodos: SelectItem[] = [];

    constructor(
        private pedidoProvider: PedidoProvider,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private commonProvider: CommonProvider
    ) {
    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            codigoMetodoTransporte: ['', Validators.required]
        });

        this.metodos.push({ label: "Selecione", value: "" });
        this.commonProvider.listMetodoTransporte().subscribe((response) => {
            if (response.success && response.data) {
                response.data.map(o => {
                    this.metodos.push({ label: o.label, value: o.value });
                });                
            }
        });     
    }

    ngAfterViewChecked() {
        //this.changeDetectorRef.detectChanges();
        
    }

    LoadData(idOrder: any, idOrderItem: any, _codigometodotransporte: any) {
        var aux = {codigoMetodoTransporte: _codigometodotransporte};        
        this.form.patchValue({codigoMetodoTransporte: _codigometodotransporte});

        this.idOrder = idOrder;
        this.idOrderItem = idOrderItem;             
    }

    Salvar() {

        if (this.form.valid) {
            var data = {IdPedido: this.idOrder, IdPedidoItem: this.idOrderItem, codigometodotransporte: this.form.controls["codigoMetodoTransporte"].value };
            this.pedidoProvider.alteraTransportadora(data).subscribe((response) => {

                if (response.success) {
                    this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
                }
                else {
                    this.saveEmitter.emit({ success: response.success, severity: 'alert', detail: response.message });
                }
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }
}


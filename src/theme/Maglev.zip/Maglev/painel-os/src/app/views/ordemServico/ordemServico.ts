export * from './index/index.component';
export * from './ordemServico.route';
export * from './ordemServico.module';
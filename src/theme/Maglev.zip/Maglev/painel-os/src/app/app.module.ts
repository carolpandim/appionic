import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, XHRBackend } from '@angular/http';
import { DatePipe } from '@angular/common';

import { InterceptorProvider } from './general/authentication/interceptor.provider';
import { AuthenticationGuard } from './general/authentication/authentication.guard';
import { LoginGuard } from './general/authentication/login.guard';

import { SlimLoadingBarModule} from 'ng2-slim-loading-bar';

import { SimpleNotificationsModule } from 'angular2-notifications';

import { appRoute, routes } from './app.route';
import { AppComponent } from './app.component';

import { AuthenticationService } from './general/service/authentication.service';
import { NavBarModule, SideBarModule } from './shared/shared';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { EmitterProvider } from "./general/emitter/emitter.provider";
import { HttpService } from "./general/service/http.service";

import { LoginModule } from './views/login/login';
import { DashBoardModule } from './views/dashboard/dashboard';
import { BsModalModule } from 'ng2-bs3-modal';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { SystemModule } from './views/system/system';
import { PedidoModule } from './views/pedido/pedido';
import { OrdemServicoModule } from './views/ordemServico/ordemServico';
import { TiposOsModule } from './views/tiposOs/tiposOs';
import { RangeCepModule } from './views/rangecep/rangecep';
import { MetodosTransportesModule } from './views/metodosTransportes/metodostransportes';
import { ConfigProdutoModule } from './views/configProduto/configProduto';


@NgModule({
  declarations: [
    AppComponent,

  ],
  imports: [
    routes,
    BrowserModule,
    BrowserAnimationsModule, 
    FormsModule,
    HttpModule,
    SlimLoadingBarModule.forRoot(),
    SimpleNotificationsModule.forRoot(),
    LazyLoadImageModule,
    BsModalModule,
    NavBarModule, 
    SideBarModule,
    LoginModule,
    DashBoardModule,
    SystemModule,
    PedidoModule,
    OrdemServicoModule,
    TiposOsModule,
    MetodosTransportesModule,
    RangeCepModule,
    ConfigProdutoModule
  ],
  providers: [
    appRoute,
    SlimLoadingBarModule,
    InterceptorProvider,
    AuthenticationGuard,
    LoginGuard,
    AuthenticationService,
    EmitterProvider,
    HttpService,
    DatePipe,
    { provide: XHRBackend, useClass: InterceptorProvider }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


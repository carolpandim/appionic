import { Injectable } from '@angular/core';
import { Http, Headers, RequestMethod, RequestOptions,ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { NotificationsService } from "angular2-notifications";
import { AuthenticationService } from "./authentication.service";
import { AppConfig } from "../app.configuration";
import { EmitterProvider } from "../emitter/emitter.provider";
import { EmitterType } from "../emitter/emitter.type";
import { saveAs } from 'file-saver/FileSaver';
declare var moment: any;

@Injectable()
export class HttpService {

    constructor(
        private http: Http,
        private notificationService: NotificationsService,             
        private emitter: EmitterProvider,
        private authenticationService: AuthenticationService
    ) { }

    createQuery(query: any): String {
        let param = "";

        for (let prop in query) {
            if (!param) {
                param = "?$filter=";
            }
            else {
                param += " and "
            }

            let value = query[prop];
            param += `${prop}+eq+${value}`;
        }

        return param;
    }

    file(resource: String, erroHandler?: (error: any) => void): Observable<any> {
        return this.callFile(resource, null, RequestMethod.Get, erroHandler);
    }

    get(resource: String, parms?: any, erroHandler?: (error: any) => void): Observable<any> {
        return this.call(resource, parms, RequestMethod.Get, erroHandler);
    }

    post(resource: String, parms?: any, erroHandler?: (error: any) => void): Observable<any> {
        return this.call(resource, parms, RequestMethod.Post, erroHandler);
    }

    download(resource: String) {
        return this.callDownload(resource);
    }    

    put(resource: String, parms?: any, erroHandler?: (error: any) => void): Observable<any> {
        return this.call(resource, parms, RequestMethod.Put, erroHandler);
    }

    delete(resource: String, parms?: any, erroHandler?: (error: any) => void): Observable<any> {
        return this.call(resource, parms, RequestMethod.Delete, erroHandler);
    }

    external(resource: String, method: RequestMethod,  parms?: any, erroHandler?: (error: any) => void): Observable<any> {
        return this.callexternal(resource, parms, method, erroHandler);
    }    

    private callexternal(resource: String, param?: any, method: RequestMethod = RequestMethod.Get, erroHandler?: (error: any) => void): Observable<any> {

        this.emitter.base.emit(EmitterType.LOADING_BEGIN);

        let options = new RequestOptions({ method: method, body: param });
        let uri = `${resource}`;

        return new Observable<any>(observer => {

            this.http.request(uri, options)
                .map((res) => res.json())
                .subscribe((response) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);
                    observer.next(response);
                    observer.complete();

                }, (error) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);

                    if (erroHandler) {
                        erroHandler(error);
                    }
                    else {
                        this.handleError(error, resource);
                    }
                });
        });
    }    

    private call(resource: String, param?: any,
        method: RequestMethod = RequestMethod.Get, erroHandler?: (error: any) => void): Observable<any> {

        this.emitter.base.emit(EmitterType.LOADING_BEGIN);

        let options = new RequestOptions({ method: method, body: param });
        let uri = `${AppConfig.Api}/${resource}`;

        return new Observable<any>(observer => {

            let user = this.authenticationService.getUser();

            this.http.request(uri, options)
                .map((res) => res.json())
                .subscribe((response) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);
                    observer.next(response);
                    observer.complete();

                }, (error) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);

                    if (erroHandler) {
                        erroHandler(error);
                    }
                    else {
                        this.handleError(error, resource);
                    }
                });
        });
    }

    
    private callDownload(resource: String){

        this.emitter.base.emit(EmitterType.LOADING_BEGIN);

        let uri = `${AppConfig.Api}/${resource}`;
    
        window.open(uri);
    }

    
    private callFile(resource: String, param?: any,
        method: RequestMethod = RequestMethod.Get, erroHandler?: (error: any) => void): Observable<any> {

        this.emitter.base.emit(EmitterType.LOADING_BEGIN);

        let options = new RequestOptions({ method: method, body: param });
        let uri = `${resource}`;

        return new Observable<any>(observer => {

            let user = this.authenticationService.getUser();

            this.http.request(uri, options)
                .map((res) => res.json())
                .subscribe((response) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);
                    observer.next(response);
                    observer.complete();

                }, (error) => {
                    this.emitter.base.emit(EmitterType.LOADING_END);

                    if (erroHandler) {
                        erroHandler(error);
                    }
                    else {
                        this.handleError(error, resource);
                    }
                });
        });        
    }

    private handleError(response: any, resource: String) {
        
        if (response.status === 401)
        {
            this.notificationService.error("Atenção", "Acesso não autorizado!");
            this.emitter.base.emit(EmitterType.USER_SIGN_OUT);
        }
        else if(response.status === 403) {
            this.emitter.base.emit(EmitterType.USER_SIGN_OUT);
        }
        else if(response.status === 500){
            this.notificationService.error("Atenção", "Ocorreu um erro!");
        }
    }
}

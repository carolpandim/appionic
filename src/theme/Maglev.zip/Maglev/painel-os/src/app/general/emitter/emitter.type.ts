export class EmitterType {

    static LOADING_BEGIN = "LOADING_BEGIN";

    static USER_SIGN_IN = "USER_SIGN_IN";

    static USER_SIGN_OUT = "USER_SIGN_OUT";

    static LOADING_END = "LOADING_END";
    
}
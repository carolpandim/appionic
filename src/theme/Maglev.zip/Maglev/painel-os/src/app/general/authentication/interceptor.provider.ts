import { Injectable } from '@angular/core';
import { XHRBackend, BrowserXhr, Request, Response, ResponseOptions, XSRFStrategy } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AuthenticationService } from '../service/authentication.service';
import {AppConfig} from '../app.configuration';

@Injectable()
export class InterceptorProvider extends XHRBackend {

    private authenticationService: AuthenticationService;

    constructor(browserXhr: BrowserXhr, baseResponseOptions: ResponseOptions, xsrfStrategy: XSRFStrategy) {
        super(browserXhr, baseResponseOptions, xsrfStrategy);
        this.authenticationService = new AuthenticationService();
    }

    createConnection(request: Request) {
        let enableToken = request.url.indexOf(AppConfig.Api) >= 0; 
        
        if (enableToken && this.authenticationService.getToken()) {
            request.headers.set('Authorization', `Bearer ${this.authenticationService.getToken()}`);
        }

        let xhrConnection = super.createConnection(request);
        xhrConnection.response = xhrConnection.response
        //.catch((this.processResponse));

        return xhrConnection;
    }

    processResponse(response: Response) {
        if (this.authenticationService.isAuthenticated && this.isAuthorizedStatus(response)) {
        }
        return Observable.throw(response);
    }

    isAuthorizedStatus(response: Response) {
        return (response.status === 401 || response.status === 403);
    }
}

import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Injectable()
export class LoginGuard implements CanActivate {
    constructor(private authenticationService: AuthenticationService, private router: Router) {}

    canActivate() {
        if (this.authenticationService.isAuthenticated ) {
            this.router.navigate(['/dashboard']);
        } else {
            return true;
        }
    }
}

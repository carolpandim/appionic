
import { Directive, ElementRef, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';


@Directive({ selector: '[checkPermission]' })
export class CheckPermissionDirective implements OnInit {

    el: ElementRef;
    authenticationService: AuthenticationService;
    constructor(
        el: ElementRef, 
        authenticationService: AuthenticationService
    ) 
    {
        this.el = el;
        this.authenticationService = authenticationService;
    }

    ngOnInit() {
        let permissions = this.authenticationService.getPermissions();
        
        let params = this.el.nativeElement.dataset;
        let item = null;

        if (!permissions) return;

        if (params.permission) {
            item = permissions.find(x => params.permission.indexOf(x) > -1);
        }
        if (!item) {
            
            if(this.el && this.el.nativeElement){

                if(!params.action)
                {
                    this.el.nativeElement.remove();
                }
                else if(params.action == "disable"){
                    //(<HTMLElement>this.el.nativeElement).setAttribute('disabled', 'true');
                    this.el.nativeElement.style.display = 'none';
                }
            }   
        }
    }

}
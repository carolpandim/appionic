import { Injectable } from '@angular/core';
import { EmitterEvent } from './emitter.event';

@Injectable()
export class EmitterProvider {
    base: EmitterEvent;
    
    constructor() {
        this.base = new EmitterEvent();
    }
}

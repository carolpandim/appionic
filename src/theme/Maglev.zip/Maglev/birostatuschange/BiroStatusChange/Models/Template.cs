﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroStatusChange.Models
{
    class Template
    {
        public String NomeTemplate { get; set; }
        public String NomeCliente { get; set; }
    }
}

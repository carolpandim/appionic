﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroStatusChange.Models
{
    class MetodoTransportador
    {
        public int CodigoMetodoTransporte { get; set; }
        public int Sla { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroStatusChange.Models
{
    class OrderPreProduction
    {
        public Int64 Id { get; set; }
        public BiroUtils.Models.JSON.OrderPreProduction Conteudo { get; set; }
        public Int64 TotalCartoes { get; set; }
        public Decimal PesoCartoes { get; set; }
        public Decimal ValorTotalNotaFiscal { get; set; }
    }
}

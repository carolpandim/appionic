﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroStatusChange.App_Start
{
    class ConfigurationJSON
    {
        public Configuration configuration { get; set; }

        public class Configuration
        {
            public String TrackingCodePrefixBegin { get; set; }
            public String TrackingCodePrefixEnd { get; set; }
            public decimal InvoiceTotalValue { get; set; }
            public decimal CardWeight { get; set; }
            public String Invoicekey { get; set; }

            public ConnectionStrings connectionStrings { get; set; }

            public class ConnectionStrings
            {

                public String BiroRead { get; set; }
                public String BiroProd { get; set; }
                public String ProcesadoraRead { get; set; }
            }

        }
    }
}

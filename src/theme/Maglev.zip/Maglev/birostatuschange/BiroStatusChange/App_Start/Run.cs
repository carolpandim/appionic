﻿using Newtonsoft.Json;
using System.IO;
using System.Reflection;

namespace BiroStatusChange.App_Start
{
    class Run
    {
        public static ConfigurationJSON ConfigurationJSON()
        {
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"BiroStatusChange.json");
            string config = File.ReadAllText(path);
            var JsonObject = JsonConvert.DeserializeObject<ConfigurationJSON>(config);
            return JsonObject;
        }
    }
}

﻿using BiroStatusChange.Database.SQL;
using BiroStatusChange.Services;
using System;

namespace BiroStatusChange
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Precione a tecla Ctrl+C para abortar Processo");
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine(" ");

            if (args.Length > 0)
            {
                OpcoesMenu(args);
            }
            else
            {
                Console.WriteLine("Nenhuma opção foi informada ! ");
                Console.WriteLine("Usage: ");
                Console.WriteLine(" --ProcessOrdersWithStatus1    Processa 1000 pedidos com status 1");
                Console.WriteLine(" --ProcessOrdersWithStatus4    Processa 1000 pedidos com status 4");
            }
        }

        private static void OpcoesMenu(string[] Opcao)
        {
            foreach (var arg in Opcao)
            {
                var opcao = arg.ToString();

                switch (opcao)
                {
                    case "--ProcessOrdersWithStatus1":
                        Commands.Status1.Start();
                        break;

                    case "--ProcessOrdersWithStatus4":
                        Commands.Status4.Start();
                        break;

                    default:
                        Console.WriteLine("opção informada não existe!");
                        Console.WriteLine("Usage: ");
                        Console.WriteLine(" --ProcessOrdersWithStatus1    Processa 1000 pedidos com status 1");
                        Console.WriteLine(" --ProcessOrdersWithStatus4    Processa 1000 pedidos com status 4");
                        break;
                }
            }

            Console.WriteLine(" ");
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("----------------Fim processamento------------");
            Console.WriteLine("---------------------------------------------");

        }
    }
}

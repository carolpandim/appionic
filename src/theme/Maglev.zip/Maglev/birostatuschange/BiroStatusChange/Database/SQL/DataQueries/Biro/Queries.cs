﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroStatusChange.Database.SQL.DataQueries.Biro
{
    class Queries
    {
        public static String GetTotalItemsOrderPreProduction()
        {
            String Query = @"
                            select 
	                            count(0)
                            from
	                            OrderPreProduction t1 
                            where 
                                t1.idstatusorderpreproduction = 1
	                            and t1.Deleted = 0
                            ";
            return Query;
        }

        public static string GetItemsOrderPreProduction(Int32 pageIndex = 0, Int32 pageSize = 0)
        {
            String Query = @"
                            select 
	                            t1.id,
	                            t1.conteudo
                            from
	                            OrderPreProduction t1
                            where 
                                t1.idstatusorderpreproduction = 1
	                            and t1.Deleted = 0
                            order by t1.id OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY
                            ";

            Query = String.Format(Query, pageIndex.ToString(), pageSize.ToString());

            return Query;
        }

        public static String GetCodigoMetodoEntrega(long cep)
        {
            String Query = @"
                              select
	                            top 1
	                            t3.sla,
	                            t2.prioridade,
	                            t3.codigometodotransporte
                            from
	                            rangecep t1
	                            inner join tiposEntregas t2 on t1.idtipoentrega = t2.idtipoentrega
	                            inner join metodostransportes t3 on t1.codigometodotransporte = t3.codigometodotransporte 
                            where
	                            '{0}' between cepinicio and cepfim
                            order by
	                            t2.prioridade asc
                            ";

            Query = String.Format(Query, cep);

            return Query;
        }

        public static String GetTemplateAndNomeCliente(long CodigoCanal)
        {
            String Query = @"
                            select 
                                top 1
	                            ot.produto 'NomeCliente',
	                            ot.template
                            from 
	                            osTypeChannels oc
	                            inner join osType ot on oc.idostype = ot.idostype
                            where
	                            oc.codigocanal = {0}
                            ";

            Query = String.Format(Query, CodigoCanal);

            return Query;
        }

    }

}

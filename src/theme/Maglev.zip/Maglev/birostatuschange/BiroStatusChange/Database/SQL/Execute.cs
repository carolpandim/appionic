﻿using BiroStatusChange.App_Start;
using BiroUtils.Controllers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;

namespace BiroStatusChange.Database.SQL
{
    class Execute
    {
        public class Query
        {
            private static Query oQuery;

            public static Query Instance { get { oQuery = oQuery ?? new Query(); return oQuery; } }

            private ConfigurationJSON.Configuration.ConnectionStrings connectionStrings;

            public Query()
            {
                this.connectionStrings = App_Start.Run.ConfigurationJSON().configuration.connectionStrings;
            }

            public List<Models.OrderPreProduction> GetItemsOrderPreProduction(int pageIndex, int pageSize)
            {
                List<Models.OrderPreProduction> listOrderPreProduction = new List<Models.OrderPreProduction>();

                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Biro.Queries.GetItemsOrderPreProduction(pageIndex, pageSize), conn))
                        {
                            var reader = comm.ExecuteReader();
                            while (reader.Read())
                            {
                                listOrderPreProduction.Add(new Models.OrderPreProduction()
                                {
                                    Id = Convert.ToInt64(reader["id"]),
                                    Conteudo = JsonConvert.DeserializeObject<BiroUtils.Models.JSON.OrderPreProduction>(reader["conteudo"].ToString()),
                                });
                            }
                        }
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu um erro ao tentar processar os items da OrderPreProduction");
                    Logs.Instance.RegisterLog("BiroStatusChange", "error", ex.Message.ToString(), "GetItemsOrderPreProduction", "query:" + DataQueries.Biro.Queries.GetItemsOrderPreProduction(pageIndex, pageSize));
                }

                return listOrderPreProduction;
            }

            public long GetTotalItemsOrderPreProduction()
            {
                long result = 0;
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Biro.Queries.GetTotalItemsOrderPreProduction(), conn))
                        {
                            result = Convert.ToInt64(comm.ExecuteScalar());
                        }
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu um erro ao tentar processar os items da OrderPreProduction");
                    Logs.Instance.RegisterLog("BiroStatusChange", "error", ex.Message.ToString(), "GetTotalItemsOrderPreProduction", "query:" + DataQueries.Biro.Queries.GetTotalItemsOrderPreProduction());
                }

                return result;
            }

            public void UpdateOrderPreProduction(List<String> Updates)
            {

                using (SqlConnection conn = new SqlConnection(connectionStrings.BiroProd))
                {
                    conn.Open();

                    foreach (var update in Updates)
                    {
                        SqlTransaction transaction = conn.BeginTransaction();

                        try
                        {
                            using (SqlCommand comm = new SqlCommand(update, conn, transaction))
                            {
                                comm.ExecuteScalar();
                            }
                            transaction.Commit();
                        }                    
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            Logs.Instance.RegisterLog("BiroStatusChange", "error", ex.Message.ToString(), "UpdateOrderPreProduction", ex.StackTrace.ToString());
                        }
                    }
                    conn.Close();
                }

            }

            public Models.MetodoTransportador GetCodigoMetodoEntrega(long cep)
            {
                Models.MetodoTransportador item = new Models.MetodoTransportador();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.GetCodigoMetodoEntrega(cep), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var reader = comm.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    item.CodigoMetodoTransporte = Convert.ToInt32(reader["codigometodotransporte"]);
                                    item.Sla = Convert.ToInt32(reader["sla"]);

                                }
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao tentar pegar tipo de transportador. Consulte Logs");
                    Logs.Instance.RegisterLog("", "error", "field:" + ex.Message.ToString(), "SetPropertiesTransportes", "query:" + SQL.DataQueries.Biro.Queries.GetCodigoMetodoEntrega(cep));
                }

                return item;

            }

            public Models.Template GetTemplateAndNomeCliente(long CodigoCanal)
            {
                Models.Template item = new Models.Template();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.GetTemplateAndNomeCliente(CodigoCanal), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var reader = comm.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    item.NomeCliente = reader["NomeCliente"].ToString();
                                    item.NomeTemplate = reader["template"].ToString();
                                }
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao tentar pegar tipo de transportador. Consulte Logs");
                    Logs.Instance.RegisterLog("", "error", "field:" + ex.Message.ToString(), "GetTemplateAndNomeCliente", "query:" + SQL.DataQueries.Biro.Queries.GetTemplateAndNomeCliente(CodigoCanal));
                }

                return item;

            }

        }
    }
}

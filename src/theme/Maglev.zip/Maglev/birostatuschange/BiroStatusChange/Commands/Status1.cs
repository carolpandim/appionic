﻿using BiroStatusChange.Database.SQL;
using BiroStatusChange.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

namespace BiroStatusChange.Commands
{
    class Status1
    {
        public static void Start()
        {
            Console.WriteLine("Iniciando processamento de pedido com status 1 na tabela OrderPreProduction");
            Console.WriteLine("");
            Console.WriteLine("Data Inicio Processamento:" + DateTime.Now.ToString());
            Console.WriteLine("");
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            int pageSize = 3000;

            var totalItems = Execute.Query.Instance.GetTotalItemsOrderPreProduction();
            var totalPages = Convert.ToInt32(Math.Ceiling((double)totalItems / pageSize));

            List<String> updates = new List<String>();
            var insert = @" update OrderPreProduction 
                                set conteudo ='{0}', idstatusorderpreproduction=2, CodigoMetodoTransporte={2}, NomeCliente='{3}', totalcartoes={4}, pesocartoes={5}, valortotalnotafiscal={6} 
                                where
                                    id={1}";

            for (int index = 1; index <= totalPages; index++)
            {
                Stopwatch stopWatch1 = new Stopwatch();
                stopWatch1.Start();

                var orderPreProductionList = Execute.Query.Instance.GetItemsOrderPreProduction(index, pageSize);

                orderPreProductionList = Utils.Instance.SetTrackingCode(orderPreProductionList);
                orderPreProductionList = Utils.Instance.SetCodigoMetodoEntrega(orderPreProductionList);
                orderPreProductionList = Utils.Instance.SetTemplateAndNomeCliente(orderPreProductionList);
                orderPreProductionList = Utils.Instance.SetWeightCard(orderPreProductionList);
                orderPreProductionList = Utils.Instance.SetProductsQuantity(orderPreProductionList);
                orderPreProductionList = Utils.Instance.SetInvoiceTotalValue(orderPreProductionList);


                if (orderPreProductionList.Count > 0)
                {  
                    updates.Add(String.Join(";", orderPreProductionList.Select(o =>
                                    String.Format(insert, JsonConvert.SerializeObject(o.Conteudo), o.Id, o.Conteudo.MetodoTransporte, o.Conteudo.NomeCliente, o.TotalCartoes,
                                        o.PesoCartoes.ToString("F", CultureInfo.InvariantCulture),
                                        o.ValorTotalNotaFiscal.ToString("F", CultureInfo.InvariantCulture))).ToList())
                                );
                }

                stopWatch1.Stop();
                TimeSpan ts1 = stopWatch1.Elapsed;
                Console.WriteLine(String.Format("Tempo de Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts1.Hours, ts1.Minutes, ts1.Seconds, ts1.Milliseconds / 10));
            }


            Execute.Query.Instance.UpdateOrderPreProduction(updates);

            stopWatch.Stop();
            TimeSpan ts = stopWatch.Elapsed;
            Console.WriteLine(String.Format("Tempo de Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));
            Console.WriteLine("Data Fim Processamento:" + DateTime.Now.ToString());
        }

    }
}

﻿using System;
using System.Diagnostics;

namespace BiroStatusChange.Commands
{
    class Status4
    {
        public static void Start()
        {
            Console.WriteLine("Data Inicio Processamento:" + DateTime.Now.ToString());
            Console.WriteLine("");
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            BiroUtils.Controllers.CMD.Instance.Start();
            stopWatch.Stop();
            TimeSpan ts = stopWatch.Elapsed;
            Console.WriteLine(String.Format("Data Fim Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));

            Console.ReadKey();
        }
    }
}

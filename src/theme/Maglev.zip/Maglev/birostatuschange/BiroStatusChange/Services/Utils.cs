﻿using BiroStatusChange.App_Start;
using BiroStatusChange.Database.SQL;
using BiroUtils.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BiroStatusChange.Services
{
    class Utils
    {
        private static Utils oUtils;

        public static Utils Instance { get { oUtils = oUtils ?? new Utils(); return oUtils; } }

        private ConfigurationJSON.Configuration ApplicationSetting;
        private decimal InvoiceTotalValue { get; set; }
        private decimal CardWeight { get; set; }

        public Utils()
        {
            this.ApplicationSetting = App_Start.Run.ConfigurationJSON().configuration;
            InvoiceTotalValue = ApplicationSetting.InvoiceTotalValue;
            CardWeight = ApplicationSetting.CardWeight;
        }

        public List<Models.OrderPreProduction> SetTrackingCode(List<Models.OrderPreProduction> list)
        {

            foreach (var items in list.Where(x => x.Conteudo.Conteudo.TrackingCode == null || x.Conteudo.Conteudo.TrackingCode == "")
                                        .GroupBy(x => new
                                        {
                                            x.Conteudo.Conteudo.IdPedido,
                                            x.Conteudo.Conteudo.Endereco.Destinatario.CEP,
                                            x.Conteudo.Conteudo.Endereco.Destinatario.Complemento,
                                            x.Conteudo.Conteudo.Endereco.Destinatario.Numero
                                        }))
            {
                items.Select(x => { x.Conteudo.Conteudo.TrackingCode = Convert.ToString(String.Concat(
                    ApplicationSetting.TrackingCodePrefixBegin,
                    x.Conteudo.Conteudo.IdPedidoItem,
                    x.Conteudo.Plataforma,
                    ApplicationSetting.TrackingCodePrefixEnd
                    )); return x; }).ToList();
            }

            return list;
        }

        public List<Models.OrderPreProduction> SetCodigoMetodoEntrega(List<Models.OrderPreProduction> list)
        {
            List<Int64> ItemsWithError = new List<Int64>();

            foreach (var items in list.GroupBy(x => x.Conteudo.Conteudo.Endereco.Destinatario.CEP))
            {
                var result = Execute.Query.Instance.GetCodigoMetodoEntrega(Convert.ToInt64(items.Key.Replace("-", "")));

                if (result != null)
                {
                    if (result.CodigoMetodoTransporte != 0 && result.CodigoMetodoTransporte != null)
                    {
                        items.Select(x =>
                        {
                            x.Conteudo.MetodoTransporte = result.CodigoMetodoTransporte.ToString(); return x;
                        }).ToList();
                    }
                    else
                    {
                        items.Select(x =>
                        {
                            x.Conteudo.MetodoTransporte = "123456"; return x;
                        }).ToList();

                        //ItemsWithError.AddRange(items.Select(x => x.Id).ToList());
                    }
                }
                else
                {
                    //ItemsWithError.AddRange(items.Select(x => x.Id).ToList());
                }
            }

            if (ItemsWithError.Count > 0)
            {
                Logs.Instance.RegisterLog("", "warning", "Não foi possível definir o tipo e metodo de transporte pelo CEP do destinatario", "SetCodigoMetodoEntrega", "procurar pelo ids: " + String.Join(",", ItemsWithError));
                var OrderPreProductionListWithoutError = list.Where(x => !ItemsWithError.Contains(x.Id)).ToList();
                return OrderPreProductionListWithoutError;
            }

            return list;

        }

        public List<Models.OrderPreProduction> SetTemplateAndNomeCliente(List<Models.OrderPreProduction> list)
        {
            List<Int64> ItemsWithError = new List<Int64>();

            foreach (var items in list.GroupBy(x => x.Conteudo.CodigoCanal))
            {
                var result = Execute.Query.Instance.GetTemplateAndNomeCliente(Convert.ToInt64(items.Key));

                if (result != null)
                {
                    if (result.NomeCliente != " " && result.NomeCliente != null)
                    {
                        items.Select(x =>
                        {
                            x.Conteudo.NomeCliente = result.NomeCliente
                            
                            ; return x;
                        }).ToList();

                        items.Select(x =>
                        {
                            x.Conteudo.Template = result.NomeTemplate
                            
                            ; return x;
                        }).ToList();

                    }
                    else
                    {
                        ItemsWithError.AddRange(items.Select(x => x.Id).ToList());
                    }
                }
                else
                {
                    ItemsWithError.AddRange(items.Select(x => x.Id).ToList());
                }
            }

            if (ItemsWithError.Count > 0)
            {
                Logs.Instance.RegisterLog("", "warning", "Não foi possível definir o tipo e metodo de transporte pelo CEP do destinatario", "SetCodigoMetodoEntrega", "procurar pelo ids: " + String.Join(",", ItemsWithError));
                var OrderPreProductionListWithoutError = list.Where(x => !ItemsWithError.Contains(x.Id)).ToList();
                return OrderPreProductionListWithoutError;
            }

            return list;

        }

        public List<Models.OrderPreProduction> SetInvoiceTotalValue(List<Models.OrderPreProduction> listOrderpreProduction)
        {
            foreach (var items in listOrderpreProduction.GroupBy(x => x.Conteudo.Conteudo.TrackingCode))
            {
                items.Select(x => { x.ValorTotalNotaFiscal = (items.Count() * InvoiceTotalValue); return x; }).ToList();
            }
            return listOrderpreProduction;
        }

        public List<Models.OrderPreProduction> SetProductsQuantity(List<Models.OrderPreProduction> listOrderpreProduction)
        {
            foreach (var items in listOrderpreProduction.GroupBy(x => x.Conteudo.Conteudo.TrackingCode))
            {
                items.Select(x => { x.TotalCartoes = items.Count(); return x; }).ToList();
            }
            return listOrderpreProduction;
        }

        public List<Models.OrderPreProduction> SetWeightCard(List<Models.OrderPreProduction> listOrderpreProduction)
        {
            foreach (var items in listOrderpreProduction.GroupBy(x => x.Conteudo.Conteudo.TrackingCode))
            {
                items.Select(x => { x.PesoCartoes = (items.Count() * CardWeight); return x; }).ToList();
            }
            return listOrderpreProduction;
        }



    }
}

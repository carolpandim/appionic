﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.OsType
{
    public class OSTypeListResponse
    {
        public int IdOsType { get; set; }
        public string Produto { get; set; }
        public string Codigo { get; set; }
        public Boolean? Ativo { get; set; }
        public Boolean? B2b { get; set; }
    }
}

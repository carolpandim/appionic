﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.OsType
{
    public class OSTypeRequest
    {
        public Int32? IdOsType { get; set; }
        public Boolean? B2b { get; set; }
        public Boolean? Ativo { get; set; }
    }
}

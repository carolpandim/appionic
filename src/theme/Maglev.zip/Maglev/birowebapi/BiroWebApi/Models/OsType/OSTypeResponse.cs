﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.OsType
{
    public class OsTypeResponse
    {
		public Int32? IdOsType { get; set; }
		public String Produto { get; set; }
		public String Codigo { get; set; }
        public String Template { get; set; }
        public String Arquivo { get; set; }
        public Boolean B2b { get; set; }
        public Boolean Ativo { get; set; }
        public Boolean PreImpresso { get; set; }
    }
}

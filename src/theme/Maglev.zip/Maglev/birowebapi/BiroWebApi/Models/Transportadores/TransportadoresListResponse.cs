﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Transportadores
{
    public class TransportadoresListResponse
    {
        public Int32 IdTransportador { get; set; }
        public String Nome { get; set; }
        public Boolean? Ativo { get; set; }
    }
}

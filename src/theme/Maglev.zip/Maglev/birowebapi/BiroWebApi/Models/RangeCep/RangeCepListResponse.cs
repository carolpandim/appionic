﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.RangeCep
{
    public class RangeCepListResponse
    {
        public String IdRangeCep { get; set; }
        public String CepInicio { get; set; }
        public String CepFim { get; set; }
        public String Transportador { get; set; }
        public String Metodo { get; set; }
        public String TipoEntrega { get; set; }

    }
}

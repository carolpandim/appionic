﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.RangeCep
{
    public class RangeCepRequest
    {
        public String Cep { get; set; }
        public Int32? Transportador { get; set; }
        public Int32? TipoEntrega { get; set; }
        public Int32? Metodo { get; set; }
    }
}

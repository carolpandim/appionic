﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.RangeCep
{
    public class RangeCepDetailResponse
    {
        public String IdRangeCep { get; set; }
        public String CepInicio { get; set; }
        public String CepFim { get; set; }
        public Int32 IdTransportador { get; set; }
        public Int32 IdTransportadorMetodo { get; set; }
        public Int32 IdTipoEntrega { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.DataBase.SQL.DataModels
{
    public class Parameters
    {
        public String FieldName { get; set; }
        public SqlDbType DataType { get; set; }
        public Object Value { get; set; }
    }
}

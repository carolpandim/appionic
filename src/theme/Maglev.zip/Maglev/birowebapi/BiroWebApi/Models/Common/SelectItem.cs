﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Common
{
    public class SelectItem
    {
		public String Label { get; set; }
		public String Value { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Common
{
    public class JsonText
    {
        public Int64 IdOs { get; set; }
        public Int64 IdPedido { get; set; }
        public Int64 IdPedidoItem { get; set; }
        public String TrackingCode { get; set; }
        public Int64 CodigoCartao { get; set; }
        public String Imagem { get; set; }
        public String Logo { get; set; }
        public String EnderecoRemetente { get; set; }
        public String NumeroRemetente { get; set; }
        public String ComplementoRemetente { get; set; }
        public String BairroRemetente { get; set; }
        public String CepRemetente { get; set; }
        public String CidadeRemetente { get; set; }
        public String EstadoRemetente { get; set; }
        public String EnderecoDestinatario { get; set; }
        public String NumeroDestinatario { get; set; }
        public String ComplementoDestinatario { get; set; }
        public String BairroDestinatario { get; set; }
        public String CepDestinatario { get; set; }
        public String CidadeDestinatario { get; set; }
        public String EstadoDestinatario { get; set; }
        public String Mensagem { get; set; }
        public String Titulo { get; set; }
        public String Assinatura { get; set; }
        public Int32? IdTransportador { get; set; }
        public Int32? IdTransportadorMetodo { get; set; }
        public String NomeRemetente { get; set; }
        public String NomeDestinatario { get; set; }
        public String NomeCartao { get; set; }
        public Int32? Customer_Shipping_Costs { get; set; }
        public String Sales_Channel { get; set; }
        public Boolean? Scheduled { get; set; }
        public DateTime? Shipped_Date { get; set; }
        public String Shipment_Order_Type { get; set; }
        public Int32? Delivery_Method_Id { get; set; }
        public DateTime? Estimated_Delivery_Date { get; set; }
        public String Email { get; set; }
        public String Phone { get; set; }
        public String CellPhone { get; set; }
        public Boolean? Is_Company { get; set; }
        public String Federal_Tax_Payer_Id { get; set; }
        public String Shipping_Country { get; set; }
        public Int32? Shipment_Order_Volume_Number { get; set; }
        public String Volume_Name { get; set; }
        public Decimal? Weight { get; set; }
        public String Volume_Type_Code { get; set; }
        public Decimal? Width { get; set; }
        public Decimal? Height { get; set; }
        public Decimal? Length { get; set; }
        public Int32? Products_Quantity { get; set; }
        public Boolean? Is_Icms_Exempt { get; set; }
        public String Invoice_Series { get; set; }
        public String Invoice_Key { get; set; }
        public DateTime? Invoice_Date { get; set; }
        public Decimal? Invoice_Total_Value { get; set; }
        public String CFOP { get; set; }
        public String Origin_WareHouse_Code { get; set; }
        public Decimal Saldo { get; set; }

    }
}

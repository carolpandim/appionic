﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models
{
    public class CustomReturn
    {
		public int TotalResultado { get; set; }
		public int TotalPaginas { get; set; }
		public Boolean Success { get; set; }
		public Object Data { get; set; }
		public String Message { get; set; }
	}
}

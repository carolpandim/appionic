﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.TransportadorMetodos
{
    public class TransportadorMetodosListResponse
    {
		public Int32 IdTransportadorMetodo { get; set; }
		public Int32? IdTransportador { get; set; }
		public String Nome { get; set; }
		public String Codigo { get; set; }
		public Int32? SLA { get; set; }
	}
}

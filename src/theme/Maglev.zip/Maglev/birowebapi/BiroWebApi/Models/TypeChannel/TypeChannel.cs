﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.TypeChannel
{
    public class TypeChannel
    {
        public Int64? IdOsTypechannel { get; set; }
        public Int64? IdOsType { get; set; }
        public String CodigoCanal { get; set; }
        public String Nome { get; set; }
    }
}

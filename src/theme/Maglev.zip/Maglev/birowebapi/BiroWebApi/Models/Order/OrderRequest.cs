﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Order
{
    public class OrderRequest
    {
		public string IdPedido { get; set; }
		public List<int> IdsProdutos { get; set; }
		public DateTime? DataInicio { get; set; }
		public DateTime? DataFim { get; set; }
        public Boolean? Deleted { get; set; }
    }
}

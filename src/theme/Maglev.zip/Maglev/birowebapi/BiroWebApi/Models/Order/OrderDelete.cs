﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Order
{
    public class OrderDelete
    {
        public Int64 IdPedido { get; set; }
        public Int64 IdPedidoItem { get; set; }
        public String Description { get; set; }
    }
}

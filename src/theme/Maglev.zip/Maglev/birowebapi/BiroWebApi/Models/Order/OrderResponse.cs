﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Order
{
    public class OrderResponse
    {
        public Int64 Id { get; set; }
        public Int64 IdPedido { get; set; }
        public Int64 IdPedidoItem { get; set; }
        public String Codigo { get; set; }
        public String Conteudo { get; set; }
        public DateTime DataPedido { get; set; }
        public DateTime DataImportacao { get; set; }
        public String Plataforma { get; set; }
        public Boolean Processed { get; set; }
        public Int64 IdOsType { get; set; }
        public String Produto { get; set; }
        public int TotalCartao { get; set; }
        public Boolean Deleted { get; set; }


    }
}

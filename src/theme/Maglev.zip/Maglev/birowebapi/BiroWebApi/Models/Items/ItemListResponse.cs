﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Items
{
    public class ItemListResponse
    {
        public Int64 IdItem { get; set; }
        public Int64 IdOs { get; set; }
        public Int64 IdPedido { get; set; }
        public Int64 IdPedidoItem { get; set; }
        public String TrackingCode { get; set; }
        public Int64 CodigoCartao { get; set; }
        public String Destinatario { get; set; }
        public String Cep { get; set; }
        public String Cidade { get; set; }
        public Int32 IdTransportador { get; set; }
        public Int32 Idtransportadormetodo { get; set; }
        public String TransportadorNome { get; set; }
        public String MetodoNome { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Os
{
    public class OsListResponse
    {
		public Int64 IdOs { get; set; }
        public DateTime? Data { get; set; }
        public String Produto { get; set; }
        public Int32 Cartoes { get; set; }
        public String Status { get; set; }
        public Int32 IdStatus { get; set; }
        public Boolean PossuiChip { get; set; }
        public Boolean Publicado { get; set; }
    }
}

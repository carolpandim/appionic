﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BiroWebApi.Models.Os
{
    public class OsRequest
    {
        public DateTime? DataInicio { get; set; }
        public DateTime? DataFim { get; set; }
        public Int32? IdOsType { get; set; }
        public Int64? IdOs { get; set; }
        public Int32? IdStatus { get; set; }
        public Int64? IdPedido { get; set; }
    }
}

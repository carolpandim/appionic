﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/RangeCep")]
    public class RangeCepController : BaseController
    {
        public RangeCepController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("list/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int32 pageIndex, Int32 pageSize, [FromBody]  JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.RangeCep.RangeCepRequest rangecepRequest = data.ToObject<Models.RangeCep.RangeCepRequest>();

            List<Models.RangeCep.RangeCepListResponse> rangeCepListResponse = new List<Models.RangeCep.RangeCepListResponse>();

            List<String> fieldFilter = new List<string>();

            List<SqlParameter> filter = new List<SqlParameter>();

            if (!String.IsNullOrEmpty(rangecepRequest.Cep))
            {
                fieldFilter.Add(" @cep between cepinicio and cepfim ");
                filter.Add(new SqlParameter() { ParameterName = "@cep", SqlDbType = SqlDbType.VarChar, Value = rangecepRequest.Cep.Replace("-", "") });
            }

            if (rangecepRequest.TipoEntrega.HasValue)
            {
                fieldFilter.Add(" t1.idTipoEntrega = @idTipoEntrega ");
                filter.Add(new SqlParameter() { ParameterName = "@idTipoEntrega", SqlDbType = SqlDbType.Int, Value = rangecepRequest.TipoEntrega.Value });
            }

            if (rangecepRequest.Transportador.HasValue)
            {
                fieldFilter.Add(" t1.IdTransportador = @IdTransportador ");
                filter.Add(new SqlParameter() { ParameterName = "@IdTransportador", SqlDbType = SqlDbType.Int, Value = rangecepRequest.Transportador.Value });
            }

            if (rangecepRequest.Metodo.HasValue)
            {
                fieldFilter.Add(" t1.IdTransportadorMetodo = @IdTransportadorMetodo ");
                filter.Add(new SqlParameter() { ParameterName = "@IdTransportadorMetodo", SqlDbType = SqlDbType.Int, Value = rangecepRequest.Metodo.Value });
            }

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
										from 
											   rangecep (nolock) t1
                                     ";

                    if (fieldFilter.Count() > 0)
                    {
                        queryTotal += " where " + String.Join(" AND ", fieldFilter);
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        if (filter.Count() > 0)
                        {
                            comm.Parameters.AddRange(filter.ToArray());
                        }

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());

                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }

                        comm.Parameters.Clear();
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"
                                        select                                                
	                                           t1.idrangecep,
	                                           t1.cepinicio,
	                                           t1.cepfim,
	                                           t2.nome as tipoentrega,
	                                           t4.nome as transportador,
	                                           t3.nome as metodo
                                        from 
                                               rangecep t1
                                               inner join tiposEntregas t2 on t1.idtipoentrega = t2.idtipoentrega
                                               inner join transportadorMetodos t3 on t1.idtransportadormetodo = t3.idtransportadormetodo
                                               inner join transportadores t4 on t1.idtransportador = t4.idtransportador
                                         ";

                        if (fieldFilter.Count() > 0)
                        {
                            query += " where " + String.Join(" AND ", fieldFilter);
                        }

                        query += " order by t1.cepinicio asc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            if (filter.Count() > 0)
                            {
                                comm.Parameters.Clear();
                                comm.Parameters.AddRange(filter.ToArray());
                            }

                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                rangeCepListResponse.Add(new Models.RangeCep.RangeCepListResponse()
                                {
                                    IdRangeCep = reader["idrangecep"].ToString(),
                                    CepInicio = reader["cepinicio"].ToString(),
                                    CepFim = reader["cepfim"].ToString(),
                                    Metodo = reader["metodo"].ToString(),
                                    TipoEntrega = reader["tipoentrega"].ToString(),
                                    Transportador = reader["transportador"].ToString()
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = rangeCepListResponse;
                returnData.Success = true;

            }
            catch (Exception ex)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = false;
            }

            return returnData;

        }


        [HttpGet]
        [Route("detail/{idrangecep}")]
        public Models.CustomReturn Detail(String idrangecep)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            Models.RangeCep.RangeCepDetailResponse data = new Models.RangeCep.RangeCepDetailResponse();
            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT 
                                    idrangecep,
                                    cepinicio,
                                    cepfim,
                                    idtipoentrega,
                                    idtransportador,
                                    idtransportadormetodo
                                FROM rangecep
                                where idrangecep=@idrangecep";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idrangecep", SqlDbType = SqlDbType.VarChar, Value = idrangecep });

                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            data.IdRangeCep = reader["idrangecep"].ToString();

                            if (reader["cepinicio"].ToString().Count() == 7)
                                data.CepInicio = "0" + reader["cepinicio"].ToString();
                            else
                                data.CepInicio = reader["cepinicio"].ToString();

                            if (reader["cepFim"].ToString().Count() == 7)
                                data.CepFim = "0" + reader["cepFim"].ToString();
                            else
                                data.CepFim = reader["cepFim"].ToString();

                            data.IdTipoEntrega = Convert.ToInt32(reader["idtipoentrega"]);
                            data.IdTransportador = Convert.ToInt32(reader["idtransportador"]);
                            data.IdTransportadorMetodo = Convert.ToInt32(reader["idtransportadormetodo"]);
                        }

                    }


                    conn.Close();

                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }

        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Detail([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.RangeCep.RangeCepDetailResponse dataPost = postData.ToObject<Models.RangeCep.RangeCepDetailResponse>();

            List<SqlParameter> filter = new List<SqlParameter>();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "";

                    if (!String.IsNullOrEmpty(dataPost.IdRangeCep))
                    {
                        query = "Update rangecep set cepinicio = @cepinicio, cepfim = @cepfim, idtransportador=@idtransportador, idtransportadormetodo = @idtransportadormetodo, idtipoentrega = @idtipoentrega where idrangecep = @idrangecep ";

                        filter.Add(new SqlParameter() { ParameterName = "@idrangecep", SqlDbType = SqlDbType.VarChar, Value = dataPost.IdRangeCep.ToString() });
                    }
                    else
                    {
                        query = "insert rangecep(idrangecep,cepinicio,cepfim,idtransportador,idtransportadormetodo,idtipoentrega) values (@idrangecep,@cepinicio,@cepfim,@idtransportador,@idtransportadormetodo,@idtipoentrega)";

                        filter.Add(new SqlParameter() { ParameterName = "@idrangecep", SqlDbType = SqlDbType.VarChar, Value = Guid.NewGuid().ToString() });
                    }

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        filter.Add(new SqlParameter() { ParameterName = "@cepInicio", SqlDbType = SqlDbType.VarChar, Value = dataPost.CepInicio.Replace("-", "") });
                        filter.Add(new SqlParameter() { ParameterName = "@cepFim", SqlDbType = SqlDbType.VarChar, Value = dataPost.CepFim.Replace("-", "") });
                        filter.Add(new SqlParameter() { ParameterName = "@idTipoEntrega", SqlDbType = SqlDbType.Int, Value = dataPost.IdTipoEntrega });
                        filter.Add(new SqlParameter() { ParameterName = "@IdTransportador", SqlDbType = SqlDbType.Int, Value = dataPost.IdTransportador });
                        filter.Add(new SqlParameter() { ParameterName = "@IdTransportadorMetodo", SqlDbType = SqlDbType.Int, Value = dataPost.IdTransportadorMetodo });

                        comm.Parameters.AddRange(filter.ToArray());

                        comm.ExecuteScalar();
                    }

                    conn.Close();
                }

                returnData.Message = "Range de Cep Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }


        [HttpDelete]
        [Route("delete/{idrangecep}")]
        public Models.CustomReturn Remove(String idrangecep)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "delete from rangecep where idrangecep = @rangecep ";


                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@rangecep", SqlDbType = SqlDbType.VarChar, Value = idrangecep });

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "Range de Cep excluído!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }
    }
}
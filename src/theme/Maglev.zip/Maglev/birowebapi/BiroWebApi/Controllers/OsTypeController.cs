﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/OsType")]
    public class OsTypeController : BaseController
    {
        public OsTypeController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("list/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int32 pageIndex, Int32 pageSize, [FromBody]  JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.OsType.OSTypeRequest  osTypeRequest = data.ToObject<Models.OsType.OSTypeRequest>();
            List<Models.OsType.OSTypeListResponse> osTypeListResponse = new List<Models.OsType.OSTypeListResponse>();

            List<String> fieldFilter = new List<string>();

            List<SqlParameter> filter = new List<SqlParameter>();

            if (osTypeRequest.IdOsType.HasValue)
            {
                fieldFilter.Add(" t1.idOsType = @idOsType ");
                filter.Add(new SqlParameter() { ParameterName = "@idOsType", SqlDbType = SqlDbType.Int, Value = osTypeRequest.IdOsType });
            }
            if (osTypeRequest.B2b.HasValue)
            {
                fieldFilter.Add(" t1.B2b = @b2b ");
                filter.Add(new SqlParameter() { ParameterName = "@b2b", SqlDbType = SqlDbType.Bit, Value = osTypeRequest.B2b });
            }
            
            if (osTypeRequest.Ativo.HasValue)
            {
                fieldFilter.Add(" t1.ativo = @ativo ");
                filter.Add(new SqlParameter() { ParameterName = "@ativo", SqlDbType = SqlDbType.Bit, Value = osTypeRequest.Ativo.Value });
            }

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
										from 
											   ostype (nolock) t1
                                     ";

                    if (fieldFilter.Count() > 0)
                    {
                        queryTotal += " where " + String.Join(" AND ", fieldFilter);
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        if (filter.Count() > 0)
                        {
                            comm.Parameters.AddRange(filter.ToArray());
                        }

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }

                        comm.Parameters.Clear();
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"
                                        SELECT 
	                                        t1.codigo,
                                            t1.idostype,
                                            t1.produto,
                                            t1.ativo,
                                            t1.b2b
                                        FROM 
	                                        ostype t1 (nolock)  ";

                        if (fieldFilter.Count() > 0)
                        {
                            query += " where " + String.Join(" AND ", fieldFilter);
                        }

                        query += " order by produto asc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            if (filter.Count() > 0)
                            {
                                comm.Parameters.Clear();
                                comm.Parameters.AddRange(filter.ToArray());
                            }

                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                osTypeListResponse.Add(new Models.OsType.OSTypeListResponse
                                {
                                    Codigo = reader["codigo"].ToString(),
                                    IdOsType = Convert.ToInt32(reader["idostype"]),
                                    Produto = reader["produto"].ToString(),
                                    Ativo = Convert.ToBoolean(reader["ativo"]),
                                    B2b = Convert.ToBoolean(reader["b2b"])
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = osTypeListResponse;
                returnData.Success = true;

            }
            catch (Exception ex)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = false;
            }

            return returnData;

        }

        [HttpGet]
        [Route("detail/{idostype}")]
        public Models.CustomReturn Detail(String idostype)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            Models.OsType.OsTypeResponse data = new Models.OsType.OsTypeResponse();
            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT * FROM ostype where idostype=@idostype";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idostype", SqlDbType = SqlDbType.VarChar, Value = idostype });

                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            data.IdOsType = Convert.ToInt32(reader["idostype"]);
                            data.Arquivo = reader["arquivo"].ToString();
                            data.Codigo = reader["codigo"].ToString();
                            data.Produto = reader["produto"].ToString();
                            data.Template = reader["template"].ToString();
                            data.B2b = Convert.ToBoolean(reader["b2b"]);
                            data.Ativo = Convert.ToBoolean(reader["ativo"]);
                            data.PreImpresso = Convert.ToBoolean(reader["preimpresso"]);
                        }

                    }


                    conn.Close();

                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }

        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Detail([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.OsType.OsTypeResponse dataPost = postData.ToObject<Models.OsType.OsTypeResponse>();

            List<SqlParameter> filter = new List<SqlParameter>();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "";

                    if (dataPost.IdOsType.HasValue)
                    {
                        query = "Update ostype set template = @template, arquivo = @arquivo, produto = @produto, codigo = @codigo, b2b=@b2b, ativo = @ativo, preimpresso=@preimpresso where idostype = @idostype ";
                        filter.Add(new SqlParameter() { ParameterName = "@idostype", SqlDbType = SqlDbType.Int, Value = dataPost.IdOsType });
                    }
                    else
                    {
                        query = "insert ostype(template,arquivo,produto,codigo,b2b,ativo,preimpresso) values (@template,@arquivo,@produto,@codigo,@b2b,@ativo,@preimpresso)";
                    }

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        filter.Add(new SqlParameter() { ParameterName = "@template", SqlDbType = SqlDbType.VarChar, Value = dataPost.Template });
                        filter.Add(new SqlParameter() { ParameterName = "@arquivo", SqlDbType = SqlDbType.VarChar, Value = dataPost.Arquivo });
                        filter.Add(new SqlParameter() { ParameterName = "@produto", SqlDbType = SqlDbType.VarChar, Value = dataPost.Produto });
                        filter.Add(new SqlParameter() { ParameterName = "@codigo", SqlDbType = SqlDbType.Int, Value = dataPost.Codigo });
                        filter.Add(new SqlParameter() { ParameterName = "@b2b", SqlDbType = SqlDbType.Bit, Value = dataPost.B2b });
                        filter.Add(new SqlParameter() { ParameterName = "@ativo", SqlDbType = SqlDbType.Bit, Value = dataPost.Ativo });
                        filter.Add(new SqlParameter() { ParameterName = "@preimpresso", SqlDbType = SqlDbType.Bit, Value = dataPost.PreImpresso });

                        comm.Parameters.AddRange(filter.ToArray());

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "OsType Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }


        [HttpDelete]
        [Route("delete/{idostype}")]
        public Models.CustomReturn Remove(String idostype)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "Update ostype set ativo=0 where idostype = @idostype ";


                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idostype", SqlDbType = SqlDbType.Int, Value = idostype });

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "OsType excluído!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }
    }
}
﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/Order")]
    public class OrderController : BaseController
    {
        public OrderController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("Search/{pageIndex}/{pageSize}")]
        public Models.CustomReturn Search(Int32 pageIndex, Int32 pageSize, [FromBody]  JObject data)
        {
            Models.Order.OrderRequest orderRequest = data.ToObject<Models.Order.OrderRequest>();

            List<Models.Order.OrderResponse> listOrderResponse = new List<Models.Order.OrderResponse>();

            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
                                        FROM 
                                            OrderPreProduction t1
		                                    left join ostypeChannels t2 on t1.codigo = t2.codigocanal
                                            left join osType t3 on t3.idostype = t2.idostype 
										where
											   t1.processed = 0 and t1.deleted = 0
                                     ";

                    string filters = "";

                    if (!String.IsNullOrEmpty(orderRequest.IdPedido))
                    {
                        filters += " and t1.idpedido = " + orderRequest.IdPedido + " ";
                    }

                    if (orderRequest.IdsProdutos != null)
                    {
                        filters += " and t2.idOsType in (" + string.Join(',', orderRequest.IdsProdutos) + ") ";
                    }

                    if (orderRequest.Deleted.HasValue)
                    {
                        filters += " and t2.deleted = "+ (orderRequest.Deleted.HasValue ? "1" : "0") +" ";
                    }

                    

                    if (orderRequest.DataInicio.HasValue && orderRequest.DataFim.HasValue && orderRequest.DataFim >= orderRequest.DataInicio)
                    {
                        filters += " and cast(t1.dataimportacao as date) between '" + orderRequest.DataInicio.Value + "' and '" + orderRequest.DataFim.Value + "' ";
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal + filters, conn))
                    {

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"select 
                                        t1.id 
                                        ,t1.idpedido             
                                        ,t1.idpedidoitem 
                                        ,t1.codigo
                                        ,cast(t1.datapedido as date) as datapedido               
                                        ,cast(t1.dataimportacao as date) as dataimportacao
                                        ,t1.plataforma 
		                                ,t2.idostype
                                        ,t1.processed
                                        ,t2.nome as produto,
                                        t1.deleted
	                                from 
                                        OrderPreProduction t1
		                                left join ostypeChannels t2 on t1.codigo = t2.codigocanal
                                        left join osType t3 on t3.idostype = t2.idostype 
                                    where
									   t1.processed = 0 and t1.deleted = 0
									";

                        query += filters;

                        query += @"order by 
									    t1.id  asc
								        OFFSET (({0} - 1) * {1}) ROWS
								        FETCH NEXT {1} ROWS ONLY
								   ";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            var reader = comm.ExecuteReader();

                            Models.Order.OrderResponse item = null;

                            while (reader.Read())
                            {
                                item = new Models.Order.OrderResponse();

                                item.Id = Convert.ToInt64(reader["id"]);
                                item.IdPedido = Convert.ToInt64(reader["idPedido"]);
                                item.IdPedidoItem = Convert.ToInt64(reader["idpedidoitem"]);
                                item.Codigo = reader["codigo"].ToString();
                                item.DataPedido = Convert.ToDateTime(reader["datapedido"].ToString());
                                item.DataImportacao = Convert.ToDateTime(reader["dataimportacao"].ToString());
                                item.Plataforma = reader["plataforma"].ToString();
                                item.Processed = Convert.ToBoolean(reader["processed"]);
                                if (!String.IsNullOrEmpty(reader["idostype"].ToString())) { item.IdOsType = Convert.ToInt64(reader["idostype"]); }
                                if (!String.IsNullOrEmpty(reader["produto"].ToString())) { item.Produto = reader["produto"].ToString(); }
                                item.Deleted = Convert.ToBoolean(reader["deleted"]);
                                listOrderResponse.Add(item);
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = listOrderResponse;
                returnData.Success = true;


            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro ao processar os dados";
            }

            return returnData;

        }

        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Save([FromBody] JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var orders = ((JArray)data.SelectToken("ids")).ToList();
                var ids = String.Join(",", orders);

                var result = BiroUtils.Controllers.API.Instance.Process("API", ids);

                if (result.Success)
                {
                    returnData.Success = true;
                    returnData.Message = result.Message;
                }
                else
                {
                    returnData.Success = false;
                    returnData.Message = result.Message;
                }
                
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro ao processar os dados";
            }

            return returnData;

        }

        [HttpDelete]
        [Route("Delete")]
        public Models.CustomReturn Delete([FromBody] JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                Models.Order.OrderDelete orderDelete = data.ToObject<Models.Order.OrderDelete>();

                String query = "update OrderPreProduction set deleted=1, description = @description, usuario=@usuario where ";

                if(orderDelete.IdPedidoItem > 0)
                {
                    query += String.Format(" idPedidoItem = {0}", orderDelete.IdPedidoItem);
                }
                else
                {
                    query += String.Format(" idPedido = {0}", orderDelete.IdPedido);
                }

                using(SqlConnection conn = new SqlConnection(configuration.GetConnectionString("BiroProd")))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@description", SqlDbType = SqlDbType.VarChar, Value = orderDelete.Description });
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@usuario", SqlDbType = SqlDbType.VarChar, Value = "" });

                        var reader = comm.ExecuteScalar();
                    }

                    conn.Close();
                }

                returnData.Success = true;
                returnData.Message = "Pedido excluído com sucesso!";


            }
            catch(Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro ao excluir a informação";
            }

            return returnData;
        }

        [HttpGet]
        [Route("Get/{idOrderProduction}")]
        public Models.CustomReturn Get(Int64 idOrderProduction)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            try
            {
                using(SqlConnection conn = new SqlConnection(configuration.GetConnectionString("BiroRead")))
                {
                    conn.Open();
                    using (SqlCommand comm = new SqlCommand(String.Format("Select * from OrderPreProduction (nolock) where id = {0}", idOrderProduction), conn))
                    {
                        var reader = comm.ExecuteReader();

                        Models.Order.OrderDetail item = new Models.Order.OrderDetail();

                        while (reader.Read())
                        {
                            
                            item.Id = Convert.ToInt64(reader["id"]);
                            item.IdPedido = Convert.ToInt64(reader["idPedido"]);
                            item.IdPedidoItem = Convert.ToInt64(reader["idpedidoitem"]);
                            item.Codigo = reader["codigo"].ToString();
                            item.Conteudo = reader["conteudo"].ToString();
                            item.DataPedido = Convert.ToDateTime(reader["datapedido"].ToString());
                            item.DataImportacao = Convert.ToDateTime(reader["dataimportacao"].ToString());
                            item.Plataforma = reader["plataforma"].ToString();
                            item.Processed = Convert.ToBoolean(reader["processed"]);
                            item.Deleted = Convert.ToBoolean(reader["deleted"]);

                        }

                        returnData.Data = item;
                        returnData.Message = "Dados processados";
                        returnData.Success = true;
                    }

                    conn.Close();
                }

            }catch(Exception ex)
            {
                returnData.Message = "Ocorreu um erro ao processar os dados";
                returnData.Success = false;
            }

            return returnData;
        }

    }
}
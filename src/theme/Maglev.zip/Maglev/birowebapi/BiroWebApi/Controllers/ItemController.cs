﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/item")]
    public class ItemController : BaseController
    {
        public ItemController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("list/{idOs}/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int64 idOs, Int32 pageIndex, Int32 pageSize)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Items.ItemListResponse> itemListResponse = new List<Models.Items.ItemListResponse>();

            List<String> fieldFilter = new List<string>();

            List<SqlParameter> filter = new List<SqlParameter>();


            fieldFilter.Add(" i.idOs = @idOs ");
            filter.Add(new SqlParameter() { ParameterName = "@idOs", SqlDbType = SqlDbType.BigInt, Value = idOs });

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
										from 
											   items (nolock) i
                                     ";

                    if (fieldFilter.Count() > 0)
                    {
                        queryTotal += " where " + String.Join(" AND ", fieldFilter);
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        if (filter.Count() > 0)
                        {
                            comm.Parameters.AddRange(filter.ToArray());
                        }

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }

                        comm.Parameters.Clear();
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"
                                        SELECT 
	                                        i.cepdestinatario,
	                                        i.cidadedestinatario,
	                                        i.CodigoCartao,
	                                        i.nomedestinatario,
	                                        i.idos,
	                                        i.iditem,
	                                        i.idpedido,
	                                        i.idpedidoitem,
	                                        i.idtransportador,
	                                        i.idtransportadormetodo,
	                                        i.trackingcode,
	                                        t.nome as transportadorNome,
	                                        m.nome as metodoNome
                                        FROM 
	                                        items as i (nolock)
	                                        left join transportadores t on i.idtransportador = t.idtransportador
	                                        left join transportadorMetodos m on m.idtransportadormetodo = i.idtransportadormetodo ";

                        if (fieldFilter.Count() > 0)
                        {
                            query += " where " + String.Join(" AND ", fieldFilter);
                        }

                        query += " order by cepdestinatario asc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            if (filter.Count() > 0)
                            {
                                comm.Parameters.Clear();
                                comm.Parameters.AddRange(filter.ToArray());
                            }

                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                var aux = new Models.Items.ItemListResponse();

                                aux.Cep = reader["cepdestinatario"].ToString();
                                aux.Cidade = reader["cidadedestinatario"].ToString();
                                aux.CodigoCartao = Convert.ToInt64(reader["CodigoCartao"]);
                                aux.Destinatario = reader["nomedestinatario"].ToString();
                                aux.IdOs = Convert.ToInt64(reader["idos"]);
                                aux.IdItem = Convert.ToInt64(reader["iditem"]);
                                aux.IdPedido = Convert.ToInt64(reader["idpedido"]);
                                aux.IdPedidoItem = Convert.ToInt64(reader["idpedidoitem"]);
                                aux.IdTransportador = Convert.ToInt32(reader["idtransportador"]);
                                aux.Idtransportadormetodo = Convert.ToInt32(reader["idtransportadormetodo"]);                                
                                aux.TrackingCode = reader["trackingcode"].ToString();
                                if (!String.IsNullOrEmpty(reader["transportadorNome"].ToString()))
                                { aux.TransportadorNome = reader["transportadorNome"].ToString();} else { aux.TransportadorNome = ""; }
                                if (!String.IsNullOrEmpty(reader["metodoNome"].ToString()))
                                { aux.MetodoNome = reader["metodoNome"].ToString(); } else { aux.MetodoNome = ""; }

                                itemListResponse.Add(aux);
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = itemListResponse;
                returnData.Success = true;

            }
            catch (Exception ex)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = false;
            }

            return returnData;

        }


        [HttpGet]
        [Route("detail/{iditem}")]
        public Models.CustomReturn Detail(Int64 idItem)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            Models.Items.ItemsDetailResponse data = new Models.Items.ItemsDetailResponse();
            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT * FROM items where iditem=@iditem";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@iditem", SqlDbType = SqlDbType.BigInt, Value = idItem });

                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            data.Assinatura = reader["assinatura"].ToString();
                            data.BairroDestinatario = reader["bairrodestinatario"].ToString();
                            data.BairroRemetente = reader["BairroRemetente"].ToString();
                            data.CellPhone = reader["CellPhone"].ToString();
                            data.CepDestinatario = reader["CepDestinatario"].ToString();
                            data.CepRemetente = reader["CepRemetente"].ToString();
                            data.CFOP = reader["CFOP"].ToString();
                            data.CidadeDestinatario = reader["CidadeDestinatario"].ToString();
                            data.CidadeRemetente = reader["CidadeRemetente"].ToString();
                            data.CodigoCartao = Convert.ToInt64(reader["CodigoCartao"].ToString());
                            data.ComplementoDestinatario = reader["ComplementoDestinatario"].ToString();
                            data.ComplementoRemetente = reader["ComplementoRemetente"].ToString();

                            if (!String.IsNullOrEmpty(reader["Customer_Shipping_Costs"].ToString()))
                            {
                                data.Customer_Shipping_Costs = Convert.ToInt32(reader["Customer_Shipping_Costs"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Delivery_Method_Id"].ToString()))
                            {
                                data.Delivery_Method_Id = Convert.ToInt32(reader["Delivery_Method_Id"].ToString());
                            }

                            data.Email = reader["Email"].ToString();
                            data.EnderecoDestinatario = reader["EnderecoDestinatario"].ToString();
                            data.EnderecoRemetente = reader["EnderecoRemetente"].ToString();
                            data.EstadoDestinatario = reader["EstadoDestinatario"].ToString();
                            data.EstadoRemetente = reader["EstadoRemetente"].ToString();

                            if (!String.IsNullOrEmpty(reader["Estimated_Delivery_Date"].ToString()))
                            {
                                data.Estimated_Delivery_Date = Convert.ToDateTime(reader["Estimated_Delivery_Date"].ToString());
                            }

                            data.Federal_Tax_Payer_Id = reader["Federal_Tax_Payer_Id"].ToString();

                            if (!String.IsNullOrEmpty(reader["Height"].ToString()))
                            {
                                data.Height = Convert.ToDecimal(reader["Height"].ToString());
                            }

                            data.IdItem = Convert.ToInt64(reader["IdItem"].ToString());
                            data.IdOs = Convert.ToInt64(reader["IdOs"].ToString());
                            data.IdPedido = Convert.ToInt64(reader["IdPedido"].ToString());
                            data.IdPedidoItem = Convert.ToInt64(reader["IdPedidoItem"].ToString());

                            if (!String.IsNullOrEmpty(reader["IdTransportador"].ToString()))
                            {
                                data.IdTransportador = Convert.ToInt32(reader["IdTransportador"].ToString());
                            }

                            data.Imagem = reader["Imagem"].ToString();

                            if (!String.IsNullOrEmpty(reader["Invoice_Date"].ToString()))
                            {
                                data.Invoice_Date = Convert.ToDateTime(reader["Invoice_Date"].ToString());
                            }

                            data.Invoice_Key = reader["Invoice_Key"].ToString();
                            data.Invoice_Series = reader["Invoice_Series"].ToString();
                            if (!String.IsNullOrEmpty(reader["Invoice_Total_Value"].ToString()))
                            {
                                data.Invoice_Total_Value = Convert.ToDecimal(reader["Invoice_Total_Value"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Is_Company"].ToString()))
                            {
                                data.Is_Company = Convert.ToBoolean(reader["Is_Company"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Is_Icms_Exempt"].ToString()))
                            {
                                data.Is_Icms_Exempt = Convert.ToBoolean(reader["Is_Icms_Exempt"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Length"].ToString()))
                            {
                                data.Length = Convert.ToDecimal(reader["Length"].ToString());
                            }

                            data.Logo = reader["Logo"].ToString();
                            data.Mensagem = reader["Mensagem"].ToString();
                            data.NomeCartao = reader["NomeCartao"].ToString();
                            data.NomeDestinatario = reader["NomeDestinatario"].ToString();
                            data.NomeRemetente = reader["NomeRemetente"].ToString();
                            data.NumeroDestinatario = reader["NumeroDestinatario"].ToString();
                            data.NumeroRemetente = reader["NumeroRemetente"].ToString();
                            data.Origin_WareHouse_Code = reader["Origin_WareHouse_Code"].ToString();
                            data.Phone = reader["Phone"].ToString();

                            if (!String.IsNullOrEmpty(reader["Products_Quantity"].ToString()))
                            {
                                data.Products_Quantity = Convert.ToInt32(reader["Products_Quantity"].ToString());
                            }

                            data.Sales_Channel = reader["Sales_Channel"].ToString();

                            if (!String.IsNullOrEmpty(reader["Scheduled"].ToString()))
                            {
                                data.Scheduled = Convert.ToBoolean(reader["Scheduled"].ToString());
                            }

                            data.Shipment_Order_Type = reader["Shipment_Order_Type"].ToString();

                            if (!String.IsNullOrEmpty(reader["Shipment_Order_Volume_Number"].ToString()))
                            {
                                data.Shipment_Order_Volume_Number = Convert.ToInt32(reader["Shipment_Order_Volume_Number"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Shipped_Date"].ToString()))
                            {
                                data.Shipped_Date = Convert.ToDateTime(reader["Shipped_Date"].ToString());
                            }
                            data.Shipping_Country = reader["Shipping_Country"].ToString();
                            data.Titulo = reader["Titulo"].ToString();
                            data.TrackingCode = reader["TrackingCode"].ToString();
                            data.Volume_Name = reader["Volume_Name"].ToString();
                            data.Volume_Type_Code = reader["Volume_Type_Code"].ToString();

                            if (!String.IsNullOrEmpty(reader["Weight"].ToString()))
                            {
                                data.Weight = Convert.ToDecimal(reader["Weight"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["Width"].ToString()))
                            {
                                data.Width = Convert.ToDecimal(reader["Width"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["data_biro"].ToString()))
                            {
                                data.Data_Biro = Convert.ToDateTime(reader["data_biro"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["data_pedido"].ToString()))
                            {
                                data.Data_Pedido = Convert.ToDateTime(reader["data_pedido"].ToString());
                            }

                            if (!String.IsNullOrEmpty(reader["IdTransportadorMetodo"].ToString()))
                            {
                                data.IdTransportadorMetodo = Convert.ToInt32(reader["IdTransportadorMetodo"].ToString());
                            }
                        }

                    }


                    conn.Close();

                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }

        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Detail([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.Items.ItemsDetailResponse dataPost = postData.ToObject<Models.Items.ItemsDetailResponse>();

            List<SqlParameter> filter = new List<SqlParameter>();
            List<Models.DataBase.SQL.DataModels.Parameters> items = new List<Models.DataBase.SQL.DataModels.Parameters>();

            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "assinatura", DataType = SqlDbType.VarChar, Value = dataPost.Assinatura });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairrodestinatario", DataType = SqlDbType.VarChar,Value = dataPost.BairroDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairroremetente", DataType = SqlDbType.VarChar, Value = dataPost.BairroRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cellphone", DataType = SqlDbType.VarChar, Value = dataPost.CellPhone });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepdestinatario", DataType = SqlDbType.VarChar, Value = dataPost.CepDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepremetente", DataType = SqlDbType.VarChar, Value = dataPost.CepRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cfop", DataType = SqlDbType.VarChar, Value = dataPost.CFOP });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidadedestinatario", DataType = SqlDbType.VarChar, Value = dataPost.CidadeDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidaderemetente", DataType = SqlDbType.VarChar, Value = dataPost.CidadeRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "codigocartao", DataType = SqlDbType.BigInt, Value = dataPost.CodigoCartao });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementodestinatario", DataType = SqlDbType.VarChar, Value = dataPost.ComplementoDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementoremetente", DataType = SqlDbType.VarChar, Value = dataPost.ComplementoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "customer_shipping_costs", DataType = SqlDbType.Int, Value = dataPost.Customer_Shipping_Costs });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "delivery_method_id", DataType = SqlDbType.Int, Value = dataPost.Delivery_Method_Id });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "email", DataType = SqlDbType.VarChar, Value = dataPost.Email });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecodestinatario", DataType = SqlDbType.VarChar, Value = dataPost.EnderecoDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecoremetente", DataType = SqlDbType.VarChar, Value = dataPost.EnderecoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadodestinatario", DataType = SqlDbType.VarChar, Value = dataPost.EstadoDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadoremetente", DataType = SqlDbType.VarChar, Value = dataPost.EstadoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estimated_delivery_date", DataType = SqlDbType.DateTime, Value = dataPost.Estimated_Delivery_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "federal_tax_payer_id", DataType = SqlDbType.VarChar, Value = dataPost.Federal_Tax_Payer_Id });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "height", DataType = SqlDbType.Decimal, Value = dataPost.Height });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idos", DataType = SqlDbType.BigInt, Value = dataPost.IdOs });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedido", DataType = SqlDbType.BigInt, Value = dataPost.IdPedido });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedidoitem", DataType = SqlDbType.BigInt, Value = dataPost.IdPedidoItem });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportador", DataType = SqlDbType.Int, Value = dataPost.IdTransportador });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "imagem", DataType = SqlDbType.VarChar, Value = dataPost.Imagem });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_date", DataType = SqlDbType.DateTime, Value = dataPost.Invoice_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_key", DataType = SqlDbType.VarChar, Value = dataPost.Invoice_Key });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_series", DataType = SqlDbType.VarChar, Value = dataPost.Invoice_Series });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_total_value", DataType = SqlDbType.Decimal, Value = dataPost.Invoice_Total_Value });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_company", DataType = SqlDbType.Bit, Value = dataPost.Is_Company });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_icms_exempt", DataType = SqlDbType.Bit, Value = dataPost.Is_Icms_Exempt });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "length", DataType = SqlDbType.Decimal, Value = dataPost.Length });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "logo", DataType = SqlDbType.VarChar, Value = dataPost.Logo });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "mensagem", DataType = SqlDbType.VarChar, Value = dataPost.Mensagem });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomecartao", DataType = SqlDbType.VarChar, Value = dataPost.NomeCartao });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomedestinatario", DataType = SqlDbType.VarChar, Value = dataPost.NomeDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomeremetente", DataType = SqlDbType.VarChar, Value = dataPost.NomeRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numerodestinatario", DataType = SqlDbType.VarChar, Value = dataPost.NumeroDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numeroremetente", DataType = SqlDbType.VarChar, Value = dataPost.NumeroRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "origin_warehouse_code", DataType = SqlDbType.VarChar, Value = dataPost.Origin_WareHouse_Code });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "phone", DataType = SqlDbType.VarChar, Value = dataPost.Phone });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "products_quantity", DataType = SqlDbType.Int, Value = dataPost.Products_Quantity });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "sales_channel", DataType = SqlDbType.VarChar, Value = dataPost.Sales_Channel });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "scheduled", DataType = SqlDbType.Bit, Value = dataPost.Scheduled });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_type", DataType = SqlDbType.VarChar, Value = dataPost.Shipment_Order_Type });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_volume_number", DataType = SqlDbType.Int, Value = dataPost.Shipment_Order_Volume_Number });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipped_date", DataType = SqlDbType.DateTime, Value = dataPost.Shipped_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipping_country", DataType = SqlDbType.VarChar, Value = dataPost.Shipping_Country });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "titulo", DataType = SqlDbType.VarChar, Value = dataPost.Titulo });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "trackingcode", DataType = SqlDbType.VarChar, Value = dataPost.TrackingCode });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_name", DataType = SqlDbType.VarChar, Value = dataPost.Volume_Name });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_type_code", DataType = SqlDbType.VarChar, Value = dataPost.Volume_Type_Code });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Weight", DataType = SqlDbType.Decimal, Value = dataPost.Weight });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Width", DataType = SqlDbType.Decimal, Value = dataPost.Width });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_biro", DataType = SqlDbType.DateTime, Value = dataPost.Data_Biro });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_pedido", DataType = SqlDbType.DateTime, Value = dataPost.Data_Pedido });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportadormetodo", DataType = SqlDbType.Int, Value = dataPost.IdTransportador });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "plataforma", DataType = SqlDbType.Char, Value = dataPost.Plataforma });

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "";

                    if (dataPost.IdItem.HasValue)
                    {
                        var fields = items.Select(x => String.Concat(x.FieldName, " = @", x.FieldName)).ToList();

                        query =  String.Format("Update items set {0} where iditem = @iditem ", String.Join(",", fields));

                        filter.Add(new SqlParameter() { ParameterName = "@iditem", SqlDbType = SqlDbType.BigInt, Value = dataPost.IdItem });
                    }
                    else
                    {
                        var fields = items.Select(x => new { field = x.FieldName, value = String.Concat("@", x.FieldName) }).ToList();

                        query = String.Format("insert items({0}) values ({1})", String.Join(',',fields.Select(x => x.field).ToList()), String.Join(',', fields.Select(x => x.value).ToList()));

                    }

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        foreach(var item in items)
                        {
                            filter.Add(new SqlParameter() { ParameterName = String.Concat("@", item.FieldName), SqlDbType = item.DataType, Value = item.Value != null ? item.Value : DBNull.Value });
                        }

                        comm.Parameters.AddRange(filter.ToArray());

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "Item Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }


        [HttpDelete]
        [Route("delete/{idItem}")]
        public Models.CustomReturn Remove(Int64 idItem)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = @"update OrderPreProduction set processed = 0 where idpedidoitem in (select idpedidoitem  from items where iditem = @idItem )
                                     go 
                                     delete from items where idItem= @idItem";
                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {                        
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idItem", SqlDbType = SqlDbType.BigInt, Value = idItem });
                        comm.ExecuteScalar();
                    }
                    conn.Close();
                }

                returnData.Message = "Item Excluído!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }

        [HttpPost]
        [Route("updateTransport")]
        public Models.CustomReturn UpdateTransport([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.Items.ItemsDetailResponse dataPost = postData.ToObject<Models.Items.ItemsDetailResponse>();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"update items set idtransportador = {0}, idtransportadormetodo = {1} where iditem = {2} ";

                    using (SqlCommand comm = new SqlCommand(String.Format(query, dataPost.IdTransportador,dataPost.IdTransportadorMetodo,dataPost.IdItem) , conn))
                    {
                        comm.ExecuteScalar();
                    }

                    conn.Close();
                }

                returnData.Message = "Item Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }
            return returnData;
        }
    }
}
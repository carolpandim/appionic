﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace BiroWebApi.Controllers
{
	[EnableCors("AllowAll")]
	public class BaseController : Controller, IDisposable
	{

		public readonly IConfigurationRoot configuration;

		public BaseController(IConfigurationRoot _configuration)
		{
			configuration = _configuration;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{

			}
		}

		public new void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
	}
}
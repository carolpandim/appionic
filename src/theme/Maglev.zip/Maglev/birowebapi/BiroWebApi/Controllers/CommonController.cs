﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/Common")]
    public class CommonController : BaseController
    {
        public CommonController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }


        [HttpGet]
        [Route("list-os-type")]
        public Models.CustomReturn GetOsType()
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT idostype, produto FROM osType Order by produto";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["produto"].ToString(),
                                    Value = reader["idostype"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }


        [HttpGet]
        [Route("list-os-status")]
        public Models.CustomReturn GetOsStatus()
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT idosstatus, nome FROM osStatus Order by nome";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["nome"].ToString(),
                                    Value = reader["idosstatus"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }

        [HttpGet]
        [Route("list-product")]
        public Models.CustomReturn GetProducts()
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT produto, codigo FROM osType Order by produto";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["produto"].ToString(),
                                    Value = reader["codigo"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }


        [HttpGet]
        [Route("list-tipo-entrega")]
        public Models.CustomReturn ListTipoEntrega()
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT idtipoentrega,nome FROM tiposentregas Order by nome";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["nome"].ToString(),
                                    Value = reader["idtipoentrega"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }

		[HttpGet]
		[Route("list-transportador")]
		public Models.CustomReturn ListTransportador()
		{
			Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT idtransportador,nome FROM transportadores where ativo=1 Order by nome";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["nome"].ToString(),
                                    Value = reader["idtransportador"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }

        [HttpGet]
        [Route("list-transportador-metodo/{idtransportador}")]
        public Models.CustomReturn ListTransportadorMetodo(string idTransportador)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            List<Models.Common.SelectItem> listData = new List<Models.Common.SelectItem>();

            string query = "";

            if (!String.IsNullOrEmpty(idTransportador) && idTransportador!="undefined" && idTransportador!= "null" && idTransportador!="-3")
            {
                query = String.Format(@"select 
                                          idtransportadormetodo, 
                                          nome 
                                        from transportadormetodos 
                                        where idtransportador = {0}",
                                        idTransportador);
            }
            else
            {
                query = @"select 
                            idtransportadormetodo, 
                            nome 
                          from transportadormetodos";
            }

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listData.Add(new Models.Common.SelectItem()
                                {
                                    Label = reader["nome"].ToString(),
                                    Value = reader["idtransportadormetodo"].ToString()
                                });
                            }
                        }
                    }
                }

                returnData.Data = listData;
                returnData.Success = true;

            }
            catch (Exception)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = true;
            }

            return returnData;
        }

    }
}
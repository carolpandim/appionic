﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/os")]
    public class OsController : BaseController
    {
        public OsController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("list/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int32 pageIndex, Int32 pageSize, [FromBody]  JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.Os.OsRequest osRequest = data.ToObject<Models.Os.OsRequest>();
            List<Models.Os.OsListResponse> osListResponse = new List<Models.Os.OsListResponse>();

            List<String> fieldFilter = new List<string>();

            List<SqlParameter> filter = new List<SqlParameter>();

            if (osRequest.DataFim.HasValue && osRequest.DataInicio.HasValue)
            {
                fieldFilter.Add(" cast(t1.data as date) between cast(@dataInicio as date) and cast(@dataFim as date)");
                filter.Add(new SqlParameter() { ParameterName = "@dataInicio", SqlDbType = SqlDbType.DateTime, Value = osRequest.DataInicio });
                filter.Add(new SqlParameter() { ParameterName = "@dataFim", SqlDbType = SqlDbType.DateTime, Value = osRequest.DataFim });
            }
            if (osRequest.IdOsType.HasValue)
            {
                fieldFilter.Add(" t1.idosType = @idosType ");
                filter.Add(new SqlParameter() { ParameterName = "@idosType", SqlDbType = SqlDbType.Int, Value = osRequest.IdOsType });
            }
            if (osRequest.IdOs.HasValue)
            {
                fieldFilter.Add(" t1.IdOs = @IdOs ");
                filter.Add(new SqlParameter() { ParameterName = "@IdOs", SqlDbType = SqlDbType.BigInt, Value = osRequest.IdOs });
            }
            if (osRequest.IdPedido.HasValue)
            {
                fieldFilter.Add(" exists(select 100 from items st1 (nolock) where  st1.idOs = t1.idOs and  st1.IdPedido = @IdPedido ) ");
                filter.Add(new SqlParameter() { ParameterName = "@IdPedido", SqlDbType = SqlDbType.BigInt, Value = osRequest.IdPedido });
            }
            if (osRequest.IdStatus.HasValue)
            {
                fieldFilter.Add(" t1.idstatus = @idstatus ");
                filter.Add(new SqlParameter() { ParameterName = "@idstatus", SqlDbType = SqlDbType.Int, Value = osRequest.IdStatus });
            }

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
										from 
											   os (nolock) t1
                                     ";

                    if (fieldFilter.Count() > 0)
                    {
                        queryTotal += " where " + String.Join(" AND ", fieldFilter);
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        if (filter.Count() > 0)
                        {
                            comm.Parameters.AddRange(filter.ToArray());
                        }

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }

                        comm.Parameters.Clear();
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"
                                        SELECT 
	                                        t1.idos,
	                                        t1.data,
	                                        t2.produto,
	                                        1 as cartoes,
	                                        t3.nome as status,
	                                        t3.idosstatus,
                                            t1.possuichip,
                                            t1.publicado
                                        FROM 
	                                        os t1 (nolock)
	                                        inner join ostype t2 (nolock) on t1.idostype = t2.idostype
	                                        inner join osstatus t3 (nolock) on t1.idstatus = t3.idosstatus ";

                        if (fieldFilter.Count() > 0)
                        {
                            query += " where " + String.Join(" AND ", fieldFilter);
                        }

                        query += " order by data desc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            if (filter.Count() > 0)
                            {
                                comm.Parameters.Clear();
                                comm.Parameters.AddRange(filter.ToArray());
                            }

                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                osListResponse.Add(new Models.Os.OsListResponse()
                                {
                                    Cartoes = Convert.ToInt32(reader["cartoes"]),
                                    Data = Convert.ToDateTime(reader["data"]),
                                    IdOs = Convert.ToInt64(reader["idos"]),
                                    IdStatus = Convert.ToInt32(reader["idosstatus"]),
                                    PossuiChip = Convert.ToBoolean(reader["possuichip"]),
                                    Produto= reader["Produto"].ToString(),
                                    Publicado = Convert.ToBoolean(reader["publicado"]),
                                    Status = reader["status"].ToString()
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = osListResponse;
                returnData.Success = true;

            }
            catch (Exception ex)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = false;
            }

            return returnData;

        }

    }
}
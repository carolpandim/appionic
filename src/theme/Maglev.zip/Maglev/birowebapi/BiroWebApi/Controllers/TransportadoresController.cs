﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/transportadores")]
    public class TransportadoresController : BaseController
    {
        public TransportadoresController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpPost]
        [Route("list/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int32 pageIndex, Int32 pageSize, [FromBody]  JObject data)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.Transportadores.TransportadoresRequest transportRequest = data.ToObject<Models.Transportadores.TransportadoresRequest>();
            List<Models.Transportadores.TransportadoresListResponse> transportListResponse = new List<Models.Transportadores.TransportadoresListResponse>();

            List<String> fieldFilter = new List<string>();

            List<SqlParameter> filter = new List<SqlParameter>();

            if (!String.IsNullOrEmpty(transportRequest.Nome))
            {
                fieldFilter.Add(" t1.nome = @nome ");
                filter.Add(new SqlParameter() { ParameterName = "@nome", SqlDbType = SqlDbType.VarChar, Value = transportRequest.Nome });
            }

            if (transportRequest.Ativo.HasValue)
            {
                fieldFilter.Add(" t1.ativo = @ativo ");
                filter.Add(new SqlParameter() { ParameterName = "@ativo", SqlDbType = SqlDbType.Bit, Value = transportRequest.Ativo.Value });
            }

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var queryTotal = @"
										select 
											   count(1)
										from 
											   transportadores (nolock) t1
                                     ";

                    if (fieldFilter.Count() > 0)
                    {
                        queryTotal += " where " + String.Join(" AND ", fieldFilter);
                    }

                    using (SqlCommand comm = new SqlCommand(queryTotal, conn))
                    {
                        if (filter.Count() > 0)
                        {
                            comm.Parameters.AddRange(filter.ToArray());
                        }

                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }

                        comm.Parameters.Clear();
                    }

                    if (returnData.TotalResultado > 0)
                    {
                        var query = @"
                                        SELECT 
	                                        *
                                        FROM 
	                                        transportadores t1 (nolock) ";

                        if (fieldFilter.Count() > 0)
                        {
                            query += " where " + String.Join(" AND ", fieldFilter);
                        }

                        query += " order by nome asc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
                        {
                            if (filter.Count() > 0)
                            {
                                comm.Parameters.Clear();
                                comm.Parameters.AddRange(filter.ToArray());
                            }

                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                transportListResponse.Add(new Models.Transportadores.TransportadoresListResponse()
                                {
                                    IdTransportador = Convert.ToInt32(reader["idtransportador"].ToString()),
                                    Nome = reader["nome"].ToString(),
                                    Ativo = Convert.ToBoolean(reader["ativo"].ToString())
                                });
                            }
                        }
                    }

                    conn.Close();
                }

                returnData.Data = transportListResponse;
                returnData.Success = true;

            }
            catch (Exception ex)
            {
                returnData.Message = "Ocorreu um erro";
                returnData.Success = false;
            }

            return returnData;

        }


        [HttpGet]
        [Route("detail/{idtransportador}")]
        public Models.CustomReturn Detail(String idtransportador)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            Models.Transportadores.TransportadoresDetailResponse data = new Models.Transportadores.TransportadoresDetailResponse();
            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT * FROM transportadores where idtransportador=@idtransportador";

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idtransportador", SqlDbType = SqlDbType.VarChar, Value = idtransportador });

                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            data.Nome = reader["nome"].ToString();
                            data.Ativo = Convert.ToBoolean(reader["ativo"]);
                            data.IdTransportador = Convert.ToInt32(reader["idTransportador"].ToString());
                        }

                    }


                    conn.Close();

                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }

        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Detail([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.Transportadores.TransportadoresDetailResponse dataPost = postData.ToObject<Models.Transportadores.TransportadoresDetailResponse>();

            List<SqlParameter> filter = new List<SqlParameter>();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "";

                    if (dataPost.IdTransportador.HasValue)
                    {
                        query = "Update transportadores set nome = @nome, ativo = @ativo where idtransportador = @idtransportador ";
                        filter.Add(new SqlParameter() { ParameterName = "@idtransportador", SqlDbType = SqlDbType.BigInt, Value = dataPost.IdTransportador });
                    }
                    else
                    {
                        query = "insert transportadores(nome,ativo) values (@nome,@ativo)";

                    }

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        filter.Add(new SqlParameter() { ParameterName = "@nome", SqlDbType = SqlDbType.VarChar, Value = dataPost.Nome });
                        filter.Add(new SqlParameter() { ParameterName = "@ativo", SqlDbType = SqlDbType.Bit, Value = dataPost.Ativo });

                        comm.Parameters.AddRange(filter.ToArray());

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "Transportador Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }


        [HttpDelete]
        [Route("delete/{idtransportador}")]
        public Models.CustomReturn Remove(String idtransportador)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "update transportadores set ativo = 0 where idtransportador= @idtransportador ";


                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.Parameters.Add(new SqlParameter() { ParameterName = "@idtransportador", SqlDbType = SqlDbType.Int, Value = idtransportador });

                        comm.ExecuteScalar();
                    }


                    conn.Close();

                }

                returnData.Message = "transportador inativado!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }


            return returnData;
        }
    }
}
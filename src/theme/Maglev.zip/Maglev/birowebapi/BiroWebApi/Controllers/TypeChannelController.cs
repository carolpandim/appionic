﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{

    [Produces("application/json")]
    [EnableCors("AllowAll")]
    [Route("api/typeChannel")]

    public class TypeChannelController : BaseController
    {
        public TypeChannelController(IConfigurationRoot _configuration) : base(_configuration)
        {

        }

        [HttpGet]
        [Route("list/{idOsType}/{pageIndex}/{pageSize}")]
        public Models.CustomReturn List(Int64 idOsType, Int32 pageIndex, Int32 pageSize)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();
            List<String> fieldFilter = new List<string>();


            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                var data = new List<Models.TypeChannel.TypeChannel>();
         
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();


                    var queryTotal = @"	select 
											   count(1)
										from 
											   osTypeChannels (nolock) where idostype={0}
                                     ";

                    using (SqlCommand comm = new SqlCommand(String.Format(queryTotal,idOsType), conn))
                    {
                        returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());
                        if (returnData.TotalResultado > 0)
                        {
                            returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
                        }
                        comm.Parameters.Clear();
                    }
                    if (returnData.TotalResultado > 0)
                    {

                        var query = @"SELECT idostypechannel,
                                            idostype,
                                            codigocanal,
                                            nome
                                    FROM osTypeChannels 
                                    where idostype={0}
                                    order by codigocanal asc OFFSET (({1} - 1) * {2}) ROWS FETCH NEXT {2} ROWS ONLY";

                        using (SqlCommand comm = new SqlCommand(String.Format(query, idOsType, pageIndex, pageSize), conn))
                        {
                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                var aux = new Models.TypeChannel.TypeChannel();

                                aux.IdOsTypechannel = Convert.ToInt64(reader["idostypechannel"]);
                                aux.IdOsType = Convert.ToInt64(reader["idostype"]);
                                aux.CodigoCanal = reader["codigocanal"].ToString();
                                aux.Nome = reader["nome"].ToString();

                                data.Add(aux);
                            }
                        }
                    }
                    conn.Close();
                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Erro ao consultar dados";
            }

            return returnData;
        }


        [HttpGet]
        [Route("detail/{idostypechannel}")]
        public Models.CustomReturn Detail(Int64 idostypechannel)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");
                var data = new Models.TypeChannel.TypeChannel();

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"SELECT idostypechannel,
                                            idostype,
                                            codigocanal,
                                            nome
                                    FROM osTypeChannels 
                                    where idostypechannel={0}";

                    using (SqlCommand comm = new SqlCommand(String.Format(query, idostypechannel), conn))
                    {
                        var reader = comm.ExecuteReader();
                        while (reader.Read())
                        {
                            data.IdOsTypechannel = Convert.ToInt64(reader["idostypechannel"]);
                            data.IdOsType = Convert.ToInt64(reader["idostype"]);
                            data.CodigoCanal = reader["codigocanal"].ToString();
                            data.Nome = reader["nome"].ToString();
                        }
                    }
                    conn.Close();
                }

                returnData.Data = data;
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Erro ao consultar dados";
            }

            return returnData;
        }


        [HttpPost]
        [Route("save")]
        public Models.CustomReturn Detail([FromBody] JObject postData)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            Models.TypeChannel.TypeChannel dataPost = postData.ToObject<Models.TypeChannel.TypeChannel>();

            List<SqlParameter> filter = new List<SqlParameter>();

            try
            {
                var connection = configuration.GetConnectionString("BiroProd");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    String query = "";

                    if (dataPost.IdOsTypechannel.HasValue)
                    {
                        query = @"Update osTypeChannels set 
                                        codigocanal = @codigocanal,
                                        nome = @nome
                                        where Idostypechannel = @Idostypechannel ";

                        filter.Add(new SqlParameter() { ParameterName = "@Idostypechannel", SqlDbType = SqlDbType.BigInt, Value = dataPost.IdOsTypechannel });
                    }
                    else
                    {
                        query = @"Insert osTypeChannels (idostype,codigocanal,nome) 
                                        values (@idostype,@codigocanal,@nome)";

                        filter.Add(new SqlParameter() { ParameterName = "@idostype", SqlDbType = SqlDbType.BigInt, Value = dataPost.IdOsType });
                    }

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {                        
                        filter.Add(new SqlParameter() { ParameterName = "@codigocanal", SqlDbType = SqlDbType.VarChar, Value = dataPost.CodigoCanal });
                        filter.Add(new SqlParameter() { ParameterName = "@nome", SqlDbType = SqlDbType.VarChar, Value = dataPost.Nome });

                        comm.Parameters.AddRange(filter.ToArray());
                        comm.ExecuteScalar();
                    }

                    conn.Close();
                }

                returnData.Message = "Tipo de Canal Salvo!";
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro no processamento";
            }
            return returnData;
        }

        [HttpDelete]
        [Route("delete/{idostypechannel}")]
        public Models.CustomReturn Delete(Int64 idostypechannel)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var connection = configuration.GetConnectionString("BiroRead");

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    var query = @"Delete osTypeChannels 
                                    where idostypechannel = {0}";

                    using (SqlCommand comm = new SqlCommand(String.Format(query, idostypechannel), conn))
                    {
                        var reader = comm.ExecuteScalar();
                    }
                    conn.Close();
                }
                returnData.Success = true;
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Erro ao excluir dados";
            }

            return returnData;
        }
    }
}
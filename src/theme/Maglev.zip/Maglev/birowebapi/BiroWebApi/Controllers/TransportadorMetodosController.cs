﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using BiroWebApi.Models.TransportadorMetodos;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace BiroWebApi.Controllers
{
	[Produces("application/json")]
	[EnableCors("AllowAll")]
	[Route("api/TransportadorMetodos")]
	public class TransportadorMetodosController : BaseController
	{
		public TransportadorMetodosController(IConfigurationRoot _configuration) : base(_configuration)
		{

		}

		[HttpGet]
		[Route("list/{pageIndex}/{pageSize}/{idTransportador}")]
		public Models.CustomReturn List(Int32 pageIndex, Int32 pageSize, int? idTransportador)
		{
			Models.CustomReturn returnData = new Models.CustomReturn();

			List<String> fieldFilter = new List<string>();

			List<SqlParameter> filter = new List<SqlParameter>();

			List<TransportadorMetodosListResponse> transportadorMetodoListResponse = new List<TransportadorMetodosListResponse>();
			
			if (idTransportador != null)
			{
				fieldFilter.Add(" t1.idtransportador = @idtransportador ");
				filter.Add(new SqlParameter() { ParameterName = "@idtransportador", SqlDbType = SqlDbType.Int, Value = idTransportador.Value });
			}

			try
			{
				var connection = configuration.GetConnectionString("BiroRead");

				using (SqlConnection conn = new SqlConnection(connection))
				{
					conn.Open();

					var queryTotal = @"
										select 
											   count(1)
										from 
											   transportadorMetodos (nolock) t1
                                     ";

					if (fieldFilter.Count() > 0)
					{
						queryTotal += " where " + String.Join(" AND ", fieldFilter);
					}

					using (SqlCommand comm = new SqlCommand(queryTotal, conn))
					{
						if (filter.Count() > 0)
						{
							comm.Parameters.AddRange(filter.ToArray());
						}

						returnData.TotalResultado = Convert.ToInt32(comm.ExecuteScalar());

						if (returnData.TotalResultado > 0)
						{
							returnData.TotalPaginas = Convert.ToInt32(Math.Ceiling((double)returnData.TotalResultado / pageSize));
						}

						comm.Parameters.Clear();
					}

					if (returnData.TotalResultado > 0)
					{
						var query = @"
                                        SELECT 
	                                        *
                                        FROM 
	                                        transportadorMetodos t1 (nolock) ";

						if (fieldFilter.Count() > 0)
						{
							query += " where " + String.Join(" AND ", fieldFilter);
						}

						query += " order by nome asc OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY";

						using (SqlCommand comm = new SqlCommand(String.Format(query, pageIndex, pageSize), conn))
						{
							if (filter.Count() > 0)
							{
								comm.Parameters.Clear();
								comm.Parameters.AddRange(filter.ToArray());
							}

							var reader = comm.ExecuteReader();

							while (reader.Read())
							{
								transportadorMetodoListResponse.Add(new TransportadorMetodosListResponse
								{
									IdTransportadorMetodo = Convert.ToInt32(reader["idtransportadormetodo"].ToString()),
									IdTransportador = Convert.ToInt32(reader["idtransportador"].ToString()),
									Nome = reader["nome"].ToString(),
									Codigo = reader["codigo"].ToString(),
									SLA = Convert.ToInt32(reader["sla"].ToString())
								});
							}
						}
					}

					conn.Close();
				}

				returnData.Data = transportadorMetodoListResponse;
				returnData.Success = true;
			}
			catch (Exception ex)
			{
				returnData.Message = "Ocorreu um erro";
				returnData.Success = false;
			}

			return returnData;
		}



		[HttpGet]
		[Route("detail/{idtransportadormetodo}")]
		public Models.CustomReturn Detail(String idtransportadormetodo)
		{
			Models.CustomReturn returnData = new Models.CustomReturn();
			Models.TransportadorMetodos.TransportadorMetodosDetailResponse data = new Models.TransportadorMetodos.TransportadorMetodosDetailResponse();
			try
			{
				var connection = configuration.GetConnectionString("BiroRead");

				using (SqlConnection conn = new SqlConnection(connection))
				{
					conn.Open();

					var query = @"SELECT * FROM transportadormetodos where idtransportadormetodo=@idtransportadormetodo";

					using (SqlCommand comm = new SqlCommand(query, conn))
					{
						comm.Parameters.Add(new SqlParameter() { ParameterName = "@idtransportadormetodo", SqlDbType = SqlDbType.Int, Value = idtransportadormetodo });

						var reader = comm.ExecuteReader();

						while (reader.Read())
						{
							data.IdTransportador = Convert.ToInt32(reader["idTransportador"].ToString());
							data.Codigo = reader["codigo"].ToString();
							data.Nome = reader["nome"].ToString();
							if (!String.IsNullOrEmpty(reader["sla"].ToString()))
							{
								data.SLA = Convert.ToInt32(reader["sla"]);
							}
							data.IdTransportadorMetodo = Convert.ToInt32(reader["idtransportadormetodo"]);
						}

					}


					conn.Close();

				}

				returnData.Data = data;
				returnData.Success = true;
			}
			catch (Exception ex)
			{
				returnData.Success = false;
				returnData.Message = "Ocorreu um erro no processamento";
			}


			return returnData;
		}


		[HttpPost]
		[Route("save")]
		public Models.CustomReturn Detail([FromBody] JObject postData)
		{
			Models.CustomReturn returnData = new Models.CustomReturn();

			TransportadorMetodosDetailResponse dataPost = postData.ToObject<TransportadorMetodosDetailResponse>();

			List<SqlParameter> filter = new List<SqlParameter>();

			try
			{
				var connection = configuration.GetConnectionString("BiroProd");

				using (SqlConnection conn = new SqlConnection(connection))
				{
					conn.Open();

					String query = "";

					if (dataPost.IdTransportadorMetodo.HasValue)
					{
						query = "Update transportadormetodos set idtransportador=@idtransportador, nome = @nome, codigo = @codigo, sla=@sla where idtransportadormetodo = @idtransportadormetodo ";
						filter.Add(new SqlParameter() { ParameterName = "@idtransportadormetodo", SqlDbType = SqlDbType.Int, Value = dataPost.IdTransportadorMetodo });

					}
					else
					{
						query = "insert transportadormetodos(idtransportador,nome,codigo,sla) values (@idtransportador,@nome,@codigo,@sla)";

					}

					using (SqlCommand comm = new SqlCommand(query, conn))
					{
						filter.Add(new SqlParameter() { ParameterName = "@idtransportador", SqlDbType = SqlDbType.Int, Value = dataPost.IdTransportador });
						filter.Add(new SqlParameter() { ParameterName = "@nome", SqlDbType = SqlDbType.VarChar, Value = dataPost.Nome });
						filter.Add(new SqlParameter() { ParameterName = "@codigo", SqlDbType = SqlDbType.VarChar, Value = dataPost.Codigo });
						filter.Add(new SqlParameter() { ParameterName = "@sla", SqlDbType = SqlDbType.Int, Value = dataPost.SLA });

						comm.Parameters.AddRange(filter.ToArray());

						comm.ExecuteScalar();
					}


					conn.Close();

				}

				returnData.Message = "Transportador Métodos Salvo!";
				returnData.Success = true;
			}
			catch (Exception ex)
			{
				returnData.Success = false;
				returnData.Message = "Ocorreu um erro no processamento";
			}


			return returnData;
		}


		[HttpDelete]
		[Route("delete/{idtransportadormetodo}")]
		public Models.CustomReturn Remove(String idtransportadormetodo)
		{
			Models.CustomReturn returnData = new Models.CustomReturn();

			try
			{
				var connection = configuration.GetConnectionString("BiroProd");

				using (SqlConnection conn = new SqlConnection(connection))
				{
					conn.Open();

					String query = "delete transportadormetodos where idtransportadormetodo= @idtransportadormetodo ";


					using (SqlCommand comm = new SqlCommand(query, conn))
					{
						comm.Parameters.Add(new SqlParameter() { ParameterName = "@idtransportadormetodo", SqlDbType = SqlDbType.Int, Value = idtransportadormetodo });

						comm.ExecuteScalar();
					}


					conn.Close();

				}

				returnData.Message = "transportador método excluído!";
				returnData.Success = true;
			}
			catch (Exception ex)
			{
				returnData.Success = false;
				returnData.Message = "Ocorreu um erro no processamento";
			}


			return returnData;
		}
	}
}
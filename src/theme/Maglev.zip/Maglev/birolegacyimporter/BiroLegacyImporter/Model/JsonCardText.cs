﻿namespace BiroLegacyImporter.Model
{
    public class JsonCardText : BiroUtils.Models.JSON.OrderPreProduction
    {

    }
}

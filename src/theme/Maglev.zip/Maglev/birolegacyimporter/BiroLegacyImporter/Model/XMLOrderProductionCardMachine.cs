﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using System.Xml.Serialization;

namespace BiroLegacyImporter.Model
{
    public class XMLOrderProductionCardMachine
    {
        [Serializable()]
        [System.Xml.Serialization.XmlRoot("Root")]
        public class Root
        {
            public Cartao Cartao { get; set; }
            public PedIdo PedIdo { get; set; }
            public Impressao Impressao { get; set; }
            public Remetente Remetente { get; set; }
            public Destino Destino { get; set; }
           
        }

        [Serializable()]
        public class Cartao
        {
            [System.Xml.Serialization.XmlElement("Tracking")]
            public long Tracking { get; set; }

            [System.Xml.Serialization.XmlElement("Nome")]
            public String Nome { get; set; }

            [System.Xml.Serialization.XmlElement("TipoEnvioSenha")]
            public String TipoEnvioSenha { get; set; }
        }

        [Serializable()]
        public class PedIdo
        {

            [System.Xml.Serialization.XmlElement("Saldo")]
            public decimal Saldo { get; set; }

            [System.Xml.Serialization.XmlElement("Objeto")]
            public String Objeto { get; set; }

            [System.Xml.Serialization.XmlElement("pedido")]
            public String Pedido { get; set; }

            [System.Xml.Serialization.XmlElement("TipoDoProduto")]
            public String TipoDoProduto { get; set; }

        }

        [Serializable()]
        public class Impressao
        {
            [System.Xml.Serialization.XmlElement("Imagem")]
            public String Imagem { get; set; }

            [System.Xml.Serialization.XmlElement("Mensagem")]
            public String Mensagem { get; set; }

            [System.Xml.Serialization.XmlElement("Assinatura")]
            public String Assinatura { get; set; }

            [System.Xml.Serialization.XmlElement("Titulo")]
            public String Titulo { get; set; }

        }

        [Serializable()]
        public class Remetente
        {
            [System.Xml.Serialization.XmlElement("Nome")]
            public String Nome { get; set; }

            [System.Xml.Serialization.XmlElement("Endereco")]
            public String Endereco { get; set; }

            [System.Xml.Serialization.XmlElement("Numero")]
            public String Numero { get; set; }

            [System.Xml.Serialization.XmlElement("Complemento")]
            public String Complemento { get; set; }

            [System.Xml.Serialization.XmlElement("Uf")]
            public String Uf { get; set; }

            [System.Xml.Serialization.XmlElement("CIdade")]
            public String CIdade { get; set; }

            [System.Xml.Serialization.XmlElement("Cep")]
            public String Cep { get; set; }

            [System.Xml.Serialization.XmlElement("Bairro")]
            public String Bairro { get; set; }


        }

        [Serializable()]
        public class Destino
        {
            [System.Xml.Serialization.XmlElement("Nome")]
            public String Nome { get; set; }

            [System.Xml.Serialization.XmlElement("Endereco")]
            public String Endereco { get; set; }

            [System.Xml.Serialization.XmlElement("Numero")]
            public String Numero { get; set; }

            [System.Xml.Serialization.XmlElement("Complemento")]
            public String Complemento { get; set; }

            [System.Xml.Serialization.XmlElement("Uf")]
            public String Uf { get; set; }

            [System.Xml.Serialization.XmlElement("CIdade")]
            public String CIdade { get; set; }

            [System.Xml.Serialization.XmlElement("Cep")]
            public String Cep { get; set; }

            [System.Xml.Serialization.XmlElement("Bairro")]
            public String Bairro { get; set; }

        }
    }
}

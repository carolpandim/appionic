﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroLegacyImporter.Model
{
    public class TblCardMachineItems
    {
        public Int64 CdCardMachineItems { get; set; }
        public Int64 TotalItens { get; set; }
        public string NomeCliente { get; set; }
        public Int64 CdOrder { get; set; }
        public Int64 CdOrderItems { get; set; }
        public String CdOrderCdOrderItems { get; set; }
        public Int64 CdCard { get; set; }
        public Int64 CdChannel { get; set; }
        public String DsLogo { get; set; }
        public Model.JsonCardText JSON { get; set; }
        public String DsFrontPath { get; set; }
        public DateTime DtCreated { get; set; }
        public Int16 FlCreated { get; set; }

        private string _cardtext;
        public String CardText
        {
            get
            {
                return _cardtext;
            }
            set
            {
                _cardtext = value.ToString();
                var content = _cardtext.Split('<').ToList();
                var itemLista = new List<Content>();
                foreach (var itemContent in content)
                {
                    var text = itemContent.Split('>').ToList();
                    if (text.Count() > 1)
                    {
                        itemLista.Add(new Content()
                        {

                            Key = text[0],
                            Value = text[1]

                        });

                    }

                }

                JsonCardText jsonCardText = new JsonCardText();

                jsonCardText.Conteudo.IdPedido = CdOrder;
                jsonCardText.Conteudo.IdPedidoItem = CdOrderItems;
                jsonCardText.Conteudo.Cartao.CodigoCartao = CdCard;
                jsonCardText.TotalItens = TotalItens;
                jsonCardText.NomeCliente = NomeCliente;
                jsonCardText.CodigoCanal = Convert.ToInt64(this.CdChannel);
                jsonCardText.Conteudo.Endereco.Destinatario.Logradouro= itemLista.Where(x => x.Key == "street").Select(x => x.Value).FirstOrDefault().Replace("'", "") + ", " + itemLista.Where(x => x.Key == "streetnumber").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.Cidade= itemLista.Where(x => x.Key == "city").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.Numero = itemLista.Where(x => x.Key == "streetnumber").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.Complemento = itemLista.Where(x => x.Key == "addresscomp").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.Bairro = itemLista.Where(x => x.Key == "neigh").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.Estado = itemLista.Where(x => x.Key == "stateacronym").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Endereco.Destinatario.CEP = itemLista.Where(x => x.Key == "zipcode").Select(x => x.Value).FirstOrDefault();
                jsonCardText.Conteudo.CartaBerco.Mensagem = itemLista.Where(x => x.Key == "xenvmsg").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.CartaBerco.Assinatura = itemLista.Where(x => x.Key == "xenvsig").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.CartaBerco.Titulo = itemLista.Where(x => x.Key == "xenvtit").Select(x => x.Value).FirstOrDefault();
                jsonCardText.Conteudo.Endereco.Destinatario.NomeDestinatario = itemLista.Where(x => x.Key == "recipientname").Select(x => x.Value).FirstOrDefault().Replace("'", "");
                jsonCardText.Conteudo.Cartao.NomeCartao = itemLista.Where(x => x.Key == "emb5").Select(x => x.Value).FirstOrDefault();
                jsonCardText.Conteudo.Cartao.Imagem = DsFrontPath;
                jsonCardText.Plataforma = "L";
                jsonCardText.DataPedido = DtCreated.ToString("yyyy-MM-dd HH:mm:ss");

                JSON = jsonCardText;
                _cardtext = JsonConvert.SerializeObject(jsonCardText, Formatting.Indented);

            }
        }
    }
}
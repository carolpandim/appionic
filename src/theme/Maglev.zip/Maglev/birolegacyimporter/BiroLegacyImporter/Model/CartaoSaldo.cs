﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroLegacyImporter.Model
{
    class CartaoSaldo
    {
        public long CodigoCartao { get; set; }
        public decimal Saldo { get; set; }
    }
}

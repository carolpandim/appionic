﻿using System;

namespace BiroLegacyImporter.Model
{
    public class Content
    {
        public String Key { get; set; }
        public String Value { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Xml.Serialization;

namespace BiroLegacyImporter.Model
{
    public class OrderProductionCardMachine
    {
        public Int64 CdCardMachineItems { get; set; }
        public Int64 TotalItens { get; set; }
        public string NomeCliente { get; set; }
        public DateTime DtCreated { get; set; }
        public Int16 FlCreated { get; set; }
        public long CdCard { get; set; }
        public long CdOrder { get; set; }
        public long CdOrderItems { get; set; }
        public String DestinatarioNumeroEndereco { get; set; }
        public String DestinatarioComplementoEndereco { get; set; }
        public String DestinatarioCidadeEndereco { get; set; }
        public String DestinatarioBairroEndereco { get; set; }
        public String DestinatarioEstadoEndereco { get; set; }
        public String DestinatarioLogradouroEndereco { get; set; }
        public String DestinatarioCepEndereco { get; set; }
        public String DestinatarioNome { get; set; }
        public String CodigoRastreio { get; set; }
        public String RemetenteNome { get; set; }
        public String RemetenteCidadeEndereco { get; set; }
        public String RemetenteComplementoEndereco { get; set; }
        public String RemetenteBairroEndereco { get; set; }
        public String RemetenteEstadoEndereco { get; set; }
        public String RemetenteLogradouroEndereco { get; set; }
        public String RemetenteNumeroEndereco { get; set; }
        public String RemetenteCepEndereco { get; set; }
        public String Imagem { get; set; }
        public String Assinatura { get; set; }
        public String Mensagem { get; set; }
        public String Nome { get; set; }
        public String Frase { get; set; }
        public String CdChannel { get; set; }
        public Model.JsonCardText JSON { get; set; }

        private string _cardtext;
        public String CardText
        {
            get { return _cardtext; }
            set
            {
                JsonCardText jsonCardText = new JsonCardText();

                jsonCardText.Conteudo.IdPedido = this.CdOrder;
                jsonCardText.CodigoCanal = Convert.ToInt64(this.CdChannel);
                jsonCardText.TotalItens = TotalItens;
                jsonCardText.NomeCliente = NomeCliente;
                jsonCardText.Conteudo.IdPedidoItem = this.CdOrderItems;
                jsonCardText.Conteudo.Cartao.CodigoCartao = this.CdCard;
                jsonCardText.Conteudo.Cartao.Imagem = String.Concat("http://", ("cdn.valepresente.com.br/"+Imagem).Replace("//","/"));

                //Cartao
                jsonCardText.Conteudo.TrackingCode = CodigoRastreio.ToString();
                jsonCardText.Conteudo.Cartao.NomeCartao = Nome;

                //Impressao
                jsonCardText.Conteudo.CartaBerco.Mensagem = Mensagem;
                jsonCardText.Conteudo.CartaBerco.Assinatura = Assinatura;
                //jsonCardText.Cartao.Titulo = jsonCardText.Titulo = xmlResult.Impressao.Titulo != null ? xmlResult.Impressao.Titulo.Replace("'", "") : ""; 
                //jsonCardText.Titulo = xmlResult.Impressao.Titulo != null ? xmlResult.Impressao.Titulo.Replace("'", "") : ""; ;

                //Remetente
                jsonCardText.Conteudo.Endereco.Remetente.NomeRemetente = RemetenteNome;
                jsonCardText.Conteudo.Endereco.Remetente.Logradouro = RemetenteLogradouroEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.Numero = RemetenteNumeroEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.Complemento = RemetenteComplementoEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.Estado= RemetenteEstadoEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.Cidade = RemetenteCidadeEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.CEP = RemetenteCepEndereco;
                jsonCardText.Conteudo.Endereco.Remetente.Bairro = RemetenteBairroEndereco;

                //Destino
                jsonCardText.Conteudo.Endereco.Destinatario.NomeDestinatario = DestinatarioNome;
                jsonCardText.Conteudo.Endereco.Destinatario.Logradouro = DestinatarioLogradouroEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.Numero = DestinatarioNumeroEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.Complemento = DestinatarioComplementoEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.Estado = DestinatarioEstadoEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.Cidade = DestinatarioCidadeEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.CEP = DestinatarioCepEndereco;
                jsonCardText.Conteudo.Endereco.Destinatario.Bairro = DestinatarioBairroEndereco;

                jsonCardText.Plataforma = "L";
                jsonCardText.DataPedido = DtCreated.ToString("yyyy-MM-dd HH:mm:ss");

                _cardtext = JsonConvert.SerializeObject(jsonCardText);

                JSON = jsonCardText;

                //XmlSerializer serializer = new XmlSerializer(typeof(XMLOrderProductionCardMachine.Root));

                //using (TextReader reader = new StringReader(_cardtext))
                //{
                //    var xmlResult = (XMLOrderProductionCardMachine.Root)serializer.Deserialize(reader);

                //    jsonCardText.IdpedIdo = this.CdOrder.ToString();
                //    jsonCardText.IdPedIdoItem = this.CdOrderItems;
                //    jsonCardText.CodigoCartao = this.CdCard;

                //    //Cartao
                //    jsonCardText.TrackingCode = xmlResult.Cartao.Tracking;
                //    jsonCardText.NomeCartao = xmlResult.Cartao.Nome != null ? xmlResult.Cartao.Nome.Replace("'", "") : ""; ;

                //    //Impressao
                //    jsonCardText.Mensagem = xmlResult.Impressao.Mensagem != null ? xmlResult.Impressao.Mensagem.Replace("'", "") : ""; ;
                //    jsonCardText.Assinatura = xmlResult.Impressao.Assinatura != null ? xmlResult.Impressao.Assinatura.Replace("'", "") : ""; ;
                //    jsonCardText.Titulo = xmlResult.Impressao.Titulo != null ? xmlResult.Impressao.Titulo.Replace("'", "") : ""; ;

                //    //Remetente
                //    jsonCardText.NomeRemetente = xmlResult.Remetente.Nome != null ? xmlResult.Remetente.Nome.Replace("'", "") : ""; ;
                //    jsonCardText.EnderecoRemetente = xmlResult.Remetente.Endereco != null ? xmlResult.Remetente.Endereco.Replace("'", "") : ""; ;
                //    jsonCardText.NumeroRemetente = xmlResult.Remetente.Numero != null ? xmlResult.Remetente.Numero.Replace("'", "") : ""; ;
                //    jsonCardText.ComplementoRemetente = xmlResult.Remetente.Complemento != null ? xmlResult.Remetente.Complemento.Replace("'", "") : ""; ;
                //    jsonCardText.EstadoRemetente = xmlResult.Remetente.Uf != null ? xmlResult.Remetente.Uf.Replace("'", "") : ""; ;
                //    jsonCardText.CidadeRemetente = xmlResult.Remetente.CIdade != null ? xmlResult.Remetente.CIdade.Replace("'", "") : ""; ;
                //    jsonCardText.CepRemetente = xmlResult.Remetente.Cep != null ? xmlResult.Remetente.Cep.Replace("'", "") : ""; ;
                //    jsonCardText.BairroRemetente = xmlResult.Remetente.Bairro != null ? xmlResult.Remetente.Bairro.Replace("'", "") : ""; ;

                //    //Destino
                //    jsonCardText.NomeDestinatario = xmlResult.Destino.Nome != null ? xmlResult.Destino.Nome.Replace("'", "") : ""; ;
                //    jsonCardText.EnderecoDestinatario = xmlResult.Destino.Endereco != null ? xmlResult.Destino.Endereco.Replace("'", "") : ""; ;
                //    jsonCardText.NumeroDestinatario = xmlResult.Destino.Numero != null ? xmlResult.Destino.Numero.Replace("'", "") : ""; ;
                //    jsonCardText.ComplementoDestinatario = xmlResult.Destino.Complemento != null ? xmlResult.Destino.Complemento.Replace("'", "") : ""; ;
                //    jsonCardText.EstadoDestinatario = xmlResult.Destino.Uf != null ? xmlResult.Destino.Uf.Replace("'", "") : ""; ;
                //    jsonCardText.CidadeDestinatario = xmlResult.Destino.CIdade != null ? xmlResult.Destino.CIdade.Replace("'", "") : ""; ;
                //    jsonCardText.CepDestinatario = xmlResult.Destino.Cep != null ? xmlResult.Destino.Cep.Replace("'", "") : ""; ;
                //    jsonCardText.BairroDestinatario = xmlResult.Destino.Bairro != null ? xmlResult.Destino.Bairro.Replace("'", "") : ""; ;

                //    _cardtext = JsonConvert.SerializeObject(jsonCardText);
                //    JSON = jsonCardText;
                //}
            }
        }
    }
}

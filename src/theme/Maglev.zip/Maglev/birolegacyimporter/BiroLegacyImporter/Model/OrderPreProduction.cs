﻿using System;

namespace BiroLegacyImporter.Model
{
    public class OrderPreProduction
    {
        public Int64 Id { get; set; }
        public Int64 IdpedIdo { get; set; }
        public Int64 IdPedIdoItem { get; set; }
        public String Codigo { get; set; }
        public String Conteudo { get; set; }
        public DateTime DataPedido { get; set; }
        public String Plataforma { get; set; }
        public Int64 TotalItens { get; set; }


        public String Idempotency { get; set; }
        public String Origem { get; set; }
        public Model.JsonCardText JSON { get; set; }

        public enum StatusOrderPreProduction
        {
            Importado = 1,
            GeneratedTrackingCode = 2,
            Processado = 3,
        }
    }
}

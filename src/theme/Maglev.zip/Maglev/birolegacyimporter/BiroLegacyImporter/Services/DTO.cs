﻿using BiroLegacyImporter.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroLegacyImporter.Services
{
    class DTO
    {
        private static DTO oDTO;
        public static DTO Instance { get { oDTO = oDTO ?? new DTO(); return oDTO; } }

        public List<Model.OrderPreProduction> MapperTblCardMachineToOrderPreProduction(List<Model.TblCardMachineItems> listCardMachineItems)
        {
            List<OrderPreProduction> listOrderPreProduction = new List<OrderPreProduction>();

            if (listCardMachineItems.Count() > 0)
            {
                foreach (var item in listCardMachineItems)
                {
                    OrderPreProduction order = new OrderPreProduction
                    {
                        Id = item.CdCardMachineItems,
                        TotalItens = item.TotalItens,
                        IdpedIdo = item.CdOrder,
                        IdPedIdoItem = item.CdOrderItems,
                        Codigo = item.CdChannel.ToString(),
                        Conteudo = item.CardText,
                        DataPedido = item.DtCreated,
                        Origem = "Machine",
                        JSON = item.JSON,
                        Plataforma = "L",
                        Idempotency = String.Concat(item.CdOrder.ToString(), item.CdOrderItems.ToString(), item.CdChannel.ToString(), 'L')

                    };

                    listOrderPreProduction.Add(order);
                }
            }

            return listOrderPreProduction;

        }
        public List<Model.OrderPreProduction> MapperOrderProductionCardMachineToOrderPreProduction(List<Model.OrderProductionCardMachine> listOrderProductionCardMachine)
        {
            List<OrderPreProduction> listOrderPreProduction = new List<OrderPreProduction>();

            if (listOrderProductionCardMachine.Count() > 0)
            {
                foreach (var item in listOrderProductionCardMachine)
                {
                    OrderPreProduction order = new OrderPreProduction
                    {
                        Id = item.CdCardMachineItems,
                        TotalItens = item.TotalItens,
                        IdpedIdo = item.CdOrder,
                        IdPedIdoItem = item.CdOrderItems,
                        Codigo = item.CdChannel.ToString(),
                        Conteudo = item.CardText,
                        DataPedido = item.DtCreated,
                        Origem = "BNDES",
                        JSON = item.JSON,
                        Plataforma = "L",
                        Idempotency = String.Concat(item.CdOrder.ToString(),item.CdOrderItems.ToString(),item.CdChannel.ToString(), 'L')
                    };

                    listOrderPreProduction.Add(order);
                }
            }

            return listOrderPreProduction;

        }
    }
}

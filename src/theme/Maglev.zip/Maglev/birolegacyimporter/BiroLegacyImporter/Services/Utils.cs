﻿using BiroLegacyImporter.DataBase.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using BiroLegacyImporter.Model;
using System.Text;
using BiroUtils.Controllers;
using Newtonsoft.Json;

namespace BiroLegacyImporter.Services
{
    class Utils
    {
        private static Utils oUtils;
        public static Utils Instance { get { oUtils = oUtils ?? new Utils(); return oUtils; } }
        
        public List<Model.OrderPreProduction> SetCharacteristics(List<Model.OrderPreProduction> listOrderPreProduction)
        {
            listOrderPreProduction = SetCardHasChipAndCardWithoutChip(listOrderPreProduction);
            listOrderPreProduction = SetCardValue(listOrderPreProduction);

            return listOrderPreProduction;
        }

        private List<Model.OrderPreProduction> SetCardValue(List<Model.OrderPreProduction> listOrderPreProduction)
        {
            List<Int64> ItemsWithError = new List<Int64>();

            var SaldoCartao = Execute.Query.Instance.GetSaldoProcessadora(listOrderPreProduction);

            var s = (from order in listOrderPreProduction
                     join saldo in SaldoCartao on order.JSON.Conteudo.Cartao.CodigoCartao equals saldo.CodigoCartao
                     select new { pedido = order, valor = saldo.Saldo }).ToList();

            s.ForEach(x => { x.pedido.JSON.Conteudo.CartaBerco.Saldo = x.valor; x.pedido.Conteudo = JsonConvert.SerializeObject(x.pedido.JSON); });

            listOrderPreProduction = s.Select(x => x.pedido).ToList();


            return listOrderPreProduction;
        }

        private List<Model.OrderPreProduction> SetCardHasChipAndCardWithoutChip(List<Model.OrderPreProduction> listOrderPreProduction)
        {
            List<Int64> ItemsWithError = new List<Int64>();

            Model.CustomReturn result = new Model.CustomReturn();

            foreach (var card in listOrderPreProduction)
            {
                result = Execute.Query.Instance.CardHasChip(card.JSON.Conteudo.Cartao.CodigoCartao.Value);
                if (result.Success)
                {
                    card.JSON.Conteudo.Cartao.Chip = Convert.ToBoolean(result.Data);
                }
                else
                {
                    ItemsWithError.Add(card.Id);
                }

            }

            //Object lockObj = new Object();
            //Parallel.ForEach(orderPreProductionList, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, card =>
            //{
            //    lock (lockObj)
            //    {
            //      result = Execute.Query.Instance.CardHasChip(card.NewConteudo.CodigoCartao);
            //if (result.Success)
            //{
            //    card.IsChip = Convert.ToBoolean(result.Data);
            //}
            //else
            //{
            //    ItemsWithError.Add(card.Id);
            //}
            //    }
            //});

            if (ItemsWithError.Count > 0)
            {
                Logs.Instance.RegisterLog("BiroLegacyImporter", "warning", "O(s) cartão(ões) não foi localizado na Processadora", "SetCardHasChipAndCardWithoutChip", "procurar pelo ids: " + String.Join(",", ItemsWithError));
                var OrderPreProductionListWithoutError = listOrderPreProduction.Where(x => !ItemsWithError.Contains(x.Id)).ToList();
                return OrderPreProductionListWithoutError;
            }

            return listOrderPreProduction;
        }

    }


}

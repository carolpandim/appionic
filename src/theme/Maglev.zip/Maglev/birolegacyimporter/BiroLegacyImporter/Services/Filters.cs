﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BiroLegacyImporter.DataBase.SQL;
namespace BiroLegacyImporter.Services
{

    class Filters
    {
        private static Filters oFilter;
        public static Filters Instance { get { oFilter = oFilter ?? new Filters(); return oFilter; } }

        public List<Model.OrderPreProduction> RemoveDuplicatedItems(List<Model.OrderPreProduction> listOrderPreProduction)
        {
            // item duplicados


            var s = (from order in listOrderPreProduction
                     group order.Idempotency by order.Idempotency into g
                     where g.Count() > 1 select g.Key );
               

            //var s = (from order in listOrderPreProduction
            //         join saldo in SaldoCartao on order.JSON.CodigoCartao equals saldo.CodigoCartao
            //         select new { pedido = order, valor = saldo.Saldo }).ToList();

            //s.ForEach(x => { x.pedido.JSON.Saldo = x.valor; x.pedido.Conteudo = JsonConvert.SerializeObject(x.pedido.JSON); });

            //listOrderPreProduction = s.Select(x => x.pedido).ToList();

            var duplicateKeys = listOrderPreProduction.GroupBy(x => x.Idempotency)
                                                   .Where(group => group.Count() > 1)
                                                   .Select(group => group.Select(x => x.Id));



            if (duplicateKeys.Count() > 0)
            {
                // pegando somente o primeiro item do montante duplicado
                var listFirstItem = duplicateKeys.Select(x => x.FirstOrDefault()).ToList();

                // separando items duplicados que precisam ser marcados como criado
                var updateToCreate = duplicateKeys.Select(x => x.Where(y => !listFirstItem.Contains(y))).Select(x => x.FirstOrDefault()).ToList();

                // recriando lista sem os item duplicados
                var resultadofinal = listOrderPreProduction.Where(x => !updateToCreate.Contains(x.Id)).ToList();

                Execute.Query.Instance.UpdateTblCardMachineItems(updateToCreate);

                return resultadofinal;
            }

            return listOrderPreProduction;
        }

        public List<Model.OrderPreProduction> RemoveOrderPreProductionProcessed(List<Model.OrderPreProduction> listOrderPreProduction, List<String> existsItemOrderPreProduction)
        {
            var itemsProcessed = listOrderPreProduction.Where(x => existsItemOrderPreProduction.Contains(x.Idempotency)).ToList();

            //seta items processado para criado na tabela tbl_cardmachine_item na webstore
            Execute.Query.Instance.UpdateTblCardMachineItems(itemsProcessed.Select(x => x.Id).ToList());

            var newListCardMachineItems = listOrderPreProduction.Where(x => !existsItemOrderPreProduction.Contains(x.Idempotency)).ToList();

            // retorna uma nova lista sem os item duplicados
            return newListCardMachineItems;

        }
    }
}

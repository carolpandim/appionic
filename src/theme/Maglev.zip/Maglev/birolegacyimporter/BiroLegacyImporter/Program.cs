﻿using System;
using System.Diagnostics;

namespace BiroLegacyImporter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Iniciando importação de items criados nas tabelas tbl_cardmachine_items e OrderProduction");
            Console.WriteLine("");
            Console.WriteLine("Data Inicio Processamento:" + DateTime.Now.ToString());
            Console.WriteLine("");

            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();

            for (int i = 0; i < 10; i++)
            {
                Commands.Process.Start();

            }

            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;

            Console.WriteLine(String.Format("Tempo de Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));

            Console.WriteLine("Data Fim Processamento:" + DateTime.Now.ToString());

            
        }
    }
}

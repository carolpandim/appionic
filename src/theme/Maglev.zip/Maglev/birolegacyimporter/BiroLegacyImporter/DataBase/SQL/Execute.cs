﻿using BiroLegacyImporter.Model;
using BiroUtils.Controllers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using BiroLegacyImporter.Model;

namespace BiroLegacyImporter.DataBase.SQL
{
    class Execute
    {
        public class Query
        {
            private static Query oQuery;

            public static Query Instance { get { oQuery = oQuery ?? new Query(); return oQuery; } }


            public  List<TblCardMachineItems> GetCardMachineItems()
            {
                List<TblCardMachineItems> listMachineItems = new List<TblCardMachineItems>();

                try
                {
                    Console.WriteLine("Coletando 1000 registros da Webstore.tbl_cardmachine_items: " + DateTime.Now.ToString());

                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreRead"].ConnectionString))
                    {
                        String query = @"
                                        select 
                                            top 1000
                                            (select count(0) from Webstore.dbo.tbl_order_item ts where o.cd_order = ts.cd_order and ts.cd_order_item_base is null) as 'TotalItens',
                                            tc.ds_channel 'NomeCliente',
	                                        o.cd_cardmachine_items,
	                                        o.cd_order,
	                                        o.cd_order_items,
	                                        o.cd_card,
	                                        o.cardtext,
	                                        o.cd_channel,
	                                        o.ds_logo,
	                                        o.dt_created,
	                                        o.fl_created,
	                                        ds_front_path
                                        from 
	                                        webstore.dbo.tbl_cardmachine_items o
                                            left join webstore.dbo.tbl_channel tc on tc.cd_channel = o.cd_channel
	                                        left join webstore..tbl_order_item t2 on o.cd_order = t2.cd_order and cd_product = 18 and t2.cd_order_item_base = o.cd_order_items
                                            left join webstore..tbl_order_item_customization t3 on t2.cd_order_items = t3.cd_order_items
                                        where 
                                            o.cardtext is not null
	                                        and o.fl_created in (0,1)
                                            and o.cd_cardmachine_items > 70000
                                            and o.cd_channel in (8236)  
                                            --and o.cd_order in(1931038,1931038,1931038,1931038,15940424,15940424,15940424,15940424,15940424)
                                        
                                        ";

                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(query, conn))
                        {
                            comm.CommandTimeout = 300000;
                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                TblCardMachineItems cardMachineItems = new TblCardMachineItems
                                {
                                    CdCardMachineItems = Convert.ToInt64(reader["cd_cardmachine_items"].ToString()),
                                    TotalItens = Convert.ToInt64(reader["TotalItens"].ToString()),
                                    NomeCliente = reader["NomeCliente"].ToString(),
                                    CdOrder = Convert.ToInt64(reader["cd_order"].ToString()),
                                    CdOrderItems = Convert.ToInt64(reader["cd_order_items"].ToString()),
                                    CdCard = Convert.ToInt64(reader["cd_card"].ToString()),
                                    CdChannel = Convert.ToInt64(reader["cd_channel"].ToString()),
                                    DsLogo = reader["ds_logo"].ToString(),
                                    DtCreated = Convert.ToDateTime(reader["dt_created"].ToString()),
                                    FlCreated = Convert.ToInt16(reader["fl_created"].ToString()),
                                    DsFrontPath = reader["ds_front_path"].ToString(),
                                    CdOrderCdOrderItems = (reader["cd_order"].ToString()+reader["cd_order_items"].ToString()),
                                    CardText = reader["cardText"].ToString(),
                                };

                                listMachineItems.Add(cardMachineItems);
                            }
                        }

                        conn.Close();
                    }

                    Console.WriteLine("|--Range de dados coletados da Webstore.tbl_cardmachine_items: " + listMachineItems.First().CdCardMachineItems.ToString() + " ao " + listMachineItems.Last().CdCardMachineItems.ToString());
                    Console.WriteLine("Finalizando coleta de dados da Webstore.tbl_cardmachine_items: " + DateTime.Now.ToString());
                    

                }
                catch (Exception ex)
                {

                }

                return listMachineItems;
            }

            public List<OrderProductionCardMachine> GetOrderProductionCardMachine()
            {
                List<OrderProductionCardMachine> listOrderProductionCardMachine = new List<OrderProductionCardMachine>();
                
                Console.WriteLine("Coletando 1000 registros da Webstore.OrderProductionCardMachine: " + DateTime.Now.ToString());

                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreRead"].ConnectionString))
                {
                    String query = @"
                               select
	                                top 50
                                    (select count(0) from Webstore.dbo.tbl_order_item ts where t1.cd_order = ts.cd_order and ts.cd_order_item_base is null) as 'TotalItens',
                                    tc.ds_channel 'NomeCliente',
	                                t1.cd_cardmachine_items as CdCardMachineItems,
	                                t1.dt_created as DtCreated,
	                                t1.fl_created as FlCreated,
	                                t2.cd_card CdCard,
	                                t1.cd_order CdOrder,
	                                t1.cd_order_items CdOrderItems ,
	                                t9.nr_street as DestinatarioNumeroEndereco,
	                                t9.ds_complement  as DestinatarioComplementoEndereco,
	                                t9.ds_city as DestinatarioCidadeEndereco,
	                                t9.ds_district as DestinatarioBairroEndereco,
	                                t9.ds_state as DestinatarioEstadoEndereco,
	                                t9.ds_street as DestinatarioLogradouroEndereco,
	                                t9.nr_zipcode as DestinatarioCepEndereco,
	                                t8.ReceiverName as DestinatarioNome,
	                                t8.PostalCode as CodigoRastreio,
	                                t8.SenderName as RemetenteNome,
	                                t10.ds_city as RemetenteCidadeEndereco,
	                                t10.ds_complement as RemetenteComplementoEndereco,
	                                t10.ds_district as RemetenteBairroEndereco,
	                                t10.ds_state as RemetenteEstadoEndereco,
	                                t10.ds_street as RemetenteLogradouroEndereco,
	                                t10.nr_street as  RemetenteNumeroEndereco,
	                                t10.nr_zipcode as RemetenteCepEndereco,
	                                t11.ds_path_front_big as Imagem,
	                                t13.ds_recipient as Assinatura,
	                                t13.ds_message as Mensagem,
	                                t15.ds_recipient as Nome,
	                                t15.ds_message as Frase,
	                                t4.cd_channel as  CdChannel
                                from 
	                                OrderProductionCardMachine t1 (nolock)
                                    left join webstore.dbo.tbl_channel tc (nolock) on tc.cd_channel = t1.cd_channel
	                                inner join tbl_order_item_card t2 (nolock) on t1.cd_order_items = t2.cd_order_items 
	                                inner join tbl_order_item t3 (nolock) on t3.cd_order_items = t2.cd_order_items
	                                inner join tbl_order t4 (nolock) on t4.cd_order = t3.cd_order
	                                inner join OrderItemShipments t8 (nolock) on t8.OrderItem_Id = t3.cd_order_items
	                                inner join tbl_address t9 (nolock) on t9.cd_address = t8.ReceiverAddress
	                                inner join tbl_address t10 (nolock) on t8.SenderAddress = t10.cd_address
	                                inner join tbl_product t11 (nolock) on t11.cd_product = t3.cd_product
	                                inner join tbl_order_item t12 (nolock) on t12.cd_order = t1.cd_order and t12.cd_product = 17
	                                inner join tbl_order_item_customization t13 on t13.cd_order_items = t12.cd_order_items
	                                inner join tbl_order_item t14 (nolock) on t14.cd_order = t1.cd_order and t14.cd_product = 11017
	                                inner join tbl_order_item_customization t15 (nolock) on t15.cd_order_items = t14.cd_order_items
                                where 
	                                t1.fl_created in(0,1)
	                                and t1.cardtext is not null
                                    ";

                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(query, conn))
                    {
                        comm.CommandTimeout = 300000;
                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            OrderProductionCardMachine order = new OrderProductionCardMachine
                            {
                                TotalItens = Convert.ToInt64(reader["TotalItens"].ToString()),
                                NomeCliente = reader["NomeCliente"].ToString(),
                                CdCardMachineItems = Convert.ToInt64(reader["CdCardMachineItems"].ToString()),
                                DtCreated = Convert.ToDateTime(reader["DtCreated"].ToString()),
                                FlCreated = Convert.ToInt16(reader["FlCreated"].ToString()),
                                CdCard = Convert.ToInt64(reader["CdCard"].ToString()),
                                CdOrder = Convert.ToInt64(reader["CdOrder"].ToString()),
                                CdOrderItems = Convert.ToInt64(reader["CdOrderItems"].ToString()),
                                DestinatarioNumeroEndereco = reader["DestinatarioNumeroEndereco"].ToString(),
                                DestinatarioComplementoEndereco = reader["DestinatarioComplementoEndereco"].ToString(),
                                DestinatarioCidadeEndereco = reader["DestinatarioCidadeEndereco"].ToString(),
                                DestinatarioBairroEndereco = reader["DestinatarioBairroEndereco"].ToString(),
                                DestinatarioEstadoEndereco = reader["DestinatarioEstadoEndereco"].ToString(),
                                DestinatarioLogradouroEndereco = reader["DestinatarioLogradouroEndereco"].ToString(),
                                DestinatarioCepEndereco = reader["DestinatarioCepEndereco"].ToString(),
                                DestinatarioNome = reader["DestinatarioNome"].ToString(),
                                CodigoRastreio = reader["CodigoRastreio"].ToString(),
                                RemetenteNome = reader["RemetenteNome"].ToString(),
                                RemetenteCidadeEndereco = reader["RemetenteCidadeEndereco"].ToString(),
                                RemetenteComplementoEndereco = reader["RemetenteComplementoEndereco"].ToString(),
                                RemetenteBairroEndereco = reader["RemetenteBairroEndereco"].ToString(),
                                RemetenteEstadoEndereco = reader["RemetenteEstadoEndereco"].ToString(),
                                RemetenteLogradouroEndereco = reader["RemetenteLogradouroEndereco"].ToString(),
                                RemetenteNumeroEndereco = reader["RemetenteNumeroEndereco"].ToString(),
                                RemetenteCepEndereco = reader["RemetenteCepEndereco"].ToString(),
                                Imagem = reader["Imagem"].ToString(),
                                Assinatura = reader["Assinatura"].ToString(),
                                Mensagem = reader["Mensagem"].ToString(),
                                Nome = reader["Nome"].ToString(),
                                Frase = reader["Frase"].ToString(),
                                CdChannel = reader["CdChannel"].ToString(),
                                CardText = ""
                               
                            };

                            listOrderProductionCardMachine.Add(order);
                        }
                    }

                    conn.Close();
                }

                Console.WriteLine("|--Range de dados coletados da Webstore.OrderProductionCardMachine: " + listOrderProductionCardMachine.First().CdCardMachineItems.ToString() + " ao " + listOrderProductionCardMachine.Last().CdCardMachineItems.ToString());
                Console.WriteLine("Finalizando coleta de dados da Webstore.OrderProductionCardMachine: " + DateTime.Now.ToString());

                return  listOrderProductionCardMachine;
            }

            public List<String> ExistsItemOrderPreProduction(List<OrderPreProduction> listCardMachineItems)
            {
                String Ids = String.Join(",", listCardMachineItems.Select(x => String.Concat("'", x.Idempotency,"'")).ToList());

                List<String> listOrderPreProduction = new List<String>();
                try
                {
                    
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroRead"].ConnectionString))
                    {
                        String query = @"
                                        select 
	                                        CONCAT(IdpedIdo,IdPedIdoItem,codigo,plataforma) Idempotency
                                        from 
	                                        OrderPreProduction
                                        where 
                                            CONCAT(IdpedIdo,IdPedIdoItem,codigo,plataforma) in ({0})
                                        ";
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(String.Format(query,Ids), conn))
                        {
                            comm.CommandTimeout = 300000;
                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {
                                listOrderPreProduction.Add(reader["Idempotency"].ToString());
                            }
                        }

                        conn.Close();
                    }

                }
                catch (Exception ex)
                {

                }

                return listOrderPreProduction;
            }

            public List<CartaoSaldo> GetSaldoProcessadora(List<Model.OrderPreProduction> listOrderPreProduction )
            {

                var ids = String.Join(",",listOrderPreProduction.Select(x => x.JSON.Conteudo.Cartao.CodigoCartao).ToList());
                List<Model.CartaoSaldo> SaldoCartoes = new List<Model.CartaoSaldo>();

                String Query = @"
                                select 
                                    c.CodigoCartao,
                                    case 
                                        when la.id is null then
                                            lc.Saldo
                                        else
                                            ledger.get_account_balance_fn(la.id)
                                        end as Saldo
                                from 
                                    cartoes c    
                                    inner join ContasTitulares ct on ct.CodigoContaTitular = c.CodigoContaTitular
                                    left join ContasSaldos cc on c.CodigoContaTitular = cc.CodigoContaTitular
                                    left join ledger.accounts la on la.id = cc.CodigoContaSaldo
                                    left join accounts.Contracts ac on ac.id = la.contract_id
                                    left join LimitesCartoes lc on c.CodigoCartao = lc.CodigoCartao
                                where       
	                                c.CodigoCartao in({0})
                                  ";
                
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProcessadoraRead"].ConnectionString))
                {
                    conn.Open();

                    try
                    {
                        using (SqlCommand comm = new SqlCommand(String.Format(Query,ids), conn))
                        {
                            comm.CommandTimeout = 30000000;
                            var reader = comm.ExecuteReader();


                            while (reader.Read())
                            {
                                SaldoCartoes.Add(new Model.CartaoSaldo() {
                                    CodigoCartao = Convert.ToInt64(reader["CodigoCartao"]),
                                    Saldo = Convert.ToDecimal(reader["Saldo"])
                                });
                            }
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        
                        Logs.Instance.RegisterLog("BiroLegacyImporter", "error", ex.Message.ToString(), "GetSaldoProcessadora", ex.StackTrace.ToString());
                    }

                    conn.Close();
                        
                }

                return SaldoCartoes;

            }

            public void UpdateTblCardMachineItems(List<long> listCardMachineItems)
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreProd"].ConnectionString))
                {
                    String query = "UPDATE tbl_cardmachine_items SET fl_created = 1 WHERE cd_cardmachine_items In({0})";

                    conn.Open();

                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        using (SqlCommand comm = new SqlCommand(String.Format(query, String.Join(",", listCardMachineItems), conn, transaction)))
                        {
                            comm.ExecuteScalar();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Logs.Instance.RegisterLog("BiroLegacyImporter", "error", ex.Message.ToString(), "UpdateTblCardMachineItems", ex.StackTrace.ToString());
                    }

                    conn.Close();
                }
            }

            public void InsertOrderPreProduction(List<Model.OrderPreProduction> listOrderPreProduction)
            {
                String result = "";
                var insert = @"INSERT INTO OrderPreProduction
                                       (
                                        idstatusorderpreproduction,
                                        Deleted,
                                        DataImportacao,
                                        totalItens,
                                        IdpedIdo,
                                        IdPedIdoItem,
                                        Codigo,
                                        Conteudo,
                                        DataPedido,
                                        Plataforma
                                        ) values ";

                result = String.Join(";",listOrderPreProduction.Select(o => String.Concat(insert,"(",(int)OrderPreProduction.StatusOrderPreProduction.Importado,",0,getdate(),", o.TotalItens, ",", o.IdpedIdo, ",", o.IdPedIdoItem, ",", o.Codigo, ",", "'", o.Conteudo, "',", "'", o.DataPedido.ToString("yyyy-MM-dd HH:mm:ss"),"','",o.Plataforma,"')")).ToList());

                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroProd"].ConnectionString))
                {
                    conn.Open();

                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        using (SqlCommand comm = new SqlCommand(result, conn, transaction))
                        {
                            comm.ExecuteScalar();
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Logs.Instance.RegisterLog("BiroLegacyImporter", "error", ex.Message.ToString(), "InsertOrderPreProduction", ex.StackTrace.ToString());
                    }

                    conn.Close();
                }

            }

            public Model.CustomReturn CardHasChip(Int64 CodigoCartao)
            {
                Model.CustomReturn returnData = new Model.CustomReturn();

                try
                {
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProcessadoraRead"].ConnectionString))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Processadora.Queries.CardHasChip(CodigoCartao), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var result = comm.ExecuteScalar();

                            if (result != null && result != "")
                            {
                                returnData.Success = true;
                                returnData.Data = Convert.ToBoolean(result);
                            }
                            else
                            {
                                Logs.Instance.RegisterLog("BiroLegacyImporter", "warning", String.Format("O cartão informado não foi localizado na processadora:{0}", CodigoCartao), "CardHasChip", "query:" + DataQueries.Processadora.Queries.CardHasChip(CodigoCartao));
                                returnData.Success = false;
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    returnData.Success = false;
                    Console.WriteLine("Ocorreu um erro na hora de validar se o cartão tem chip");
                    Logs.Instance.RegisterLog("BiroLegacyImporter", "error", ex.Message.ToString(), "CardHasChip", "CodigoCartao:" + CodigoCartao);
                }

                return returnData;

            }

        }
    }
}

﻿using BiroLegacyImporter.DataBase.SQL;
using BiroLegacyImporter.Services;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace BiroLegacyImporter.Commands
{
    class Process
    {
        public static void Start()
        {

            var listMachineItems = Execute.Query.Instance.GetCardMachineItems();
            var listOrderProductionCardMachine = Execute.Query.Instance.GetOrderProductionCardMachine();

            var list1 = Services.DTO.Instance.MapperTblCardMachineToOrderPreProduction(listMachineItems);
            var list2 = Services.DTO.Instance.MapperOrderProductionCardMachineToOrderPreProduction(listOrderProductionCardMachine);

            var listFinal = list1.Union(list2).ToList();

            listFinal = Utils.Instance.SetCharacteristics(listFinal);             

            var listOrderPreProduction = Services.Filters.Instance.RemoveDuplicatedItems(listFinal);

            if (listOrderPreProduction.Count > 0)
            {
                var existsItemOrderPreProduction = Execute.Query.Instance.ExistsItemOrderPreProduction(listOrderPreProduction);

                if (existsItemOrderPreProduction.Count > 0)
                {
                    listOrderPreProduction = Filters.Instance.RemoveOrderPreProductionProcessed(listOrderPreProduction, existsItemOrderPreProduction);
                }

                Execute.Query.Instance.InsertOrderPreProduction(listOrderPreProduction);
               //Execute.Query.Instance.UpdateTblCardMachineItems(listMachineItems.Select(x => x.CdCardMachineItems).ToList());
            }
            else
            {
                Console.WriteLine("Não há item para serem processados");
            }

            //Logs.Instance.RegisterLog("BiroLegacyImporter", "error", ex.Message.ToString(), "Start", ex.StackTrace.ToString());
        }

    }
}

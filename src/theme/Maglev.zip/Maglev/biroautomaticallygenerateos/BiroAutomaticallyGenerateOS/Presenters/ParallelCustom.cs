﻿using BiroAutomaticallyGenerateOS.DataBase.SQL;
using BiroAutomaticallyGenerateOS.Services;
using ConsoleTables;
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BiroAutomaticallyGenerateOS.Presenters
{
    class ParallelCustom
    {
        public static void Start()
        {

            Stopwatch sw = Stopwatch.StartNew();

            var machineItemsGroupByChannel = Execute.Query.Instance.GetMachineItemsGroupByChannel();
            Console.WriteLine("Tempo Decorrido: {0:f2} s", sw.Elapsed.TotalMinutes);


            Console.WriteLine("        Resumo Geral da quantidade de cartoes pendentes por Canal");
            ConsoleTable.From<Models.CardMachineResumo>(machineItemsGroupByChannel).Write();

            Int32 pageSize = 1000;

            sw = Stopwatch.StartNew();
            if (machineItemsGroupByChannel.Count > 0)
            {
                foreach (var channel in machineItemsGroupByChannel)
                {

                    Console.WriteLine("Processando cartoes pendente do canal: {0}. Total de cartoes: {1}", channel.Canal, channel.Total);

                    Int64 totalItems = Execute.Query.Instance.GetTotalItemsMachineByChannel(channel.Canal);
                    Int32 totalPages = Convert.ToInt32(Math.Ceiling((double)totalItems / pageSize));

                    List<Int32> PendingLots = new List<Int32>();

                    for (int index = 1; index <= totalPages;)
                    {

                        var machineItemByChannel = Execute.Query.Instance.GetItemsMachineByChannel(index, pageSize, channel.Canal);
                        var totalresultado = machineItemByChannel.Chunks(100);
                        
                        Fillin(PendingLots, index, pageSize, channel.Canal, totalresultado);

                        index = 1;
                        totalPages -= 1;

                    }
                    //PendingLots.ForEach(x => Lot.Instance.UpdatePropertiesLot(x));

                }
            }
            else
            {
                Console.WriteLine("Nao ha items pendentes para geracao de OS");
            }

            Console.WriteLine("Fim do processamento");
            Console.WriteLine("Tempo Decorrido: {0:f2} ", sw.Elapsed.TotalMinutes);

            Console.ReadKey();


        }

        public static List<Int32> Fillin(List<Int32> PendingLots, Int32 index, Int32 pageSize, Int64 codigoCanal, IEnumerable<IEnumerable<Models.MachineItems>> machineItems)
        {
                var degreeOfParallelism = Environment.ProcessorCount;
                var tasks = new Task[machineItems.Count()];

                int i = 0;

                foreach (var items in machineItems)
                {
                    var machineItemByChannel = items.ToList();

                    if (machineItemByChannel.Count > 0)
                    {
                        tasks[i] = new Task(
                            () =>
                            {
                                Console.WriteLine(" ");
                                Console.WriteLine("Validando se os cartoes tem Chip... " + Task.CurrentId);
                                foreach (var card in machineItemByChannel)
                                {
                                    card.IsChip = Utils.Parse.Instance.CardHasChip(card.cd_card);
                                }
                                Console.WriteLine("Fim da validacao " + Task.CurrentId);
                                Console.WriteLine(" ");

                                var teset = Utils.Parse.Instance.SetTypeOsByChannel(machineItemByChannel.ToList(), codigoCanal);

                                teset = Utils.Parse.Instance.SetTrackingCode(teset);

                                var Lots = Filter.Instance.SeparateItemsByCharacteristicsToGenerateLotOS(teset);

                                foreach (var lot in Lots)
                                {
                                    var IdLot = Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip) == 0 ? Lot.Instance.CreateLotOS(lot.OsType, lot.HasChip) : Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip);

                                    PendingLots.Add(IdLot);

                                    var itemsProcessed = Execute.Query.Instance.GetItemsByLotOnBiro(IdLot);
                                    Console.WriteLine("Total de Items que ja foram Processados: {0}", itemsProcessed.Count);

                                    // seta todos os items para o mesmo lot 
                                    lot.ItemsMachine.Select(x => { x.IdOs = IdLot; return x; }).ToList();

                                    var resultadoFinal = lot.ItemsMachine.Where(x => !itemsProcessed.Contains(x.cd_order_cd_order_items)).ToList();
                                    Console.WriteLine("Total de Items Pendentes Processamento: {0}", resultadoFinal.Count);
                                    Console.WriteLine(" ");

                                     Utils.Instance.SaveMachineItemsInItemsOnBiro(resultadoFinal);
                                }



                            });
                    }

                    i = i + 1;
                }

                Parallel.ForEach(tasks.ToList(), new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, thread =>
                {
                    Object lockObj = new Object();                 

                    lock (lockObj)
                    {
                        thread.Start();

                        bool isDone = thread.IsCompleted;
                       // if (isDone)
                       // {
                        //   thread.Dispose();
                      //  }
                        
                    }
                });

                Console.WriteLine("");

            // Task[] tasksArray = tasks.Where(t => t != null).ToArray();
            // if (tasksArray.Length > 0) Task.WaitAll(tasksArray, -1);

            Task.WaitAll(tasks);

            return PendingLots;

        }

    }
}

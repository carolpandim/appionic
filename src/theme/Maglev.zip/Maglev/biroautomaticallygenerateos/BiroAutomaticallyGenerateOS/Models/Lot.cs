﻿using System.Collections.Generic;

namespace BiroAutomaticallyGenerateOS.Models
{
    class Lot
    {
        public int OsType { get; set; }
        public int HasChip { get; set; }
        public List<MachineItems> ItemsMachine { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroAutomaticallyGenerateOS.Models
{
    class CardMachineResumo
    {
        public Int64 Canal { get; set; }
        public String NomeCanal { get; set; }
        public Int64 Total { get; set; }

    }
}

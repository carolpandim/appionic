﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroAutomaticallyGenerateOS.Models
{
    class MetodoTransportador
    {
        public int idtransportador { get; set; }
        public int idtransportadormetodo { get; set; }
        public int sla { get; set; }
    }
}

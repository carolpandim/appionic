﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BiroAutomaticallyGenerateOS.Models
{
    class MachineItems
    {

        public Int64 cd_cardmachine_items { get; set; }
        public Int64 IdOs { get; set; }
        public Int64 cd_order { get; set; }
        public Int64 cd_order_items { get; set; }
        public int cd_order_direct { get; set; }
        public Int64 cd_card { get; set; }
        public String Imagem { get; set; }
        public Int64 cd_order_tracking { get; set; }
        public Int64? nr_order_items { get; set; }
        public Int64 cd_channel { get; set; }
        public int fl_created { get; set; }
        public Decimal? vl_card { get; set; }
        public DateTime dt_created { get; set; }
        public String ds_logo { get; set; }
        public String RecipientAddress { get; set; }
        public String RecipientCity { get; set; }
        public String RecipientComplement { get; set; }
        public String RecipientDistrict { get; set; }
        public String RecipientState { get; set; }
        public String RecipientZipCode { get; set; }
        public String NumeroDestinatario { get; set; }
        public String NomeRemetente { get; set; }
        public String EnderecoRemetente { get; set; }
        public String NumeroRemetente { get; set; }
        public String ComplementoRemetente { get; set; }
        public String BairroRemetente { get; set; }
        public String CepRemetente { get; set; }
        public String CidadeRemetente { get; set; }
        public String EstadoRemetente { get; set; }
        public String Mensagem { get; set; }
        public String Assinatura { get; set; }
        public Int32 IdTransportador { get; set; }
        public Int32 IdTransportadorMetodo { get; set; }
        public String Titulo { get; set; }
        public String RecipientName { get; set; }
        public String CardMessage { get; set; }

        public Int32 Customer_Shipping_Costs
        {
            get { return 0; }
        }
        public String Sales_Channel { get; set; }

        public Boolean Scheduled
        {
            get { return false; }
        }
        public DateTime? Shipped_Date { get; set; }
        public String Shipment_Order_Type { get; set; }
        public Int32 Delivery_Method_Id { get; set; }
        public DateTime? Estimated_Delivery_Date { get; set; }
        public String Email { get; set; }
        public String Phone { get; set; }
        public String CellPhone { get; set; }

        public Boolean Is_Company
        {
            get { return true; }
        }
        public String Federal_Tax_Payer_Id { get; set; }


        public String Shipping_Country
        {
            get { return "Brasil"; }

        }

        public Int32 Shipment_Order_Volume_Number
        {
            get { return 1; }
            
        }

        public String Volume_Name
        {
            get { return "0"; }
        }
        public Decimal Weight { get; set; }

        public String Volume_Type_Code
        {
            get { return "BOX"; }
        }

        public Decimal Width
        {
            get { return 1; }
        }

        public Decimal Height
        {
            get { return 1; }
        }


        public Decimal Length
        {
            get { return 1; }
        }
        public Int32 Products_Quantity { get; set; }

        public Boolean Is_Icms_Exempt
        {
            get { return true; }
        }

        public String Invoice_Series
        {
            get { return "1"; }
        }


        public String Invoice_Key
        {
            get { return "1111111111111111111111111111111111111111111"; }
        }
        public DateTime? Invoice_Date { get; set; }
        public Decimal Invoice_Total_Value { get; set; }

        public String CFOP
        {
            get { return "1"; }
        }

        public String Origin_WareHouse_Code
        {
            get { return "HubCard"; }
        }
        public String NomeCartao { get; set; }
        public DateTime? Data_Pedido { get; set; }
        public DateTime? Data_Biro { get; set; }
        public bool IsChip { get; set; }
        public int OsType { get; set; }
        private string _cardtext;
        public String cardtext
        {
            set
            {
                _cardtext = value.ToString();
                var content = _cardtext.Split('<').ToList();
                var itemLista = new List<Content>();
                foreach (var itemContent in content)
                {
                    var text = itemContent.Split('>').ToList();
                    if (text.Count() > 1)
                    {
                        itemLista.Add(new Content()
                        {

                            Key = text[0],
                            Value = text[1]

                        });

                    }

                }

                RecipientAddress = itemLista.Where(x => x.Key == "street").Select(x => x.Value).FirstOrDefault() + ", " + itemLista.Where(x => x.Key == "streetnumber").Select(x => x.Value).FirstOrDefault();
                RecipientCity = itemLista.Where(x => x.Key == "city").Select(x => x.Value).FirstOrDefault();
                Imagem = itemLista.Where(x => x.Key == "vhd").Select(x => x.Value).FirstOrDefault();
                RecipientComplement = itemLista.Where(x => x.Key == "addresscomp").Select(x => x.Value).FirstOrDefault();
                RecipientDistrict = itemLista.Where(x => x.Key == "neigh").Select(x => x.Value).FirstOrDefault();
                RecipientState = itemLista.Where(x => x.Key == "stateacronym").Select(x => x.Value).FirstOrDefault();
                RecipientZipCode = itemLista.Where(x => x.Key == "zipcode").Select(x => x.Value).FirstOrDefault();
                Mensagem = itemLista.Where(x => x.Key == "xenvmsg").Select(x => x.Value).FirstOrDefault();
                Assinatura = itemLista.Where(x => x.Key == "xenvsig").Select(x => x.Value).FirstOrDefault();
                Titulo = itemLista.Where(x => x.Key == "xenvtit").Select(x => x.Value).FirstOrDefault();
                RecipientName = itemLista.Where(x => x.Key == "recipientname").Select(x => x.Value).FirstOrDefault();
                CardMessage = itemLista.Where(x => x.Key == "emb3").Select(x => x.Value).FirstOrDefault();
                
            }
            get
            {
                return _cardtext;
            }
        }
        public String cd_order_cd_order_items { get; set; }
        public String Plataforma { get; set; }



        public class Content
        {
            public String Key { get; set; }
            public String Value { get; set; }
        }
    }
}

﻿using BiroAutomaticallyGenerateOS.DataBase.SQL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Diagnostics;
using System.Reflection;

namespace BiroAutomaticallyGenerateOS.Services
{
    class Utils
    {
        private static Utils oUtils;

        public static Utils Instance { get { oUtils = oUtils ?? new Utils(); return oUtils; } }

        public void SaveMachineItemsInItemsOnBiro(List<Models.MachineItems> machineItems)
        {
            foreach (var item in machineItems)
            {
                Execute.Query.Instance.NovoInsertMachineItemsAndUpdateMachineItemsToCreated(item);
            }
        }

        public class Parse
        {
            private static Parse oParse;

            public static Parse Instance { get { oParse = oParse ?? new Parse(); return oParse; } }

            public Boolean CardHasChip(Int64 CodigoCartao)
            {
                bool result;
                result = Execute.Query.Instance.CardHasChip(CodigoCartao);
                return result;

            }

            public List<Models.MachineItems> SetTypeOsByChannel(List<Models.MachineItems> list, Int64 CodigoCanal)
            {
          
                Int32 result;
                result = Execute.Query.Instance.GetTypeOsByChannel(CodigoCanal);

                if (result == 0)
                    Services.Logs.Instance.RegisterLog(Assembly.GetExecutingAssembly().GetName().Name.ToString(), "Não foi possivel localizar o tipo de OS pelo canal", "SetTypeOsByChannel","CodigoCanal:"+CodigoCanal);

                list = list.Select(x => { x.OsType = result; return x; }).ToList();
                return list;
            }

            public List<Models.MachineItems> SetTrackingCode(List<Models.MachineItems> list)
            {
                foreach (var items in list.GroupBy(x => x.cd_order))
                {
                   items.Select(x => { x.cd_order_tracking = x.cd_order; return x; }).ToList();
                }
                var teste = list.Where(x => x.cd_order_tracking == 0).ToList(); // somente para validar se algum ordem tracking nao foi preenchido
                return list;
            }

            public List<Models.MachineItems> SetTransportes(List<Models.MachineItems> list)
            {
                foreach (var items in list.GroupBy(x => x.RecipientZipCode))
                {

                    var result = Execute.Query.Instance.GetTransporte(Convert.ToInt64(items.Key));
                    items.Select(x =>
                    {
                        x.Estimated_Delivery_Date = Convert.ToDateTime(x.Data_Pedido).AddDays(Convert.ToInt32(result.sla));
                        //x.Estimated_Delivery_Date = result.sla;
                        x.IdTransportador = result.idtransportador;
                        x.IdTransportadorMetodo = result.idtransportadormetodo; return x;
                    }).ToList();
                }
                var teste = list.Where(x => x.cd_order_tracking == 0).ToList(); // somente para validar se algum ordem tracking nao foi preenchido
                return list;
            }
        }
    }
}

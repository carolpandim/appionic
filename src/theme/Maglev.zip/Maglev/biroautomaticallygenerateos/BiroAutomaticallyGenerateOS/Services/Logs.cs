﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BiroAutomaticallyGenerateOS.Services
{
    class Logs
    {
        
        private static Logs oLogs;

        public static Logs Instance { get { oLogs = oLogs ?? new Logs(); return oLogs; } }


        public void RegisterLog(String Origin, String MessageErro, String Method, String Property) {

            String query = @"
                            INSERT INTO dbo.logs
                                       (data,origem,mensagem_erro,metodo,propriedades)
                                 VALUES
                                       (@Data,@Origin,@MessageErro,@Method,@Property)
                        ";

            query = String.Format(query, Origin, MessageErro, Method, Property);

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroProd"].ConnectionString))
            {
                conn.Open();

                try
                {
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Data", DateTime.Now);
                        command.Parameters.AddWithValue("@Origin", Origin);
                        command.Parameters.AddWithValue("@MessageErro", MessageErro);
                        command.Parameters.AddWithValue("@Method", Method);
                        command.Parameters.AddWithValue("@Property", Property);

                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                conn.Close();
            }


        }
    }
}

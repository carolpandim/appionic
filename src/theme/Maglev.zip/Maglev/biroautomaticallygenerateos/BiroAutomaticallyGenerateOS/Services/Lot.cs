﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace BiroAutomaticallyGenerateOS.Services
{
    class Lot
    {
        private static Lot oLot;

        public static Lot Instance { get { oLot = oLot ?? new Lot(); return oLot; } }
        
        public Int32 CreateLotOS(Int32 OsType, int HasChip)
        {

            Int32 idLot = 0;

            var query = @"insert into biro_new.dbo.os(idstatus, data,idostype,possuichip)values(8,GETDATE(),{0},{1}); SELECT SCOPE_IDENTITY()";

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroProd"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query,OsType,HasChip), conn))
                {
                    comm.CommandTimeout = 300000;
                    var result = comm.ExecuteScalar();

                    idLot = Convert.ToInt32(result);

                }

                conn.Close();
            }

            return idLot;
        }

        public void UpdatePropertiesLot(Int32 idLot)
        {
         
            var query = "update biro_new.dbo.os set idstatus=1 where idos={0}";

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroProd"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query, idLot), conn))
                {
                    comm.CommandTimeout = 300000;
                    var result = comm.ExecuteScalar();

                    idLot = Convert.ToInt32(result);

                }

                conn.Close();
            }

        }

        public Int32 ExistsPendingBatch(Int32 OsType, int HasChip)
        {
            Int32 IdLot;
            //pega o primeiro lot da data atual com status importado
            var query = @"
                        select
	                        top 1
	                        idos
                        from 
	                        biro_new.dbo.os
                        where 
	                        idostype = {0}
	                        and possuichip = {1}
                            and idstatus =8
                        ";

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroRead"].ConnectionString))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query,OsType,HasChip), conn))
                {
                    comm.CommandTimeout = 300000;
                    IdLot = Convert.ToInt32(comm.ExecuteScalar());
                }

                conn.Close();
            }
            return IdLot;
        }

    }
}

﻿using BiroAutomaticallyGenerateOS.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BiroAutomaticallyGenerateOS.Services
{
    class Filter
    {
        private static Filter oFilter;

        public static Filter Instance { get { oFilter = oFilter ?? new Filter(); return oFilter; } }

        public List<Models.Lot> SeparateItemsByCharacteristicsToGenerateLotOS(List<MachineItems> list)
        {
            //separa por chip. SIM=1, NAO=0
            var lots = SeparateByChip(list);

            //separar por tipo de OS
            lots= SeparateByTypeOs(lots);

            return lots;
        }

        private List<Models.Lot> SeparateByChip(List<MachineItems> list)
        {
            List<Models.Lot> Lots = new List<Models.Lot>();

            foreach (var items in list.GroupBy(x => x.IsChip))
            {
                Lots.Add(new Models.Lot()
                {
                    HasChip = Convert.ToByte(items.Select(x => x.IsChip).FirstOrDefault()),
                    ItemsMachine = items.ToList()
                });
            }

            return Lots;

        }

        public List<Models.Lot> SeparateByTypeOs(List<Models.Lot> Lots)
        {
            List<Models.Lot> newLots = new List<Models.Lot>();

            foreach (var lot in Lots)
            {
                foreach (var items in lot.ItemsMachine.GroupBy(x => x.OsType))
                {
                    newLots.Add(new Models.Lot()
                    {
                        HasChip = Convert.ToByte(items.Select(x => x.IsChip).FirstOrDefault()),
                        OsType = Convert.ToByte(items.Select(x => x.OsType).FirstOrDefault()),
                        ItemsMachine = items.ToList()
                    });
                }
            }

            return newLots;
        }
    }
}

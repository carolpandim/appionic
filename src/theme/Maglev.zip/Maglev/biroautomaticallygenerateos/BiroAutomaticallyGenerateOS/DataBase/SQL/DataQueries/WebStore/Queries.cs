﻿using System;
using System.Data.SqlClient;

namespace BiroAutomaticallyGenerateOS.DataBase.SQL.DataQueries.WebStore
{
    class Queries
    {
        public static String GetMachineItemsByChannel(Int32 pageIndex, Int32 pageSize, Int64 codigoCanal)
        {
            String query = @"
                            select 
	                            mach.cd_cardmachine_items,
	                            mach.cd_order,
	                            iif(o.cd_new_order_context is null,'L', 'N') plataforma,
	                            o.dt_sale dataPedido,
	                            mach.dt_created DataBiro,
	                            mach.cd_order_items,
	                            mach.cd_order_direct,
	                            mach.cd_card,
	                            mach.nr_order_items,
	                            mach.cardtext,
	                            mach.cd_channel,
	                            mach.fl_created,
                                mach.dt_created,
	                            mach.vl_card,
	                            mach.ds_logo
                            from 
	                            Webstore.dbo.tbl_cardmachine_items mach
	                            inner join webstore.dbo.tbl_order o on mach.cd_order = o.cd_order
                            where
	                            mach.fl_created = 0
	                            and mach.cd_channel in ({2})
                            order by cd_card
                            OFFSET (({0} - 1) * {1}) ROWS
                            FETCH NEXT {1} ROWS ONLY
                             ";
            query = String.Format(query, pageIndex, pageSize, codigoCanal);
            return query;
        }

        public static String GetTotalMachineItemsByChannel(Int64 codigoCanal)
        {
            String query = @"
                            select 
                                count(0) 'Total'
                            from 
	                            Webstore.dbo.tbl_cardmachine_items mach
                            where
	                            mach.fl_created = 0
	                            and mach.cd_channel in ({0})
                             ";
            query = String.Format(query, codigoCanal);
            return query;
        }

        public static String GetMachineItemsGroupByChannel()
        {
            String query = @"
                            select 
	                            mach.cd_channel 'Canal', COUNT(0)'Total', c.ds_channel 'NomeCanal'
                            from 
	                            Webstore.dbo.tbl_cardmachine_items mach
	                            inner join Webstore.dbo.tbl_channel c on mach.cd_channel = c.cd_channel
                            where
	                            fl_created = 0
                            group by mach.cd_channel,c.ds_channel
                            order by Total desc
                             ";
            return query;
        }

        public static String GetTypeOsByChannel(Int64 codigoCanal)
        {
            String query = @"
                            select 
	                            t.idostype
                            from 
	                            biro_new.dbo.osType t
                            where
	                            t.codigo = {0} 
                             ";
            query = String.Format(query, codigoCanal);
            return query;
        }

        public static String UpdateTblCardMachineItemsToCreated(Int64 cd_cardmachine_items)
        {
            String query = @"update Webstore.dbo.tbl_cardmachine_items set fl_created=1 where cd_cardmachine_items={0}";
            query = String.Format(query, cd_cardmachine_items);

            return query;
        }
    }
}

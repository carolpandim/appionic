﻿using BiroAutomaticallyGenerateOS.DataBase.SQL.DataQueries;

namespace BiroAutomaticallyGenerateOS.DataBase.SQL
{
    class Execute
    {
        private static Execute oExecute;

        public static Execute Instance { get { oExecute = oExecute ?? new Execute(); return oExecute; } }

        public class Query : Queries
        {
            private static Query oQuery;

            public static Query Instance { get { oQuery = oQuery ?? new Query(); return oQuery; } }
        }
    
    }
}

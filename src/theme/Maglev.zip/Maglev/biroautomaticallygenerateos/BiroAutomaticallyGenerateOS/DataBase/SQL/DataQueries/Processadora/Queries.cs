﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroAutomaticallyGenerateOS.DataBase.SQL.DataQueries.Processadora
{
    class Queries
    {
        public static String CardHasChip(Int64 Codigocartao)
        {
            String query = @"declare @codigocontatitular int
                            declare @codigomodalidade int
                            declare @codigocartao int
                            declare @codigocanal int
                            declare @codigoProduto int

 
                            select @codigocartao = codigocartao, @codigocontatitular = CodigoContaTitular, @codigomodalidade = CodigoModalidade from cartoes where codigocartao in ({0})
                            select @codigocanal = CodigoCanal from cartoes_valepresente where codigocartao = @codigocartao
                            select @codigoProduto = codigoProduto from modalidades where CodigoModalidade = @codigomodalidade

                            select
	                            top 1
	                            case Valor when 'N' then 'false'
			                               When 'S' then 'true'
	                            end 'HasChip'
                            from
	                            (

	                            select ctp.Valor, 4 as Peso from ProdutosParametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
	                            where CodigoProduto = @codigoProduto and p.CodigoParametro = 26
	                            union all
	                            select ctp.Valor, 3 as Peso from ModalidadesParametros ctp (nolock) inner join  parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
	                            where CodigoModalidade = @codigomodalidade and p.CodigoParametro = 26
	                            union all
	                            select ctp.Valor, 2 as Peso from canaisparametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
	                            where codigocanal = @codigocanal and p.CodigoParametro = 26
	                            union all
	                            select  ctp.Valor, 1 as Peso from contastitularesparametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
	                            where codigocontatitular = @codigocontatitular and p.CodigoParametro = 26
	                            ) as res
                            order by Peso
                            ";
            query = String.Format(query, Codigocartao);
            return query;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using BiroAutomaticallyGenerateOS.Services;
using System.Threading.Tasks;

namespace BiroAutomaticallyGenerateOS.DataBase.SQL.DataQueries
{
    class Queries
    {
        public  Boolean CardHasChip(Int64 CodigoCartao)
        {
            bool result = false;

            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ProcessadoraRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(Processadora.Queries.CardHasChip(CodigoCartao), conn))
                    {
                        comm.CommandTimeout = 30000;
                        result = Convert.ToBoolean(comm.ExecuteScalar());
                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), ex.Message.ToString(), "CardHasChip", "CodigoCartao:" + CodigoCartao);
                Console.WriteLine("Ocorreu um erro na hora de validar se o cartão tem chip");
            }

            return result;

        }

        public  List<Models.MachineItems> GetItemsMachineByChannel(Int32 pageIndex, Int32 pageSize, Int64 codigoCanal)
        {
            List<Models.MachineItems> items = new List<Models.MachineItems>();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(WebStore.Queries.GetMachineItemsByChannel(pageIndex,pageSize,codigoCanal), conn))
                    {
                        comm.CommandTimeout = 300000;
                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {

                            items.Add(new Models.MachineItems()
                            {
                                cd_cardmachine_items = Convert.ToInt64(reader["cd_cardmachine_items"]),
                                cd_order = Convert.ToInt64(reader["cd_order"]),
                                Plataforma = reader["plataforma"].ToString(),
                                Data_Pedido = Convert.ToDateTime(reader["dataPedido"]),
                                Data_Biro = Convert.ToDateTime(reader["DataBiro"]),
                                cd_order_items = Convert.ToInt64(reader["cd_order_items"]),
                                cd_order_direct = Convert.ToInt32(reader["cd_order_direct"]),
                                cd_card = Convert.ToInt64(reader["cd_card"]),
                                nr_order_items = Convert.ToInt64(reader["nr_order_items"]),
                                cardtext = reader["cardtext"].ToString(),
                                cd_channel = Convert.ToInt64(reader["cd_channel"]),
                                fl_created = Convert.ToInt32(reader["fl_created"]),
                                vl_card = Convert.ToDecimal(reader["vl_card"]),
                                dt_created = Convert.ToDateTime(reader["dt_created"]),
                                ds_logo = Convert.ToString(reader["ds_logo"]),
                                cd_order_cd_order_items = String.Concat(reader["cd_order"].ToString(), reader["cd_order_items"].ToString())
                            });

                        }

                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:"+ex.Message.ToString(), "GetItemsMachineByChannel", "query:"+WebStore.Queries.GetMachineItemsByChannel(pageIndex, pageSize, codigoCanal));
                Console.WriteLine("Um ou mais campos obrigatórios da Tbl_CardMachine está nulo");
            }
            return items;

        }

        public  Int64 GetTotalItemsMachineByChannel(Int64 codigoCanal)
        {
            Int64 result =0;
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(WebStore.Queries.GetTotalMachineItemsByChannel(codigoCanal), conn))
                    {
                        comm.CommandTimeout = 300000;
                        result = Convert.ToInt64(comm.ExecuteScalar());

                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao pegar total de item por canal");
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "GetTotalItemsMachineByChannel", "query:" + WebStore.Queries.GetTotalMachineItemsByChannel(codigoCanal));

            }
            return result;

        }

        public  List<Models.CardMachineResumo> GetMachineItemsGroupByChannel()
        {
            List<Models.CardMachineResumo> items = new List<Models.CardMachineResumo>();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["WebStoreRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(WebStore.Queries.GetMachineItemsGroupByChannel(), conn))
                    {
                        comm.CommandTimeout = 300000;
                        var reader = comm.ExecuteReader();

                        while (reader.Read())
                        {

                            items.Add(new Models.CardMachineResumo()
                            {
                                Canal = Convert.ToInt64(reader["Canal"]),
                                Total = Convert.ToInt64(reader["Total"]),
                                NomeCanal = reader["NomeCanal"].ToString()
                            });

                        }

                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao tentar pegar resumo de pedido pendentes geração de cartão");
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "GetMachineItemsGroupByChannel", "query:" + WebStore.Queries.GetMachineItemsGroupByChannel());

            }
            return items;

        }

        public  Int32 GetTypeOsByChannel(Int64 CodigoCanal)
        {
            Int32 result = 0 ;

            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(WebStore.Queries.GetTypeOsByChannel(CodigoCanal), conn))
                    {
                        comm.CommandTimeout = 30000;
                        result = Convert.ToInt32(comm.ExecuteScalar());
                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu erro ao tentar pegar tipo de OS por canal:"+ CodigoCanal);
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "GetTypeOsByChannel", "query:" + WebStore.Queries.GetTypeOsByChannel(CodigoCanal));
            }

            return result;

        }
                
        public void NovoInsertMachineItemsAndUpdateMachineItemsToCreated(Models.MachineItems machineItems)
        {
            List<Models.DataBase.SQL.DataModels.Parameters> items = new List<Models.DataBase.SQL.DataModels.Parameters>();
            List<SqlParameter> filter = new List<SqlParameter>();

            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "assinatura", DataType = SqlDbType.VarChar, Value = machineItems.Assinatura });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairrodestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientDistrict });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairroremetente", DataType = SqlDbType.VarChar, Value = machineItems.BairroRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cellphone", DataType = SqlDbType.VarChar, Value = machineItems.CellPhone });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepdestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientZipCode });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepremetente", DataType = SqlDbType.VarChar, Value = machineItems.CepRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cfop", DataType = SqlDbType.VarChar, Value = machineItems.CFOP });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidadedestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientCity });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidaderemetente", DataType = SqlDbType.VarChar, Value = machineItems.CidadeRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "codigocartao", DataType = SqlDbType.BigInt, Value = machineItems.cd_card });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementodestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientComplement });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementoremetente", DataType = SqlDbType.VarChar, Value = machineItems.ComplementoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "customer_shipping_costs", DataType = SqlDbType.Int, Value = machineItems.Customer_Shipping_Costs });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "delivery_method_id", DataType = SqlDbType.Int, Value = machineItems.Delivery_Method_Id });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "email", DataType = SqlDbType.VarChar, Value = machineItems.Email });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecodestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientAddress });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecoremetente", DataType = SqlDbType.VarChar, Value = machineItems.EnderecoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadodestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientState });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadoremetente", DataType = SqlDbType.VarChar, Value = machineItems.EstadoRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estimated_delivery_date", DataType = SqlDbType.DateTime, Value = machineItems.Estimated_Delivery_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "federal_tax_payer_id", DataType = SqlDbType.VarChar, Value = machineItems.Federal_Tax_Payer_Id });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "height", DataType = SqlDbType.Decimal, Value = machineItems.Height });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idos", DataType = SqlDbType.BigInt, Value = machineItems.IdOs });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedido", DataType = SqlDbType.BigInt, Value = machineItems.cd_order });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedidoitem", DataType = SqlDbType.BigInt, Value = machineItems.cd_order_cd_order_items });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportador", DataType = SqlDbType.Int, Value = machineItems.IdTransportador });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "imagem", DataType = SqlDbType.VarChar, Value = machineItems.Imagem });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_date", DataType = SqlDbType.DateTime, Value = machineItems.Invoice_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_key", DataType = SqlDbType.VarChar, Value = machineItems.Invoice_Key });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_series", DataType = SqlDbType.VarChar, Value = machineItems.Invoice_Series });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_total_value", DataType = SqlDbType.Decimal, Value = machineItems.Invoice_Total_Value });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_company", DataType = SqlDbType.Bit, Value = machineItems.Is_Company });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_icms_exempt", DataType = SqlDbType.Bit, Value = machineItems.Is_Icms_Exempt });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "length", DataType = SqlDbType.Decimal, Value = machineItems.Length });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "logo", DataType = SqlDbType.VarChar, Value = machineItems.ds_logo });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "mensagem", DataType = SqlDbType.VarChar, Value = machineItems.Mensagem });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomecartao", DataType = SqlDbType.VarChar, Value = machineItems.NomeCartao });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomedestinatario", DataType = SqlDbType.VarChar, Value = machineItems.RecipientName });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomeremetente", DataType = SqlDbType.VarChar, Value = machineItems.NomeRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numerodestinatario", DataType = SqlDbType.VarChar, Value = machineItems.NumeroDestinatario });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numeroremetente", DataType = SqlDbType.VarChar, Value = machineItems.NumeroRemetente });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "origin_warehouse_code", DataType = SqlDbType.VarChar, Value = machineItems.Origin_WareHouse_Code });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "phone", DataType = SqlDbType.VarChar, Value = machineItems.Phone });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "products_quantity", DataType = SqlDbType.Int, Value = machineItems.Products_Quantity });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "sales_channel", DataType = SqlDbType.VarChar, Value = machineItems.Sales_Channel });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "scheduled", DataType = SqlDbType.Bit, Value = machineItems.Scheduled });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_type", DataType = SqlDbType.VarChar, Value = machineItems.Shipment_Order_Type });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_volume_number", DataType = SqlDbType.Int, Value = machineItems.Shipment_Order_Volume_Number });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipped_date", DataType = SqlDbType.DateTime, Value = machineItems.Shipped_Date });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipping_country", DataType = SqlDbType.VarChar, Value = machineItems.Shipping_Country });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "titulo", DataType = SqlDbType.VarChar, Value = machineItems.Titulo });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "trackingcode", DataType = SqlDbType.VarChar, Value = machineItems.cd_order_tracking });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_name", DataType = SqlDbType.VarChar, Value = machineItems.Volume_Name });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_type_code", DataType = SqlDbType.VarChar, Value = machineItems.Volume_Type_Code });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Weight", DataType = SqlDbType.Decimal, Value = machineItems.Weight });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Width", DataType = SqlDbType.Decimal, Value = machineItems.Width });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_biro", DataType = SqlDbType.DateTime, Value = machineItems.Data_Biro });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_pedido", DataType = SqlDbType.DateTime, Value = machineItems.Data_Pedido });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportadormetodo", DataType = SqlDbType.Int, Value = machineItems.IdTransportador });
            items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "plataforma", DataType = SqlDbType.Char, Value = machineItems.Plataforma });


            String query = "";

            if (items.Count > 0)
            {

                foreach (var item in items)
                {
                    if (item.Value != null)
                    {
                        filter.Add(new SqlParameter() { ParameterName = String.Concat("@", item.FieldName), SqlDbType = item.DataType, Value = item.Value != null ? item.Value : DBNull.Value });
                    }
                    
                }

                var fields = items.Where(x => x.Value !=null).ToList().Select(x => new { field = x.FieldName, value = String.Concat("@", x.FieldName) }).ToList();
                // var fields = items.Select(x => new { field = x.FieldName, value = String.Concat("@", x.FieldName) }).ToList();
                var insertString = String.Format("insert biro_new.dbo.items({0}) values ({1})", String.Join(",", fields.Select(x => x.field).ToList()), String.Join(",", fields.Select(x => x.value).ToList()));
                var updateString = WebStore.Queries.UpdateTblCardMachineItemsToCreated(machineItems.cd_cardmachine_items);

                query = String.Concat(insertString, "; ", updateString, ";");

                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroProd"].ConnectionString))
                {
                    conn.Open();

                    SqlTransaction transaction = conn.BeginTransaction();
                    try
                    {
                        using (SqlCommand command = new SqlCommand(query, conn, transaction))
                    {

                            command.Parameters.AddRange(filter.ToArray());
                            command.ExecuteNonQuery();
                            transaction.Commit();

                           
                        }

                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine("Erro ao tentar inserir registro ou update");
                        Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "NovoInsertMachineItemsAndUpdateMachineItemsToCreated", ex.StackTrace.ToString());

                        transaction.Rollback();
                    }

                    conn.Close();
                }
            }

        }

        public List<String> GetItemsByLotOnBiro(Int64 lot)
        {
            List<String> items = new List<String>();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.GetItemsByLot(lot), conn))
                    {
                        comm.CommandTimeout = 30000;
                        var reader = comm.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                items.Add(reader["cd_order_cd_order_items"].ToString());
                            }
                        }
                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Erro ao tentar pegar item já processados");
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "GetItemsByLotOnBiro", "query:"+ SQL.DataQueries.Biro.Queries.GetItemsByLot(lot));
            }

            return items;

        }

        public Models.MetodoTransportador GetTransporte(long cep)
        {
            Models.MetodoTransportador item = new Models.MetodoTransportador();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BiroRead"].ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.GetTransportes(cep), conn))
                    {
                        comm.CommandTimeout = 30000;
                        var reader = comm.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                item.idtransportador = Convert.ToInt32(reader["idtransportador"]);
                                item.idtransportadormetodo = Convert.ToInt32(reader["idtransportadormetodo"]);
                                item.sla = Convert.ToInt32(reader["idtransportadormetodo"]);
                                    
                            }
                        }
                    }

                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao tentar pegar tipo de transportador. Consulte Logs");
                Services.Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "field:" + ex.Message.ToString(), "GetTransporte", "query:" + SQL.DataQueries.Biro.Queries.GetTransportes(cep));

            }

            return item;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BiroAutomaticallyGenerateOS.DataBase.SQL.DataQueries.Biro
{
    class Queries
    {

        public static SqlCommand InsertInTableItemsOnBiro(Models.MachineItems machineItems)
        {
            String query = @"INSERT INTO [dbo].[items]
                            ([idos]
                            ,[idpedido]
                            ,[idpedidoitem]
                            ,[trackingCode]
                            ,[codigocartao]
                            ,[imagem]
                            ,[logo]
                            ,[enderecoremetente]
                            ,[numeroremetente]
                            ,[complementoremetente]
                            ,[bairroremetente]
                            ,[cepremetente]
                            ,[cidaderemetente]
                            ,[estadoremetente]
                            ,[enderecodestinatario]
                            ,[numerodestinatario]
                            ,[complementodestinatario]
                            ,[bairrodestinatario]
                            ,[cepdestinatario]
                            ,[cidadedestinatario]
                            ,[estadodestinatario]
                            ,[mensagem]
                            ,[titulo]
                            ,[assinatura]
                            ,[idtransportador]
                            ,[idtransportadormetodo]
                            ,[nomeremetente]
                            ,[nomedestinatario]
                            ,[nomecartao]
                            ,[data_pedido]
                            ,[data_biro]
                            ,[customer_shipping_costs]
                            ,[sales_channel]
                            ,[scheduled]
                            ,[shipped_date]
                            ,[shipment_order_type]
                            ,[delivery_method_id]
                            ,[estimated_delivery_date]
                            ,[email]
                            ,[phone]
                            ,[cellphone]
                            ,[is_company]
                            ,[federal_tax_payer_id]
                            ,[shipping_country]
                            ,[shipment_order_volume_number]
                            ,[volume_name]
                            ,[weight]
                            ,[volume_type_code]
                            ,[width]
                            ,[height]
                            ,[length]
                            ,[products_quantity]
                            ,[is_icms_exempt]
                            ,[invoice_series]
                            ,[invoice_key]
                            ,[invoice_date]
                            ,[invoice_total_value]
                            ,[cfop]
                            ,[origin_warehouse_code])
                        VALUES
                            (
                            @idos, 
                            @idpedido,
                            @idpedidoitem,
                            @trackingCode,
                            @codigocartao,
                            @imagem,
                            @logo,
                            @enderecoremetente,
                            @numeroremetente,
                            @complementoremetente,
                            @bairroremetente,
                            @cepremetente,
                            @cidaderemetente,
                            @estadoremetente,
                            @enderecodestinatario,
                            @numerodestinatario,
                            @complementodestinatario,
                            @bairrodestinatario,
                            @cepdestinatario,
                            @cidadedestinatario,
                            @estadodestinatario,
                            @mensagem,
                            @titulo,
                            @assinatura,
                            @idtransportador,
                            @idtransportadormetodo,
                            @nomeremetente,
                            @nomedestinatario,
                            @nomecartao,
                            @data_pedido,
                            @data_biro,
                            @customer_shipping_costs,
                            @sales_channel,
                            @scheduled,
                            @shipped_date,
                            @shipment_order_type,
                            @delivery_method_id,
                            @estimated_delivery_date,
                            @email,
                            @phone,
                            @cellphone,
                            @is_company,
                            @federal_tax_payer_id,
                            @shipping_country,
                            @shipment_order_volume_number,
                            @volume_name,
                            @weight,
                            @volume_type_code,
                            @width,
                            @height,
                            @length,
                            @products_quantity,
                            @is_icms_exempt,
                            @invoice_series,
                            @invoice_key,
                            @invoice_date,
                            @invoice_total_value,
                            @cfop,
                            @origin_warehouse_code
                            )";

            SqlCommand comm = new SqlCommand(query);
                comm.Parameters.AddWithValue("@idos",machineItems.IdOs);
                comm.Parameters.AddWithValue("@idpedido",machineItems.cd_order);
                comm.Parameters.AddWithValue("@idpedidoitem",machineItems.cd_order_items);
                comm.Parameters.AddWithValue("@trackingCode", machineItems.cd_order_tracking.ToString());
                comm.Parameters.AddWithValue("@codigocartao",machineItems.cd_card);
                comm.Parameters.AddWithValue("@imagem",machineItems.Imagem);
                comm.Parameters.AddWithValue("@logo", machineItems.ds_logo);
                comm.Parameters.AddWithValue("@enderecoremetente",machineItems.EnderecoRemetente);
                comm.Parameters.AddWithValue("@numeroremetente", machineItems.NumeroRemetente);
                comm.Parameters.AddWithValue("@complementoremetente", machineItems.ComplementoRemetente);
                comm.Parameters.AddWithValue("@bairroremetente", machineItems.BairroRemetente);
                comm.Parameters.AddWithValue("@cepremetente", machineItems.CepRemetente);
                comm.Parameters.AddWithValue("@cidaderemetente", machineItems.CidadeRemetente);
                comm.Parameters.AddWithValue("@estadoremetente", machineItems.EstadoRemetente);
                comm.Parameters.AddWithValue("@enderecodestinatario", machineItems.RecipientAddress);
                comm.Parameters.AddWithValue("@numerodestinatario", machineItems.NumeroDestinatario);
                comm.Parameters.AddWithValue("@complementodestinatario", machineItems.RecipientComplement);
                comm.Parameters.AddWithValue("@bairrodestinatario", machineItems.RecipientDistrict);
                comm.Parameters.AddWithValue("@cepdestinatario", machineItems.RecipientZipCode);
                comm.Parameters.AddWithValue("@cidadedestinatario", machineItems.RecipientCity);
                comm.Parameters.AddWithValue("@estadodestinatario", machineItems.RecipientState);
                comm.Parameters.AddWithValue("@mensagem", machineItems.Mensagem);
                comm.Parameters.AddWithValue("@titulo", machineItems.Titulo);
                comm.Parameters.AddWithValue("@assinatura", machineItems.Assinatura);
                comm.Parameters.AddWithValue("@idtransportador", machineItems.IdTransportador);
                comm.Parameters.AddWithValue("@idtransportadormetodo", machineItems.IdTransportadorMetodo);
                comm.Parameters.AddWithValue("@nomeremetente","nao");
                comm.Parameters.AddWithValue("@nomedestinatario",machineItems.RecipientName);
                comm.Parameters.AddWithValue("@nomecartao", machineItems.Data_Pedido);
                comm.Parameters.AddWithValue("@data_pedido", machineItems.Data_Pedido);
                comm.Parameters.AddWithValue("@data_biro", machineItems.Data_Biro);
                comm.Parameters.AddWithValue("@customer_shipping_costs", machineItems.Customer_Shipping_Costs);
                comm.Parameters.AddWithValue("@sales_channel", machineItems.Sales_Channel);
                comm.Parameters.AddWithValue("@scheduled", machineItems.Scheduled);
                comm.Parameters.AddWithValue("@shipped_date", machineItems.Shipped_Date);
                comm.Parameters.AddWithValue("@shipment_order_type", machineItems.Shipment_Order_Type);
                comm.Parameters.AddWithValue("@delivery_method_id", machineItems.Delivery_Method_Id);
                comm.Parameters.AddWithValue("@estimated_delivery_date", machineItems.Estimated_Delivery_Date);
                comm.Parameters.AddWithValue("@email", machineItems.Email);
                comm.Parameters.AddWithValue("@phone", machineItems.Phone);
                comm.Parameters.AddWithValue("@cellphone", machineItems.CellPhone);
                comm.Parameters.AddWithValue("@is_company", machineItems.Is_Company);
                comm.Parameters.AddWithValue("@federal_tax_payer_id", machineItems.Federal_Tax_Payer_Id);
                comm.Parameters.AddWithValue("@shipping_country", machineItems.Shipping_Country);
                comm.Parameters.AddWithValue("@shipment_order_volume_number", machineItems.Shipment_Order_Volume_Number);
                comm.Parameters.AddWithValue("@volume_name", machineItems.Volume_Name);
                comm.Parameters.AddWithValue("@weight", machineItems.Weight);
                comm.Parameters.AddWithValue("@volume_type_code", machineItems.Volume_Type_Code);
                comm.Parameters.AddWithValue("@width", machineItems.Width);
                comm.Parameters.AddWithValue("@height", machineItems.Height);
                comm.Parameters.AddWithValue("@length", machineItems.Length);
                comm.Parameters.AddWithValue("@products_quantity", machineItems.Products_Quantity);
                comm.Parameters.AddWithValue("@is_icms_exempt", machineItems.Is_Icms_Exempt);
                comm.Parameters.AddWithValue("@invoice_series", machineItems.Invoice_Series);
                comm.Parameters.AddWithValue("@invoice_key", machineItems.Invoice_Key);
                comm.Parameters.AddWithValue("@invoice_date", machineItems.Invoice_Date);
                comm.Parameters.AddWithValue("@invoice_total_value", machineItems.Invoice_Total_Value);
                comm.Parameters.AddWithValue("@cfop", machineItems.CFOP);
                comm.Parameters.AddWithValue("@origin_warehouse_code", machineItems.Origin_WareHouse_Code);




            return comm;
        }

        public static String GetItemsByLot(Int64 lot)
        {
            String Query = @"
                            select
                                concat(i.idpedido,i.idpedidoitem) cd_order_cd_order_items
                            from
                                biro_new.dbo.os o
                                inner join biro_new.dbo.items i on o.idos = i.idos
                            where
                                o.idos = {0}";
            Query = String.Format(Query, lot);

            return Query;
        }

        public static String GetTransportes(long cep)
        {
            String Query = @"
                 select
	                top 1 t3.idtransportador, t3.idtransportadormetodo, t3.sla
                from
	                rangecep t1
	                inner join tiposEntregas t2 on t1.idtipoentrega = t2.idtipoentrega
	                inner join transportadorMetodos t3 on t1.idtransportadormetodo = t3.idtransportadormetodo
	                inner join transportadores t4 on t1.idtransportador = t4.idtransportador

                where
	                '{0}' between cepinicio and cepfim
                order by
	                t2.prioridade asc";
            Query = String.Format(Query, cep);

            return Query;
        }

    }
}

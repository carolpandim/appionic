﻿using System;

namespace BiroAutomaticallyGenerateOS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");
            Console.WriteLine("This is Sparta");
            Console.WriteLine("Remover items duplicado pois a tbl_cardmachine tem orders duplicados. ex: 53960618");
            Console.WriteLine("");

            Presenters.Process.Start();
            //Presenters.ParallelCustom.Start();
            
        }
    }
}

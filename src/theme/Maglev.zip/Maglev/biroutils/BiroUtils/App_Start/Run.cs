﻿using BiroUtils.Models.App_Start;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace BiroUtils.App_Start
{
    class Run
    {
        public static ConfigurationJSON ConfigurationJSON()
        {
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"AppConfig.json");
            string config = File.ReadAllText(path);
            var JsonObject = JsonConvert.DeserializeObject<ConfigurationJSON>(config);
            return JsonObject;
        }
    }
}

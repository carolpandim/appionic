﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models
{
    public class OrderPreProduction
    {
        /// <summary>
        /// Os atributos IsChip,OsType,IdOsType,IdPedidoIdPedidoItem não existe na tabela. Atributos virtuais para manipular os dados
        /// </summary>
        public bool IsChip { get; set; }
        public int OsType { get; set; }
        public int LotId { get; set; }
        public Int32 IdOsType { get; set; }
        public String IdPedidoIdPedidoItem { get; set; }

        public Int64 Id { get; set; }
        public Int64 IdPedido { get; set; }
        public Int64 IdPedidoItem { get; set; }
        public Int64 Codigo { get; set; }
        public String Conteudo { get; set; }
        public DateTime DataPedido { get; set; }
        public DateTime DataImportacao { get; set; }
        public string Plataforma { get; set; }
        public Boolean Processed { get; set; }

        public OrderPreProductionJSON Itemcard{ get; set; }
    }
}

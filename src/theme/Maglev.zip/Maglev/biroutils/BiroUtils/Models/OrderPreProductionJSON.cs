﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models
{
    public class OrderPreProductionJSON
    {
        public String idpedido { get; set; }
        public long? trackingCode { get; set; }
        public Int64? codigocartao { get; set; }
        public String imagem { get; set; }
        public String logo { get; set; }
        public String enderecoremetente { get; set; }
        public String numeroremetente { get; set; }
        public String complementoremetente { get; set; }
        public String bairroremetente { get; set; }
        public String cepremetente { get; set; }
        public String cidaderemetente { get; set; }
        public String estadoremetente { get; set; }
        public String enderecodestinatario { get; set; }
        public String numerodestinatario { get; set; }
        public String complementodestinatario { get; set; }
        public String bairrodestinatario { get; set; }
        public String cepdestinatario { get; set; }
        public String cidadedestinatario { get; set; }
        public String estadodestinatario { get; set; }
        public String mensagem { get; set; }
        public String titulo { get; set; }
        public String assinatura { get; set; }
        public int? idtransportador { get; set; }
        public int? idtransportadormetodo { get; set; }
        public String nomeremetente { get; set; }
        public String nomedestinatario { get; set; }
        public String nomecartao { get; set; }
        public Int32 customer_shipping_costs { get { return 0; } }
        public String sales_channel { get; set; }
        public Boolean? scheduled { get { return false; } }
        public String shipped_date { get; set; }
        public String shipment_order_type { get; set; }
        public Int64 delivery_method_id { get; set; }
        public String estimated_delivery_date { get; set; }
        public String email { get; set; }
        public String phone { get; set; }
        public String cellphone { get; set; }
        public Boolean? is_company { get { return true; } }
        public String federal_tax_payer_id { get; set; }
        public String shipping_country { get { return "Brasil"; } }
        public Int32? shipment_order_volume_number { get { return 1; } }
        public String volume_name { get { return "0"; } }
        public Decimal? weight { get; set; }
        public String volume_type_code { get { return "BOX"; } }
        public Int32 width { get { return 1; } }
        public Int32 height { get { return 1; } }
        public Decimal? length { get { return 1; } }
        public String products_quantity { get; set; }
        public Boolean is_icms_exempt { get { return true; } }
        public String invoice_series { get { return "1"; } }
        public String invoice_key { get { var result = ""; return result.PadLeft(43, '1'); } }
        public String invoice_date { get; set; }
        public Decimal invoice_total_value { get; set; }
        public String cfop { get { return "1"; } }
        public String origin_warehouse_code { get { return "HubCard"; } }
        public Decimal saldo { get; set; }

    }
}

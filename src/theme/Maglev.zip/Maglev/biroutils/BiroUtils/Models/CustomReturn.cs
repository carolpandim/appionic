﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models
{
    public class CustomReturn
    {
        public Boolean Success { get; set; }
        public String Message { get; set; }
        public Object Data { get; set; }
    }
}

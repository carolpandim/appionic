﻿using System;
using System.Collections.Generic;
using System.Text;
using BiroUtils.Models;

namespace BiroUtils.Models
{
    class Lot
    {
        public int OsType { get; set; }
        public int HasChip { get; set; }
        public List<OrderPreProduction> OrderPreProductionItem { get; set; }
    }
}

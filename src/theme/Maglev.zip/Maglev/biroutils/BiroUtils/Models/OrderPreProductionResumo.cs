﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models
{
    class OrderPreProductionResumo
    {
        public Int64 Canal { get; set; }
        public String NomeCanal { get; set; }
        public Int64 Total { get; set; }
    }
}

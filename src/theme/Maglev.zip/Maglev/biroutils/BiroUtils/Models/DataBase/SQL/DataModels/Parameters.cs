﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BiroUtils.Models.DataBase.SQL.DataModels
{
    class Parameters
    {
        public String FieldName { get; set; }
        public SqlDbType DataType { get; set; }
        public Object Value { get; set; }
    }
}

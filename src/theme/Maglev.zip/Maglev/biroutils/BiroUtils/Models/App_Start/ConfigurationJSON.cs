﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models.App_Start
{
    class ConfigurationJSON
    {
        public Configuration configuration { get; set; }

        public class Configuration
        {
            public String PathLog { get; set; }

            public ConnectionStrings connectionStrings { get; set; }

            public class ConnectionStrings
            {
                public String WebStoreRead { get; set; }
                public String WebStoreProd { get; set; }
                public String BiroRead { get; set; }
                public String BiroProd { get; set; }
                public String ProcesadoraRead { get; set; }
            }

        }
    }
}

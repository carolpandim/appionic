﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BiroUtils.Models
{
    class MetodoTransportador
    {
        public int Idtransportador { get; set; }
        public int Idtransportadormetodo { get; set; }
        public int Sla { get; set; }
        public int Codigo { get; set; }
    }
}

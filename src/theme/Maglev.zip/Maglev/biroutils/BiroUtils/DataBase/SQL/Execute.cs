﻿using BiroUtils.Controllers;
using BiroUtils.Models;
using BiroUtils.Models.App_Start;
using BiroUtils.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace BiroUtils.DataBase.SQL
{
    class Execute
    {
        public class Query
        {
            private static Query oQuery;

            public static Query Instance { get { oQuery = oQuery ?? new Query(); return oQuery; } }

            private ConfigurationJSON.Configuration.ConnectionStrings connectionStrings;

            public Query()
            {
                this.connectionStrings = App_Start.Run.ConfigurationJSON().configuration.connectionStrings;
            }

           public List<Models.OrderPreProduction> GetItemsOrderPreProduction(String origin, string ids="", Int32 pageIndex =0, Int32 pageSize=0, Int64 codigoCanal=0)
            {
                List<Models.OrderPreProduction> listOrderPreProduction = new List<Models.OrderPreProduction>();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();                    

                        using (SqlCommand comm = new SqlCommand(DataQueries.Biro.Queries.GetItemsByIDs(origin, ids, pageIndex, pageSize, codigoCanal), conn))
                        {
                            var reader = comm.ExecuteReader();
                            while (reader.Read())
                            {

                                listOrderPreProduction.Add(new Models.OrderPreProduction()
                                {
                                    Id = Convert.ToInt64(reader["id"]),
                                    IdPedido = Convert.ToInt64(reader["idpedido"]),
                                    IdPedidoItem = Convert.ToInt64(reader["idpedidoitem"]),
                                    Codigo = Convert.ToInt64(reader["codigo"]),
                                    Conteudo = reader["conteudo"].ToString(),
                                    DataPedido = Convert.ToDateTime(reader["datapedido"]),
                                    DataImportacao = Convert.ToDateTime(reader["dataimportacao"]),
                                    Plataforma = reader["plataforma"].ToString(),
                                    Processed = Convert.ToBoolean(reader["processed"]),
                                    IdPedidoIdPedidoItem = reader["idpedido"].ToString() + reader["idpedidoitem"].ToString(),
                                    Itemcard = JsonConvert.DeserializeObject<OrderPreProductionJSON>(reader["conteudo"].ToString())
                                });
                            }
                        }
                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu um erro de processar os items");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", ex.Message.ToString(), "GetItemsOrderPreProduction", "query:" + DataQueries.Biro.Queries.GetItemsByIDs(origin, ids, pageIndex, pageSize, codigoCanal));
                }

                return listOrderPreProduction;
            }

            public Models.CustomReturn CardHasChip(Int64 CodigoCartao)
            {
                Models.CustomReturn returnData = new Models.CustomReturn();
                
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.ProcesadoraRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Processadora.Queries.CardHasChip(CodigoCartao), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var result = comm.ExecuteScalar();
                            if (result != null && result != "")
                            {
                                result = Convert.ToBoolean(result);
                                returnData.Success = true;
                                returnData.Data = Convert.ToBoolean(result);
                            }
                            else
                            {
                                Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "warning", String.Format("O cartão informado não foi localizado na processadora:{0}",CodigoCartao), "CardHasChip", "query:" + DataQueries.Processadora.Queries.CardHasChip(CodigoCartao));
                                returnData.Success = false;
                                returnData.Data = null;
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu um erro na hora de validar se o cartão tem chip");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", ex.Message.ToString(), "CardHasChip", "CodigoCartao:" + CodigoCartao);
                }

                return returnData;

            }

            public Int64 GetTotalItemsOrderPreProductionPending(Int64 codigoCanal)
            {
                Int64 result = 0;
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(String.Format("select count(0) Total from OrderPreProduction where processed=0 and codigo={0}",codigoCanal), conn))
                        {
                            comm.CommandTimeout = 300000;
                            result = Convert.ToInt64(comm.ExecuteScalar());

                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro  ao tentar pegar total de items pendentes por canal");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "GetTotalItemsOrderPreProductionPending", "query: select count(0) Total from OrderPreProduction where processed=0");
                }
                return result;

            }

            public List<Models.OrderPreProductionResumo> GetOrderPreProductionGroupByChannel()
            {
                List<Models.OrderPreProductionResumo> items = new List<Models.OrderPreProductionResumo>();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Biro.Queries.GetOrderPreProductionResumo(), conn))
                        {
                            comm.CommandTimeout = 300000;
                            var reader = comm.ExecuteReader();

                            while (reader.Read())
                            {

                                items.Add(new Models.OrderPreProductionResumo()
                                {
                                    Canal = Convert.ToInt64(reader["Canal"]),
                                    Total = Convert.ToInt64(reader["Total"]),
                                    NomeCanal = reader["NomeCanal"].ToString()
                                });

                            }

                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao tentar pegar resumo de pedidos pendentes geração de cartão");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "GetOrderPreProductionGroupByChannel", "query:" + DataQueries.Biro.Queries.GetOrderPreProductionResumo());
                }
                return items;

            }

            public Int32 GetTypeOsByChannel(Int64 CodigoCanal)
            {
                Int32 result = 0;

                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(DataQueries.Biro.Queries.GetTypeOsByChannel(CodigoCanal), conn))
                        {
                            comm.CommandTimeout = 30000;
                            result = Convert.ToInt32(comm.ExecuteScalar());
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ocorreu erro ao tentar pegar tipo de OS por canal:" + CodigoCanal);
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "GetTypeOsByChannel", "query:" + DataQueries.Biro.Queries.GetTypeOsByChannel(CodigoCanal));
                }

                return result;

            }

            public void InsertAndUpdateBiroNew(Models.OrderPreProduction OrderPreProduction)
            {
                List<Models.DataBase.SQL.DataModels.Parameters> items = new List<Models.DataBase.SQL.DataModels.Parameters>();
                List<SqlParameter> filter = new List<SqlParameter>();

                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "assinatura", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.assinatura });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairrodestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.bairrodestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "bairroremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.bairroremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cellphone", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cellphone });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepdestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cepdestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cepremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cepremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cfop", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cfop });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidadedestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cidadedestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "cidaderemetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.cidaderemetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "codigocartao", DataType = SqlDbType.BigInt, Value = OrderPreProduction.Itemcard.codigocartao });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementodestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.complementodestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "complementoremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.complementoremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "customer_shipping_costs", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.customer_shipping_costs });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "delivery_method_id", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.delivery_method_id });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "email", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.email });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecodestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.enderecodestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "enderecoremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.enderecoremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadodestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.estadodestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estadoremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.estadoremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "estimated_delivery_date", DataType = SqlDbType.DateTime, Value = OrderPreProduction.Itemcard.estimated_delivery_date });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "federal_tax_payer_id", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.federal_tax_payer_id });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "height", DataType = SqlDbType.Decimal, Value = OrderPreProduction.Itemcard.height });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idos", DataType = SqlDbType.BigInt, Value = OrderPreProduction.LotId });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedido", DataType = SqlDbType.BigInt, Value = OrderPreProduction.IdPedido });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idpedidoitem", DataType = SqlDbType.BigInt, Value = OrderPreProduction.IdPedidoItem});
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "imagem", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.imagem });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_date", DataType = SqlDbType.DateTime, Value = OrderPreProduction.Itemcard.invoice_date });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_key", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.invoice_key });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_series", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.invoice_series });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "invoice_total_value", DataType = SqlDbType.Decimal, Value = OrderPreProduction.Itemcard.invoice_total_value });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_company", DataType = SqlDbType.Bit, Value = OrderPreProduction.Itemcard.is_company });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "is_icms_exempt", DataType = SqlDbType.Bit, Value = OrderPreProduction.Itemcard.is_icms_exempt });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "length", DataType = SqlDbType.Decimal, Value = OrderPreProduction.Itemcard.length });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "logo", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.logo });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "mensagem", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.mensagem });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomecartao", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.nomecartao });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomedestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.nomedestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "nomeremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.nomeremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numerodestinatario", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.numerodestinatario });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "numeroremetente", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.numeroremetente });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "origin_warehouse_code", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.origin_warehouse_code });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "phone", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.phone });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "products_quantity", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.products_quantity });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "sales_channel", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.sales_channel });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "scheduled", DataType = SqlDbType.Bit, Value = OrderPreProduction.Itemcard.scheduled });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_type", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.shipment_order_type });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipment_order_volume_number", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.shipment_order_volume_number });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipped_date", DataType = SqlDbType.DateTime, Value = OrderPreProduction.Itemcard.shipped_date });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "shipping_country", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.shipping_country });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "titulo", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.titulo });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "trackingcode", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.trackingCode });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_name", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.volume_name });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "volume_type_code", DataType = SqlDbType.VarChar, Value = OrderPreProduction.Itemcard.volume_type_code });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Weight", DataType = SqlDbType.Decimal, Value = OrderPreProduction.Itemcard.weight });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "Width", DataType = SqlDbType.Decimal, Value = OrderPreProduction.Itemcard.width });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_biro", DataType = SqlDbType.DateTime, Value = OrderPreProduction.DataImportacao });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "data_pedido", DataType = SqlDbType.DateTime, Value = OrderPreProduction.DataPedido });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportador", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.idtransportador });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "idtransportadormetodo", DataType = SqlDbType.Int, Value = OrderPreProduction.Itemcard.idtransportadormetodo });
                items.Add(new Models.DataBase.SQL.DataModels.Parameters { FieldName = "plataforma", DataType = SqlDbType.Char, Value = OrderPreProduction.Plataforma });
                String query = "";

                if (items.Count > 0)
                {
                    foreach (var item in items)
                    {
                        if (item.Value != null)
                        {
                            filter.Add(new SqlParameter() { ParameterName = String.Concat("@", item.FieldName), SqlDbType = item.DataType, Value = item.Value != null ? item.Value : DBNull.Value });
                        }

                    }

                    var fields = items.Where(x => x.Value != null).ToList().Select(x => new { field = x.FieldName, value = String.Concat("@", x.FieldName) }).ToList();
                    var insertString = String.Format("insert biro_new.dbo.items({0}) values ({1})", String.Join(",", fields.Select(x => x.field).ToList()), String.Join(",", fields.Select(x => x.value).ToList()));
                    var updateString = String.Format("update OrderPreProduction set processed=1 where id = {0}", OrderPreProduction.Id);

                    query = String.Concat(insertString, "; ", updateString, ";");

                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroProd))
                    {
                        conn.Open();

                        SqlTransaction transaction = conn.BeginTransaction();
                        try
                        {
                            using (SqlCommand command = new SqlCommand(query, conn, transaction))
                            {
                                command.Parameters.AddRange(filter.ToArray());
                                command.ExecuteNonQuery();
                                transaction.Commit();

                            }

                        }
                        catch (Exception ex)
                        {

                            Console.WriteLine("Erro ao tentar inserir registro ou update");
                            Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "InsertAndUpdateBiroNew", ex.StackTrace.ToString());
                            transaction.Rollback();
                        }

                        conn.Close();
                    }
                }

            }

            public List<String> GetItemsByLotOnBiro(Int64 Idlot)
            {
                List<String> items = new List<String>();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.GetItemsByLot(Idlot), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var reader = comm.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    items.Add(reader["idpedidoidpedidoitem"].ToString());
                                }
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao tentar pegar item já processados");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "GetItemsByLotOnBiro", "query:" + SQL.DataQueries.Biro.Queries.GetItemsByLot(Idlot));
                }

                return items;

            }

            public Models.MetodoTransportador SetPropertiesTransportes(long cep)
            {
                Models.MetodoTransportador item = new Models.MetodoTransportador();
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
                    {
                        conn.Open();

                        using (SqlCommand comm = new SqlCommand(SQL.DataQueries.Biro.Queries.SetPropertiesTransportes(cep), conn))
                        {
                            comm.CommandTimeout = 30000;
                            var reader = comm.ExecuteReader();
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    item.Idtransportador = Convert.ToInt32(reader["idtransportador"]);
                                    item.Idtransportadormetodo = Convert.ToInt32(reader["idtransportadormetodo"]);
                                    item.Sla = Convert.ToInt32(reader["idtransportadormetodo"]);
                                    item.Codigo = Convert.ToInt32(reader["codigo"]);

                                }
                            }
                        }

                        conn.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Erro ao tentar pegar tipo de transportador. Consulte Logs");
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "error", "field:" + ex.Message.ToString(), "SetPropertiesTransportes", "query:" + SQL.DataQueries.Biro.Queries.SetPropertiesTransportes(cep));
                }

                return item;

            }

        }
    }
}

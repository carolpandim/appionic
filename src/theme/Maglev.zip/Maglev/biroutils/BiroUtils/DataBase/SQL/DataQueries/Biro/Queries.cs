﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace BiroUtils.DataBase.SQL.DataQueries.Biro
{
    class Queries
    {
        public static string GetItemsByIDs(String origin, string ids="", Int32 pageIndex = 0, Int32 pageSize = 0, Int64 codigoCanal = 0)
        {
            String QueryComplement = "";

            switch (origin)
            {

                case "API":
                    QueryComplement = String.Format("t1.id in({0})",ids);
                    break;
                case "CMD":
                    QueryComplement = String.Format("t1.codigo in({2}) order by t1.id OFFSET (({0} - 1) * {1}) ROWS FETCH NEXT {1} ROWS ONLY",pageIndex,pageSize, codigoCanal);
                    break;
                default:
                    break;
            }

            String Query = @"
                            Select 
	                            t1.*,
	                            t4.idostype 
                            from
	                            OrderPreProduction t1 
	                            inner join ostypeChannels t3 on t1.codigo = t3.codigocanal
	                            inner join osType t4 on t4.idostype = t3.idostype 
                            where 
                                t1.processed = 0
                                and {0}
                            ";
            Query = String.Format(Query, QueryComplement);

            return Query;
        }

        public static String GetItemsByLot(Int64 Idlot)
        {
            String Query = @"
                            select
                                concat(i.idpedido,i.idpedidoitem) idpedidoidpedidoitem
                            from
                                biro_new.dbo.os o
                                inner join biro_new.dbo.items i on o.idos = i.idos
                            where
                                o.idos = {0}";
            Query = String.Format(Query, Idlot);

            return Query;
        }

        public static String SetPropertiesTransportes(long cep)
        {
            String Query = @"
                select
	                top 1 
	                t3.idtransportador, 
	                t3.idtransportadormetodo, 
	                t3.sla,
	                t3.codigo
                from
	                rangecep t1
	                inner join tiposEntregas t2 on t1.idtipoentrega = t2.idtipoentrega
	                inner join transportadorMetodos t3 on t1.idtransportadormetodo = t3.idtransportadormetodo
	                inner join transportadores t4 on t1.idtransportador = t4.idtransportador
                where
	                '{0}' between cepinicio and cepfim
                order by
	                t2.prioridade asc";

            Query = String.Format(Query, cep);

            return Query;
        }

        public static String GetTypeOsByChannel(Int64 codigoCanal)
        {
            String query = @"
                           select
	                            idostype 
                            from 
	                            ostypechannels
                            where 
	                            codigocanal={0}
                            ";
            query = String.Format(query, codigoCanal);
            return query;
        }

        public static String GetOrderPreProductionResumo()
        {
            String query = @"
                            select
	                            op.codigo Canal,
	                            count(0) Total,
	                            otc.nome NomeCanal

                            from 
	                            orderpreproduction op
	                            inner join ostypeChannels otc on otc.codigocanal = op.codigo
                            where 
                                op.processed=0
                            group by codigo,otc.nome
                            ";
            return query;
        }

    }
}

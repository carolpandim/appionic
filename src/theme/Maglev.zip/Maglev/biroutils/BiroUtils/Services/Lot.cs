﻿using BiroUtils.Models.App_Start;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BiroUtils.Services
{
    class Lot
    {
        private static Lot oLot;

        public static Lot Instance { get { oLot = oLot ?? new Lot(); return oLot; } }

        public ConfigurationJSON.Configuration.ConnectionStrings connectionStrings { get; set; }

        public Lot()
        {
            this.connectionStrings = App_Start.Run.ConfigurationJSON().configuration.connectionStrings;
        }

        public Int32 CreateLotOS(Int32 OsType, int HasChip)
        {

            Int32 idLot = 0;

            var query = @"insert into Os(idstatus, data,idostype,possuichip)values(8,GETDATE(),{0},{1}); SELECT SCOPE_IDENTITY()";

            using (SqlConnection conn = new SqlConnection(connectionStrings.BiroProd))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query, OsType, HasChip), conn))
                {
                    comm.CommandTimeout = 300000;
                    var result = comm.ExecuteScalar();

                    idLot = Convert.ToInt32(result);

                }

                conn.Close();
            }

            return idLot;
        }

        public void UpdatePropertiesLot(Int32 idLot)
        {

            var query = "update Os set idstatus=1 where idos={0}";

            using (SqlConnection conn = new SqlConnection(connectionStrings.BiroProd))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query, idLot), conn))
                {
                    comm.CommandTimeout = 300000;
                    var result = comm.ExecuteScalar();

                    idLot = Convert.ToInt32(result);

                }

                conn.Close();
            }

        }

        public Int32 ExistsPendingBatch(Int32 OsType, int HasChip)
        {
            Int32 IdLot;
            //pega o primeiro lot da data atual com status importado
            var query = @"
                        select
	                        top 1
	                        idos
                        from 
	                        Os
                        where 
	                        idostype = {0}
	                        and possuichip = {1}
                            and idstatus =8
                        ";

            using (SqlConnection conn = new SqlConnection(connectionStrings.BiroRead))
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(String.Format(query, OsType, HasChip), conn))
                {
                    comm.CommandTimeout = 300000;
                    IdLot = Convert.ToInt32(comm.ExecuteScalar());
                }

                conn.Close();
            }
            return IdLot;
        }
    }

}

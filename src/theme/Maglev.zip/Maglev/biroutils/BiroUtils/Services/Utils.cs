﻿using BiroUtils.Controllers;
using BiroUtils.DataBase.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiroUtils.Services
{
    class Utils
    {
        private static Utils oUtils;

        public static Utils Instance { get { oUtils = oUtils ?? new Utils(); return oUtils; } }

        public void InsertAndUpdateBiroNew(List<Models.OrderPreProduction> OrderPreProduction)
        {
            foreach (var item in OrderPreProduction)
            {
               Execute.Query.Instance.InsertAndUpdateBiroNew(item);
            }
        }

        public class Parse
        {
            private static Parse oParse;

            public static Parse Instance { get { oParse = oParse ?? new Parse(); return oParse; } }

            private List<Int64> ItemsWithError { get; set; }

            public List<Models.OrderPreProduction> SetCardHasChipAndCardWithoutChip(List<Models.OrderPreProduction> orderPreProductionList)
            {
                //limpa atributo da classe 
                this.ItemsWithError = new List<Int64>();

                Models.CustomReturn result = new Models.CustomReturn();

                Object lockObj = new Object();

                //foreach (var card in orderPreProductionList)
                //{
                //    if (card.Itemcard != null)
                //    {
                //        if (card.Itemcard.codigocartao != null && card.Itemcard.codigocartao != 0)
                //            result = Execute.Query.Instance.CardHasChip(card.Itemcard.codigocartao.Value);
                //        if (result.Success)
                //        {
                //            card.IsChip = Convert.ToBoolean(result.Data);
                //        }
                //        else
                //        {
                //            this.ItemsWithError.Add(card.IdPedido);
                //        }
                //    }
                //    else
                //    {
                //        this.ItemsWithError.Add(card.IdPedido);
                //    }

                //}

                Parallel.ForEach(orderPreProductionList, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, card =>
                {
                    lock (lockObj)
                    {
                        if (card.Itemcard != null)
                        {
                            if (card.Itemcard.codigocartao != null && card.Itemcard.codigocartao != 0)
                                result = Execute.Query.Instance.CardHasChip(card.Itemcard.codigocartao.Value);
                                if (result.Success)
                                {
                                    card.IsChip = Convert.ToBoolean(result.Data);
                                }
                                else
                                {
                                    this.ItemsWithError.Add(card.IdPedido);
                                }
                        }
                        else
                        {
                            this.ItemsWithError.Add(card.IdPedido);
                        }

                    }
                });

                if(ItemsWithError.Count >0)
                    Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "warning", "O campo conteudo está em branco", "SetCardHasChipAndCardWithoutChip", "procurar pelo pedidos: " + String.Join(",", this.ItemsWithError));

                var OrderPreProductionListWithoutError = orderPreProductionList.Where(x => !ItemsWithError.Contains(x.IdPedido)).ToList();
                return OrderPreProductionListWithoutError;

            }

            public List<Models.OrderPreProduction> SetTypeOsByChannel(List<Models.OrderPreProduction> OrderPreProductionList)
            {
                //limpa atributo da classe 
                this.ItemsWithError = new List<Int64>();

                foreach (var item in OrderPreProductionList.GroupBy(x => x.Codigo))
                {
                    Int32 result;
                    var channel = item.Key;
                    result = Execute.Query.Instance.GetTypeOsByChannel(channel);

                    if (result != 0 && result != null)
                    {
                        OrderPreProductionList.ForEach(x =>
                        {
                            x.IdOsType = result;
                            x.Itemcard.delivery_method_id = result;
                        });
                        //OrderPreProductionList = OrderPreProductionList.Select(x => { x.IdOsType = result; return x; }).ToList();
                        //OrderPreProductionList = OrderPreProductionList.Select(x => { x.Itemcard.delivery_method_id = result.ToString(); return x; }).ToList();
                    }
                    else
                    {
                        this.ItemsWithError.AddRange(OrderPreProductionList.Where(x => x.Codigo == channel).ToList().Select(x => x.IdPedido).ToList());
                    }

                }

                Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "warning", "Não foi possível definir o tipo de OS pelo tipo do canal", "SetTypeOsByChannel", "procurar pelo pedidos: " + String.Join(",", this.ItemsWithError));
                var OrderPreProductionListWithoutError = OrderPreProductionList.Where(x => !ItemsWithError.Contains(x.IdPedido)).ToList();
                return OrderPreProductionListWithoutError;
            }

            public List<Models.OrderPreProduction> SetTrackingCode(List<Models.OrderPreProduction> list)
            {
                foreach (var items in list.GroupBy(x => new { x.IdPedido, x.Itemcard.cepdestinatario }))
                {
                    items.Select(x => { x.Itemcard.trackingCode = x.IdPedido; return x; }).ToList();
                }
                return list;
            }

            public List<Models.OrderPreProduction> SetPropertiesTransportes(List<Models.OrderPreProduction> list)
            {
                //limpa atributo da classe 
                this.ItemsWithError = new List<Int64>();
                foreach (var items in list.GroupBy(x => x.Itemcard.cepdestinatario))
                {
                    var result = Execute.Query.Instance.SetPropertiesTransportes(Convert.ToInt64(items.Key.Replace("-","")));

                    if (result.Idtransportador != 0 && result.Idtransportador != null)
                    {

                        items.Select(x =>
                        {
                            x.Itemcard.estimated_delivery_date = Convert.ToDateTime(x.DataImportacao).AddDays(Convert.ToInt32(result.Sla)).ToString();
                            //x.Estimated_Delivery_Date = result.sla;
                            x.Itemcard.idtransportador = result.Idtransportador;
                            x.Itemcard.idtransportadormetodo = result.Idtransportadormetodo;
                            x.Itemcard.delivery_method_id = result.Codigo; return x;
                        }).ToList();
                    }
                    else
                    {
                        this.ItemsWithError.Add(Convert.ToInt64(items.Key.Replace("-", "")));
                    }
                }

                Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "warning", "Não foi possível definir o tipo e metodo de transporte pelo CEP do destinatario", "SetPropertiesTransportes", "procurar pelo CEPs: " + String.Join(",", this.ItemsWithError));
                var OrderPreProductionListWithoutError = list.Where(x => !ItemsWithError.Contains(x.IdPedido)).ToList();
                return OrderPreProductionListWithoutError;
            }
        }
    }
}

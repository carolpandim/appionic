﻿using BiroUtils.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BiroUtils.Services
{
    class Filters
    {
        private static Filters oFilter;

        public static Filters Instance { get { oFilter = oFilter ?? new Filters(); return oFilter; } }

        public List<Models.OrderPreProduction> FilterItems(List<Models.OrderPreProduction> orderPreProductionList)
        {
            var listWithError = orderPreProductionList.Where(x => x.Conteudo == "" || x.Conteudo ==null).Select(x => x.Id).ToList();
            var newList = orderPreProductionList.Where(x => !listWithError.Contains(x.Id)).ToList();

            if (listWithError.Count >0)
                Logs.Instance.RegisterLog(General.GetNameSpaceProject(), "warning", "O conteudo do item não pode ser nulo", "FilterItems", "Procurar pelos ids:"+String.Join(",",listWithError) );

            return newList;

        }

        public List<Models.Lot> SeparateItemsByCharacteristicsToGenerateLotOS(List<Models.OrderPreProduction> list)
        {
            //separa por chip. SIM=1, NAO=0
            var lots = SeparateByChip(list);

            //separar por tipo de OS
            lots = SeparateByTypeOs(lots);

            return lots;
        }

        private List<Models.Lot> SeparateByChip(List<Models.OrderPreProduction> list)
        {
            List<Models.Lot> Lots = new List<Models.Lot>();

            foreach (var items in list.GroupBy(x => x.IsChip))
            {
                Lots.Add(new Models.Lot()
                {
                    HasChip = Convert.ToByte(items.Select(x => x.IsChip).FirstOrDefault()),
                    OrderPreProductionItem = items.ToList()
                });
            }

            return Lots;

        }

        public List<Models.Lot> SeparateByTypeOs(List<Models.Lot> Lots)
        {
            List<Models.Lot> newLots = new List<Models.Lot>();

            foreach (var lot in Lots)
            {
                foreach (var items in lot.OrderPreProductionItem.GroupBy(x => x.IdOsType))
                {
                    newLots.Add(new Models.Lot()
                    {
                        HasChip = Convert.ToByte(items.Select(x => x.IsChip).FirstOrDefault()),
                        OsType = Convert.ToByte(items.Select(x => x.IdOsType).FirstOrDefault()),
                        OrderPreProductionItem = items.ToList()
                    });
                }
            }

            return newLots;
        }
    }
}

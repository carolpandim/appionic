﻿using BiroUtils.DataBase.SQL;
using BiroUtils.Services;
using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiroUtils.Controllers
{
    public class CMD
    {
        public static void Start()
        {

            var orderPreProductionGroupbyChannel = Execute.Query.Instance.GetOrderPreProductionGroupByChannel();

            Console.WriteLine("Resumo Geral da quantidade de cartoes pendentes por Canal");
            ConsoleTable.From<Models.OrderPreProductionResumo>(orderPreProductionGroupbyChannel).Write();

            Int32 pageSize = 100;

            if (orderPreProductionGroupbyChannel.Count > 0)
            {
                foreach (var channel in orderPreProductionGroupbyChannel)
                {

                    Console.WriteLine("Processando cartoes pendente do canal: {0}. Total de cartoes: {1}", channel.Canal, channel.Total);
                    var totalItems = Execute.Query.Instance.GetTotalItemsOrderPreProductionPending(channel.Canal);
                    Int32 totalPages = Convert.ToInt32(Math.Ceiling((double)totalItems / pageSize));

                    List<Int32> PendingLots = new List<Int32>();

                    for (int index = 1; index <= totalPages; index++)
                    {
                        var orderPreProductionList = Execute.Query.Instance.GetItemsOrderPreProduction("CMD", pageIndex: index, pageSize: pageSize, codigoCanal: channel.Canal);

                        orderPreProductionList = Filters.Instance.FilterItems(orderPreProductionList);
                        if (orderPreProductionList.Count == 0)
                            return;

                        Console.WriteLine(" ");
                        Console.WriteLine("Validando se os cartoes tem Chip...");

                        orderPreProductionList = Utils.Parse.Instance.SetCardHasChipAndCardWithoutChip(orderPreProductionList);

                        Console.WriteLine("Fim da validacao");
                        Console.WriteLine(" ");

                        if (orderPreProductionList.Count > 0)
                        {
                            orderPreProductionList = Utils.Parse.Instance.SetTypeOsByChannel(orderPreProductionList);
                            if (orderPreProductionList.Count == 0)
                                return;

                            orderPreProductionList = Utils.Parse.Instance.SetTrackingCode(orderPreProductionList);

                            orderPreProductionList = Utils.Parse.Instance.SetPropertiesTransportes(orderPreProductionList);
                            if (orderPreProductionList.Count == 0)
                                return;

                            var Lots = Filters.Instance.SeparateItemsByCharacteristicsToGenerateLotOS(orderPreProductionList);

                            foreach (var lot in Lots)
                            {
                                var IdLot = Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip) == 0 ? Lot.Instance.CreateLotOS(lot.OsType, lot.HasChip) : Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip);

                                PendingLots.Add(IdLot);

                                var itemsProcessed = Execute.Query.Instance.GetItemsByLotOnBiro(IdLot);
                                Console.WriteLine("Total de Items que ja foram Processados: {0}", itemsProcessed.Count);

                                // seta todos os items para o mesmo lot 
                                lot.OrderPreProductionItem.Select(x => { x.LotId = IdLot; return x; }).ToList();

                                var resultadoFinal = lot.OrderPreProductionItem.Where(x => !itemsProcessed.Contains(x.IdPedidoIdPedidoItem)).ToList();
                                Console.WriteLine("Total de Items Pendentes Processamento: {0}", resultadoFinal.Count);
                                Console.WriteLine(" ");


                                Utils.Instance.InsertAndUpdateBiroNew(resultadoFinal);
                            }

                        }
                        else
                        {
                            Console.WriteLine("Consulte a tabela de logs");
                        }
                    }

                    PendingLots.ForEach(x => Services.Lot.Instance.UpdatePropertiesLot(x));

                }
            }
            else
            {
                Console.WriteLine("Nao ha items pendentes para geracao de OS");
            }

        }

        public static void StartWithParallel()
        {

            var orderPreProductionGroupbyChannel = Execute.Query.Instance.GetOrderPreProductionGroupByChannel();

            Console.WriteLine("Resumo Geral da quantidade de cartoes pendentes por Canal");
            ConsoleTable.From<Models.OrderPreProductionResumo>(orderPreProductionGroupbyChannel).Write();

            Int32 pageSize = 1000;

            if (orderPreProductionGroupbyChannel.Count > 0)
            {
                foreach (var channel in orderPreProductionGroupbyChannel)
                {

                    Console.WriteLine("Processando cartoes pendente do canal: {0}. Total de cartoes: {1}", channel.Canal, channel.Total);

                    Int64 totalItems = Execute.Query.Instance.GetTotalItemsOrderPreProductionPending(channel.Canal);
                    Int32 totalPages = Convert.ToInt32(Math.Ceiling((double)totalItems / pageSize));

                    List<Int32> PendingLots = new List<Int32>();

                    for (int index = 1; index <= totalPages; )
                    {

                        var orderPreProductionList = Execute.Query.Instance.GetItemsOrderPreProduction("CMD", pageIndex: index, pageSize: pageSize, codigoCanal: channel.Canal);

                        orderPreProductionList = Filters.Instance.FilterItems(orderPreProductionList);
                        if (orderPreProductionList.Count != 0)
                        {
                            var totalresultado = orderPreProductionList.Chunks(100);
                            Fillin(PendingLots, index, pageSize, channel.Canal, totalresultado);
                            index = 1;
                            totalPages -= 1;
                        }

                        index++;
                    }

                    PendingLots.GroupBy(x => x).ToList().ForEach(x => Services.Lot.Instance.UpdatePropertiesLot(x.Key));

                }
            }
            else
            {
                Console.WriteLine("Nao ha items pendentes para geracao de OS");
            }

        }

        public static List<Int32> Fillin(List<Int32> PendingLots, Int32 index, Int32 pageSize, Int64 codigoCanal, IEnumerable<IEnumerable<Models.OrderPreProduction>> orderPreProductions)
        {
            var degreeOfParallelism = Environment.ProcessorCount;
            var tasks = new Task[orderPreProductions.Count()];

            int i = 0;

            foreach (var items in orderPreProductions)
            {
                var orderPreProductionList = items.ToList();

                if (orderPreProductionList.Count > 0)
                {
                    tasks[i] = new Task(
                        () =>
                        {
                            Console.WriteLine(" ");
                            Console.WriteLine("Validando se os cartoes tem Chip...");

                            orderPreProductionList = Utils.Parse.Instance.SetCardHasChipAndCardWithoutChip(orderPreProductionList);

                            Console.WriteLine("Fim da validacao");
                            Console.WriteLine(" ");

                            if (orderPreProductionList.Count > 0)
                            {
                                orderPreProductionList = Utils.Parse.Instance.SetTypeOsByChannel(orderPreProductionList);
                                if (orderPreProductionList.Count == 0)
                                    return;

                                orderPreProductionList = Utils.Parse.Instance.SetTrackingCode(orderPreProductionList);

                                orderPreProductionList = Utils.Parse.Instance.SetPropertiesTransportes(orderPreProductionList);
                                if (orderPreProductionList.Count == 0)
                                    return;

                                var Lots = Filters.Instance.SeparateItemsByCharacteristicsToGenerateLotOS(orderPreProductionList);

                                foreach (var lot in Lots)
                                {
                                    var IdLot = Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip) == 0 ? Lot.Instance.CreateLotOS(lot.OsType, lot.HasChip) : Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip);

                                    PendingLots.Add(IdLot);

                                    var itemsProcessed = Execute.Query.Instance.GetItemsByLotOnBiro(IdLot);
                                    Console.WriteLine("Total de Items que ja foram Processados: {0}", itemsProcessed.Count);

                                    // seta todos os items para o mesmo lot 
                                    lot.OrderPreProductionItem.Select(x => { x.LotId = IdLot; return x; }).ToList();

                                    var resultadoFinal = lot.OrderPreProductionItem.Where(x => !itemsProcessed.Contains(x.IdPedidoIdPedidoItem)).ToList();
                                    Console.WriteLine("Total de Items Pendentes Processamento: {0}", resultadoFinal.Count);
                                    Console.WriteLine(" ");


                                    Utils.Instance.InsertAndUpdateBiroNew(resultadoFinal);
                                }

                            }
                            else
                            {
                                Console.WriteLine("Consulte a tabela de logs");
                            }
                        });
                }

                i = i + 1;
            }

            Console.WriteLine("");

            Parallel.ForEach(tasks.ToList(), new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, thread =>
            {
                Object lockObj = new Object();

                lock (lockObj)
                {
                    thread.Start();
                    bool isDone = thread.IsCompleted;
                }

            });

            Console.WriteLine("");

            Task.WaitAll(tasks);

            return PendingLots;

        }

    }
}

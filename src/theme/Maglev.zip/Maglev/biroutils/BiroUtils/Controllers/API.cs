﻿using BiroUtils.DataBase.SQL;
using BiroUtils.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiroUtils.Controllers
{
    public class API
    {
        private static API oAPI;

        public static API Instance { get { oAPI = oAPI ?? new API(); return oAPI; } }

        public Models.CustomReturn Process(String origin, string ids = "", Int32 pageIndex = 0, Int32 pageSize = 0, Int64 codigoCanal = 0)
        {
            Models.CustomReturn returnData = new Models.CustomReturn();

            try
            {
                var orderPreProductionList = Execute.Query.Instance.GetItemsOrderPreProduction("API", ids);

                Object lockObj = new Object();

                Utils.Parse.Instance.SetCardHasChipAndCardWithoutChip(orderPreProductionList);

                orderPreProductionList = Utils.Parse.Instance.SetTypeOsByChannel(orderPreProductionList);

                orderPreProductionList = Utils.Parse.Instance.SetTrackingCode(orderPreProductionList);

                orderPreProductionList = Utils.Parse.Instance.SetPropertiesTransportes(orderPreProductionList);

                var Lots = Filters.Instance.SeparateItemsByCharacteristicsToGenerateLotOS(orderPreProductionList);

                List<Int32> PendingLots = new List<Int32>();

                foreach (var lot in Lots)
                {
                    var IdLot = Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip) == 0 ? Lot.Instance.CreateLotOS(lot.OsType, lot.HasChip) : Lot.Instance.ExistsPendingBatch(lot.OsType, lot.HasChip);

                    PendingLots.Add(IdLot);

                    var itemsProcessed = Execute.Query.Instance.GetItemsByLotOnBiro(IdLot);

                    // seta todos os items para o mesmo lot 
                    lot.OrderPreProductionItem.Select(x => { x.LotId = IdLot; return x; }).ToList();

                    var resultadoFinal = lot.OrderPreProductionItem.Where(x => !itemsProcessed.Contains(x.IdPedidoIdPedidoItem)).ToList();


                    Utils.Instance.InsertAndUpdateBiroNew(resultadoFinal);
                }

                PendingLots.ForEach(x => Lot.Instance.UpdatePropertiesLot(x));

                returnData.Success = true;
                returnData.Message = "Gerada OS com sucesso";
            }
            catch (Exception ex)
            {
                returnData.Success = false;
                returnData.Message = "Ocorreu um erro durante o processamento";
            }

            return returnData;
        }
    }
}

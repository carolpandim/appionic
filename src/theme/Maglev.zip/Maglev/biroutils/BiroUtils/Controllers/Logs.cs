﻿using BiroUtils.App_Start;
using BiroUtils.Models.App_Start;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace BiroUtils.Controllers
{
    public class Logs
    {
        private static Logs oLogs;

        public static Logs Instance { get { oLogs = oLogs ?? new Logs(); return oLogs; } }

        private ConfigurationJSON.Configuration.ConnectionStrings ConnectionStrings { get; set; }

        public Logs()
        {
            this.ConnectionStrings = Run.ConfigurationJSON().configuration.connectionStrings;
        }

        public void RegisterLog(String Origin, String Type, String MessageErro, String Method, String Property)
        {

            String query = @"
                            INSERT INTO dbo.logs
                                       (data,type,origem,mensagem_erro,metodo,propriedades)
                                 VALUES
                                       (@Data,@Type,@Origin,@MessageErro,@Method,@Property)
                        ";

            using (SqlConnection conn = new SqlConnection(ConnectionStrings.BiroProd))
            {
                conn.Open();

                try
                {
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@Data", DateTime.Now);
                        command.Parameters.AddWithValue("@Type", Type);
                        command.Parameters.AddWithValue("@Origin", Origin);
                        command.Parameters.AddWithValue("@MessageErro", MessageErro);
                        command.Parameters.AddWithValue("@Method", Method);
                        command.Parameters.AddWithValue("@Property", Property);

                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                conn.Close();
            }

        }
    }

}

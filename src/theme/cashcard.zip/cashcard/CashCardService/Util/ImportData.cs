﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardService.Util
{
    public class ImportData
    {
    }
}

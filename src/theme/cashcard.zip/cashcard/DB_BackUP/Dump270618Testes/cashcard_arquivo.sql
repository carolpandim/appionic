-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cashcard
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arquivo`
--

DROP TABLE IF EXISTS `arquivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `arquivo` (
  `idarquivo` varchar(50) NOT NULL,
  `nomearquivo` varchar(255) DEFAULT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `dataarquivo` datetime DEFAULT NULL,
  `linhas` int(11) DEFAULT NULL,
  `import` tinyint(4) DEFAULT NULL,
  `dataimport` datetime DEFAULT NULL,
  `recharge` tinyint(4) DEFAULT NULL,
  `datarecharge` datetime DEFAULT NULL,
  `export` tinyint(4) DEFAULT NULL,
  `dataexport` datetime DEFAULT NULL,
  `email` tinyint(4) DEFAULT NULL,
  `dataemail` datetime DEFAULT NULL,
  PRIMARY KEY (`idarquivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arquivo`
--

LOCK TABLES `arquivo` WRITE;
/*!40000 ALTER TABLE `arquivo` DISABLE KEYS */;
INSERT INTO `arquivo` VALUES ('00dfc8f5-6489-49c5-86fd-045e48c81dc0','itau_teste_270618_input.csv',2,'2018-06-27 08:45:52',1000,1,'2018-06-27 08:45:52',1,'2018-06-27 09:20:35',1,'2018-06-27 09:20:36',1,'2018-06-27 09:20:37'),('132e6dfb-222a-4cb0-90a3-70bda43ad36a','itau_Recarga_planilha_01062018_OFICIAL_input.csv',2,'2018-06-01 09:45:34',1,1,'2018-06-01 09:45:34',1,'2018-06-01 09:45:56',1,'2018-06-01 09:45:57',0,NULL),('270248f6-6f18-4f1e-88ec-a4301d0e96c7','itau_Recarga_planilha_01062018_OFICIAL2_input.csv',2,'2018-06-01 10:26:41',913,1,'2018-06-01 10:26:41',1,'2018-06-04 18:11:02',1,'2018-06-01 13:11:25',0,NULL),('33ae38cd-6529-4006-b591-f368ece34a61','cabify_recarga_normal_2018-06-25_input.csv',1,'2018-06-26 13:27:47',114,1,'2018-06-26 13:27:47',1,'2018-06-26 13:31:28',1,'2018-06-26 13:31:37',1,'2018-06-26 13:31:38'),('67ef8832-e2ed-481d-864f-110b6636608a','itau_teste_260618_input.csv',2,'2018-06-26 17:27:14',1000,1,'2018-06-26 17:27:14',1,'2018-06-26 17:32:45',1,'2018-06-26 17:32:48',1,'2018-06-26 17:32:49'),('6be1ed5c-518f-42ac-8db6-f69233b75eb0','cabify_recarga_normal_2018-06-22_input.csv',1,'2018-06-25 08:55:07',103,1,'2018-06-25 08:55:07',1,'2018-06-25 08:58:08',1,'2018-06-25 08:58:09',1,'2018-06-25 08:58:09'),('7e96869f-b3c4-478e-ad9a-1296a787204d','cabify_recarga_normal_2018-06-20_input.csv',1,'2018-06-21 07:50:37',69,1,'2018-06-21 07:50:37',1,'2018-06-21 07:52:48',1,'2018-06-25 08:37:49',1,'2018-06-25 08:37:49'),('8be7523d-4d23-4fc6-9349-19ae9d3458b6','cabify_recarga_normal_2018-06-15_input.csv',1,'2018-06-15 18:45:20',110,1,'2018-06-15 18:45:20',1,'2018-06-15 18:50:09',1,'2018-06-15 18:50:10',1,'2018-06-15 18:50:10'),('94b28cf6-e096-4d68-ac0a-5ca7f1682af4','cabify_recarga_normal_2018-06-18_input.csv',1,'2018-06-18 17:46:20',81,1,'2018-06-18 17:46:20',1,'2018-06-18 17:48:49',1,'2018-06-18 17:48:50',1,'2018-06-18 17:48:50'),('9ad27ba8-947a-4bcf-b200-a2a43300524a','cabify_recarga_normal_2018-05-25_input.csv',1,'2018-05-25 16:25:19',2,1,'2018-05-25 04:25:19',0,'2018-05-25 04:25:19',1,'2018-06-14 09:02:02',0,NULL),('9b6de34f-7e77-48a2-944d-e703f0c845bc','cabify_recarga_pendencias_2018-06-14_input.csv',1,'2018-06-15 17:44:56',13,1,'2018-06-15 17:44:56',1,'2018-06-15 17:45:18',1,'2018-06-15 17:45:18',1,'2018-06-15 17:45:19'),('9d73871c-8682-4455-bb06-572a5e370f8d','cabify_recarga_normal_2018-06-05_input.csv',1,'2018-06-06 10:15:46',7,1,'2018-06-06 10:15:46',1,'2018-06-06 10:48:27',1,'2018-06-06 10:51:02',0,NULL),('a1f4bde9-9fbb-4bff-b92f-22c5db75e8ea','cabify_recarga_normal_2018-06-04_input.csv',1,'2018-06-04 18:09:57',58,1,'2018-06-04 06:09:57',1,'2018-06-04 18:12:13',1,'2018-06-04 18:12:14',0,NULL),('a2e7a36c-3555-49aa-8bdd-19c72fe764e5','cabify_recarga_normal_2018-05-28_input.csv',1,'2018-05-28 18:14:50',44,1,'2018-05-28 06:14:50',1,'2018-05-28 18:16:04',1,'2018-05-28 18:16:05',0,NULL),('aa81143f-cff1-4cd6-bc09-950b6911431a','itau_planilha_01062018_OFICIAL_Teste_input.csv',2,'2018-06-01 09:25:05',1,1,'2018-06-01 09:25:05',1,'2018-06-01 09:29:10',1,'2018-06-01 09:29:15',0,NULL),('bb5d3399-d692-47ca-94b7-f13d44a7179f','cabify_recarga_normal_2018-06-11_input.csv',1,'2018-06-11 17:36:04',122,1,'2018-06-11 17:36:04',1,'2018-06-11 17:42:51',1,'2018-06-11 17:42:52',0,NULL),('ce6b3e7e-b704-44f6-9f06-7abbb64bf340','cabify_recarga_correcao_2018-06-19_input.csv',1,'2018-06-19 16:41:29',22,1,'2018-06-19 16:41:29',1,'2018-06-19 16:42:23',1,'2018-06-19 16:42:24',1,'2018-06-19 16:42:24'),('d485fd89-b9e4-499b-bca5-baed12e154ce','cabify_recarga_normal_2018-06-13_input.csv',1,'2018-06-14 11:35:12',80,1,'2018-06-14 11:35:12',1,'2018-06-14 11:37:56',1,'2018-06-14 11:37:57',0,NULL),('e8d13ba0-7bd7-42c0-ba0f-247a909fa42d','cabify_recarga_correcao_2018-06-25_input.csv',1,'2018-06-26 13:27:46',11,1,'2018-06-26 13:27:46',1,'2018-06-26 13:31:36',1,'2018-06-26 13:31:37',1,'2018-06-26 13:31:38');
/*!40000 ALTER TABLE `arquivo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27 10:37:25

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Request
{
    public class Boleto
    {
        public Content content { get; set; }

    }
}

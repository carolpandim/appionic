﻿using System;
using System.Collections.Generic;

namespace CashCardDB.DataBase.Model.Request
{
    public class OrderRequest
    {
        public Int32 id { get; set; }
        public String idempotencyKey { get; set; }
        public Int64 accountId { get; set; }
        public String routingKey { get; set; }
        public String invoiceMessage { get; set; }

        public List<Account> accounts { get; set; }
        public Payments payments { get; set; }
    }
}

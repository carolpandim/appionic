﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Request
{
    public class Account
    {
        public Int64 accountId { get; set; }
        public Credit credit { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Request
{
    public class Credit
    {
        public Decimal amount { get; set; }
        public String summary { get; set; }
        public String externalId { get; set; }
    }
}

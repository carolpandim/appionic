﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Request
{
    public class Content
    {
        public Int64 accountId { get; set; }
        public Decimal amount { get; set; }
        public String Summary { get; set; }
        public InfoBoleto infoBoleto { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Request
{
    public class InfoBoleto
    {
        public Decimal fineValue { get; set; }
        public Decimal discount { get; set; }
        public String dueDate { get; set; }

    }
}

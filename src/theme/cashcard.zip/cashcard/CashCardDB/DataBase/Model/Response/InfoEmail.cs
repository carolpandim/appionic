﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Response
{
    public class InfoEmail
    {
        public String IdArquivo { get; set; }
        public String NomeArquivo { get; set; }
        public DateTime? DtInicio { get; set; }
        public DateTime? DtFinal { get; set; }
        public Int32 Linhas { get; set; }
        public Boolean? Recharge { get; set; }
        public Int32 NotRecharge { get; set; }
        public Int32 IsRecharge { get; set; }
        public Int32 SituacaoNaoAut { get; set; }
        public Int32 NaoEncontrado { get; set; }
        public Int32 Superior { get; set; }
        public Int32 Outros { get; set; }

    }
}

﻿using System;

namespace CashCardDB.DataBase.Model.Response
{
	public class ArquivoResponse
    {
        public int IdCliente { get; set; }
		public string IdArquivo { get; set; }
		public string IdArquivoItem { get; set; }
		public string CardId { get; set; }
		public string Cpf { get; set; }
		public decimal? VlRecarga { get; set; }
		public Int64 IdAccount { get; set; }
        public Int64 IdAccountParent { get; set; }
        public int? CodSituacao { get; set; }

		public string Identificador { get; set; }
		public decimal? Limite { get; set; }
		public decimal? Saldo { get; set; }

	}
}

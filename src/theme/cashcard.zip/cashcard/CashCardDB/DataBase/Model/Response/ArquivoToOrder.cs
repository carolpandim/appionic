﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Response
{
    public class ArquivoToOrder
    {
        public String IdArquivo { get; set; }
        public Int64 IdAccountParent { get; set; }
        public Decimal Total { get; set; }

    }
}

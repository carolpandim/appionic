﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Response
{
    public class OrderResponse
    {
        public String IdArquivo { get; set; }
        public String OrderId { get; set; }
        public String TotalOrder { get; set; }
        public String DataOrder { get; set; }
        public String DataBoleto { get; set; }
        public String Success { get; set; }
        public String Result { get; set; }
    }
}

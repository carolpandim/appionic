﻿using System;

namespace CashCardDB.DataBase.Model.Response
{
	public class RangeDates
    {
		public DateTime Date { get; set; }
	}
}

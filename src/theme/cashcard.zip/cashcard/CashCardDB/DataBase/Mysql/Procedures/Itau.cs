﻿using CashCardDB.DataBase.Model.Response;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CashCardDB.DataBase.Mysql.Procedures
{
    public class Itau
    {
        private static Itau oItau;

        public static Itau Instance { get { oItau = oItau ?? new Itau(); return oItau; } }

        /// <summary>
        /// Atualiza valor de recarga e saldo do pedido do arquivo.
        /// </summary>
        /// <param name="arquivoResponse">Lista de pedidos do arquivo que serão processados na recarga</param>
        public void UpdateRecargaItens(ArquivoResponse arquivoResponse)
        {
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;
                conn.Open();
                transaction = conn.BeginTransaction();
                try
                {
                    var query = "update arquivoitem set vlrecarga = {0} where idarquivoitem = '{1}';";

                    string cmdText = String.Format(query, arquivoResponse.VlRecarga.ToString().Replace(",", "."), arquivoResponse.IdArquivoItem);

                    MySqlCommand comm = new MySqlCommand(cmdText, conn, transaction);

                    comm.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao realizar atualização na CashCard. ERRO: {0}", ex.Message);

                    CashCard.Instance.SaveLog("Itau.UpdateRecargaItens", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

        /// <summary>
        /// Recupera código do cartão e cpf na Self, pelo código identifier, e os preenche na lista de pedidos.
        /// </summary>
        /// <param name="listArquivoItem">Lista de pedidos</param>
        /// <returns>Lista de pedidos atualizada com os dados do cartão e cpf.</returns>
        public List<ArquivoItem> GetCardId(List<ArquivoItem> listArquivoItem, int companyId, int productId)
        {
            List<ResultSelfie> listResultSelfie = new List<ResultSelfie>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Self"].ConnectionString))
            {
                conn.Open();

                try
                {
                    String filter = String.Format("a.company_id = {0} and a.product_id = {1} and c.card_id is not null and c.deleted_at is null and c.identifier in ({2})", companyId, productId, String.Join(",", listArquivoItem.Select(x => String.Concat("'", x.Identificador, "'")).ToList()));

                    var query = @"
                                    select c.card_id, cc.cpf, c.identifier, c.hubcard_account_id
                                    from cards c
	                                    inner join accounts a on a.id = c.account_id
	                                    inner join cardholders cc on cc.id = c.cardholder_id
                                    where {0}
                                    order by c.card_id desc;
								";

                    string cmdText = String.Format(query, filter);

                    MySqlCommand comm = new MySqlCommand(cmdText, conn);

                    using (MySqlDataReader reader = comm.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ResultSelfie res = new ResultSelfie();

                            res.Identificador = reader["identifier"].ToString();
                            res.CardId = reader["card_id"].ToString();
                            res.Cpf = reader["cpf"].ToString();

                            listResultSelfie.Add(res);
                        }
                    }

                    conn.Close();

                    string strIdentificador = string.Format("{0}", String.Join(",", listResultSelfie.Select(x => String.Concat("'", x.Identificador, "'")).ToList()));

                    foreach (var item in listArquivoItem)
                    {
                        if (strIdentificador.Contains(item.Identificador))
                        {
                            var res = listResultSelfie.Where(x => x.Identificador == item.Identificador).FirstOrDefault();

                            item.Cpf = res.Cpf;
                            item.CardId = res.CardId;
                        }
                    }
                }
                catch (Exception ex)
                {
                    string msg = String.Format("Erro ao realizar consulta na Self. ERRO: {0}", ex.Message);

                    CashCard.Instance.SaveLog("Itau.GetCardId", DateTime.Now, msg, true);
                }

            }

            return listArquivoItem;

        }
    }
}

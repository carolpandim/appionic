﻿using CashCardDB.DataBase.Model.Response;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashCardDB.DataBase.Mysql.Procedures
{
    public class CashCard
    {
        private static CashCard oCashCard;

        public static CashCard Instance { get { oCashCard = oCashCard ?? new CashCard(); return oCashCard; } }

        /// <summary>
        /// Consulto se o arquivo já foi importado anteriormente
        /// </summary>
        /// <param name="idCliente">Id do cliente</param>
        /// <param name="nomeArquivo">Nome do arquivo</param>
        /// <returns>Se já foi importado ou não</returns>
        public bool CheckIfWasImported(Int32 idCliente, string nomeArquivo)
        {
            Boolean status = false;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = String.Format("select idarquivo from arquivo where idcliente = '{0}' and nomearquivo = '{1}'", idCliente, nomeArquivo);

                    using (MySqlCommand comm = new MySqlCommand(query, conn))
                    {

                        var result = comm.ExecuteScalar();

                        if (result != null)
                        {
                            status = true;
                        }
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {

                string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                CashCard.Instance.SaveLog("CashCard.CheckIfWasImported", DateTime.Now, msg, true);
            }

            return status;
        }

        public List<string> GetArquivosByCompany(Int32 idCliente)
        {
            List<string> listArquivos = new List<string>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = String.Format("select idarquivo from arquivo where idcliente = {0} and recharge = 0 and dataarquivo >= now() - interval 6 hour", idCliente);

                    using (MySqlCommand comm = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = comm.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                listArquivos.Add(reader["idarquivo"].ToString());
                            }
                        }
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {

                string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                CashCard.Instance.SaveLog("CashCard.GetArquivosByCompany", DateTime.Now, msg, true);
            }

            return listArquivos;
        }

        /// <summary>
        /// Recupera a situação do cartão, de cada pedido, na Processadora. 
        /// Salvando esse e os outros dados extraídos do arquivo, em suas respectivas tabelas. 
        /// </summary>
        /// <param name="arquivo">Informações do arquivo do cliente</param>
        /// <param name="arquivoItens">Lista de pedidos do arquivo</param>
        public void SalvarArquivo(Arquivo arquivo, List<ArquivoItem> arquivoItens, int accountIdMatriz)
        {
            arquivoItens = GetSituacao(arquivoItens, accountIdMatriz, arquivo.IdCliente);

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                conn.Open();

                MySqlTransaction transaction = null;

                try
                {
                    transaction = conn.BeginTransaction();

                    var query = String.Format(@"insert into arquivo 
                                                (idarquivo,
                                                nomearquivo,
                                                idcliente,
                                                dataarquivo,
                                                linhas,
                                                import,
                                                dataimport) 
                                                values ('{0}','{1}',{2},'{3}',{4},{5},'{6}')  ",
                                                arquivo.IdArquivo,
                                                arquivo.NomeArquivo,
                                                arquivo.IdCliente,
                                                arquivo.DataArquivo.ToString("yyyy-MM-dd HH:mm:ss"),
                                                arquivo.Linhas,
                                                arquivo.Import,
                                                (arquivo.DataImport.HasValue ? arquivo.DataImport.Value.ToString("yyyy-MM-dd HH:mm:ss") : string.Empty));

                    using (MySqlCommand comm = new MySqlCommand(query, conn, transaction))
                    {
                        //Salva os dados do Arquivo
                        comm.ExecuteScalar();
                    }

                    //Nova lista
                    List<ArquivoItem> itensToProcess = new List<ArquivoItem>();

                    //Variável que irá controlar a quantidade total de pedidos a serem processados de uma só vez
                    //Inicializo ela com 1, garantindo que, arquivos com apenas um pedido, seja processado na lógica abaixo
                    Int32 totalArquivosItensLoaded = 1;

                    foreach (var item in arquivoItens)
                    {
                        //Se a quantidade total de pedidos a serem processados de uma só vez for igual a quantidade total de pedidos recuperados
                        if (totalArquivosItensLoaded == arquivoItens.Count())
                        {
                            //Adiciono esse pedido à nova lista
                            itensToProcess.Add(item);
                        }

                        //Se essa nova lista tiver alcançado os 1000 registros ou a condição acima se repetir, eu monto minha query de inserção com todos os pedidos
                        if (itensToProcess.Count() == 1000 || totalArquivosItensLoaded == arquivoItens.Count())
                        {
                            //Lista de query's
                            List<String> query2Process = new List<string>();

                            foreach (var item2Process in itensToProcess)
                            {
                                String queryItem = "";

                                //Se o pedido tiver as informações do cartão, necessárias para a recarga, se monta a query e a adiciona à lista de query's
                                if (!String.IsNullOrEmpty(item2Process.CardId) && !string.IsNullOrEmpty(item2Process.CodSituacao) && !string.IsNullOrEmpty(item2Process.IdAccount))
                                {
                                    queryItem = @"insert into arquivoitem (
														idarquivoitem, 
														idarquivo,
														cardid,
														cpf,	
														vlrecarga, 
														idaccount,
														codsituacao,
														identificador,
														limite,
                                                        idaccountparent,
                                                        saldo,
                                                        companyid,
                                                        regionid
														) 
													values ('{0}','{1}','{2}','{3}',{4},{5},{6},'{7}',{8},{9},{10},'{11}','{12}')";

                                    query2Process.Add(String.Format(queryItem,
                                                item2Process.IdArquivoItem,
                                                item2Process.IdArquivo,
                                                item2Process.CardId,
                                                item2Process.Cpf,
                                                !string.IsNullOrEmpty(item2Process.VlRecarga) ? item2Process.VlRecarga : "null",
                                                !string.IsNullOrEmpty(item2Process.IdAccount) ? item2Process.IdAccount : "null",
                                                !string.IsNullOrEmpty(item2Process.CodSituacao) ? item2Process.CodSituacao : "null",
                                                item2Process.Identificador,
                                                !string.IsNullOrEmpty(item2Process.Limite) ? item2Process.Limite : "null",
                                                accountIdMatriz,
                                                !string.IsNullOrEmpty(item2Process.Saldo) ? item2Process.Saldo : "null",
                                                item2Process.CompanyId,
                                                item2Process.RegionId));
                                }
                                //Senão, se monta a query de inserção, sem o valor de recarga e informações do cartão, e a adiciono à mesma lista de query's
                                else
                                {
                                    string msg = "Cartao nao encontrado";


                                    queryItem = @"insert into arquivoitem (
														idarquivoitem, 
														idarquivo,
														cpf,	
														vlrecarga,
														identificador,
														descricaoprocessamento,
                                                        companyid,
                                                        regionid,
                                                        recharge,
                                                        limite
														) 
													values ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}',{8},{9})";

                                    query2Process.Add(String.Format(queryItem,
                                                item2Process.IdArquivoItem,
                                                item2Process.IdArquivo,
                                                item2Process.Cpf,
                                                !string.IsNullOrEmpty(item2Process.VlRecarga) ? item2Process.VlRecarga : "null",
                                                item2Process.Identificador,
                                                msg,
                                                item2Process.CompanyId,
                                                item2Process.RegionId,
                                                "false",
                                                !string.IsNullOrEmpty(item2Process.Limite) ? item2Process.Limite : "null"));
                                }
                            }

                            //Salva os dados dos pedidos do arquivo de uma só vez 
                            using (MySqlCommand comm = new MySqlCommand(String.Join(";", query2Process), conn, transaction))
                            {
                                comm.ExecuteScalar();
                            }

                            //Limpo os itens da nova lista, para poder adicionar os próximos 1000 itens
                            itensToProcess.Clear();
                        }
                        else
                        {
                            //Senão, vou incrementando o total de arquivos a serem processados de uma só vez
                            totalArquivosItensLoaded++;

                            //Adiciono o arquivo a nova lista
                            itensToProcess.Add(item);
                        }
                    }

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao salvar dados na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.SalvarArquivo", DateTime.Now, msg, true);
                }

                conn.Close();
            }
        }

        public ArquivoToOrder GetArquivoToOrder(string idArquivo)
        {
            ArquivoToOrder arquivoToOrder = new ArquivoToOrder();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {

                    conn.Open();

                    MySqlCommand command = conn.CreateCommand();
                    command.Connection = conn;

                    var query = @"
                                    select 
                                        a.idarquivo,
                                        ai.idaccountparent,
                                        sum(ai.vlrecarga) as total
                                    from arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
                                    where a.idarquivo = '{0}' 
                                        and ai.recharge is true                               
                                    ";

                    command.CommandText = String.Format(query, idArquivo);

                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        arquivoToOrder.IdArquivo = reader["idarquivo"].ToString();

                        if (!string.IsNullOrEmpty(reader["total"].ToString()))
                        {
                            arquivoToOrder.Total = Convert.ToDecimal(reader["total"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["idaccountparent"].ToString()))
                        {
                            arquivoToOrder.IdAccountParent = Convert.ToInt64(reader["idaccountparent"].ToString());
                        }
                    }

                    conn.Close();

                }
            }
            catch (Exception ex)
            {

                string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                Instance.SaveLog("Cabify.GetArquivoToOrder", DateTime.Now, msg, true);
            }

            return arquivoToOrder;
        }

        /// <summary>
        /// Recupera dados do cartão na Processadora pelo cpf, tais como código do cartão, código da situação e id da account.
        /// </summary>
        /// <param name="arquivoItens">Lista de pedidos</param>
        /// <returns>Lista de pedidos atualizada com os dados do cartão</returns>
        public List<ArquivoItem> GetSituacao(List<ArquivoItem> arquivoItens, int accountIdMatriz, int idCliente)
        {
            List<ResultProcessadora> listResProc = new List<ResultProcessadora>();

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Processadora"].ConnectionString))
            {
                try
                {
                    conn.Open();

                    String filter = "";
                    String query = "";

                    //Cabify
                    if (idCliente == 1)
                    {
                        filter = string.Format("doc.document in({0}) and acc.account_parent_id = {1}", String.Join(",", arquivoItens.Select(x => String.Concat("'", x.Cpf, "'")).ToList()), accountIdMatriz);

                        query = @"
                                    select 
										c.CodigoCartao,
	                                    c.CodigoSituacao,
	                                    acc.id as account,
                                        doc.document,
                                        ledger.get_account_balance_fn (acc.id ) as saldo
									from
	                                    cartoes c
	                                    inner join ContasSaldos saldos  (nolock) on c.CodigoContaTitular = saldos.CodigoContaTitular
	                                    inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
	                                    inner join accounts.Person per  (nolock) on acc.person_id = per.id
	                                    inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id										
									where
										c.CodigoCartao in(
											select 
												Max(c.CodigoCartao)
											from 
												cartoes c
												inner join ContasSaldos saldos  (nolock) on c.CodigoContaTitular = saldos.CodigoContaTitular
												inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
												inner join accounts.Person per  (nolock) on acc.person_id = per.id
												inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
											where 
                                                {0}
											group by
												doc.document
										)
                                ";
                    }
                    //Itaú
                    else if (idCliente == 2)
                    {
                        filter = string.Format("c.CodigoCartao in ({0})", String.Join(",", arquivoItens.Select(x => String.Concat("'", x.CardId, "'")).ToList()));

                        query = @"
                                select 
	                                c.CodigoCartao,
                                    c.CodigoSituacao,
                                    acc.id as account,
                                    doc.document,
                                    ledger.get_account_balance_fn (acc.id ) as saldo
                                from
                                    cartoes c
                                    inner join ContasSaldos saldos  (nolock) on c.CodigoContaTitular = saldos.CodigoContaTitular
                                    inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
                                    inner join accounts.Person per  (nolock) on acc.person_id = per.id
                                    inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id										
                                where {0}
                                ";
                    }


                    SqlCommand command = conn.CreateCommand();
                    command.Connection = conn;

                    command.CommandText = String.Format(query, filter);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ResultProcessadora res = new ResultProcessadora();

                            res.Cpf = reader["document"].ToString();
                            res.CardId = reader["CodigoCartao"].ToString();
                            res.CodSituacao = reader["codigosituacao"].ToString();
                            res.IdAccount = reader["account"].ToString();
                            res.Saldo = reader["saldo"].ToString().ToString().Replace(",", ".");
                            res.IdAccountParent = accountIdMatriz.ToString();


                            listResProc.Add(res);
                        }
                    }

                    conn.Close();

                    if (idCliente == 1)
                    {
                        arquivoItens = (from arquivo in arquivoItens
                                        join resProc in listResProc on arquivo.Cpf equals resProc.Cpf into j1
                                        from j2 in j1.DefaultIfEmpty()
                                        select new ArquivoItem
                                        {
                                            CompanyId = arquivo.CompanyId,
                                            DescricaoProcessamento = arquivo.DescricaoProcessamento,
                                            IdArquivo = arquivo.IdArquivo,
                                            IdArquivoItem = arquivo.IdArquivoItem,
                                            Identificador = arquivo.Identificador,
                                            Limite = arquivo.Limite,
                                            Recharge = arquivo.Recharge,
                                            RegionId = arquivo.RegionId,
                                            VlRecarga = arquivo.VlRecarga,
                                            CardId = j2 != null ? j2.CardId : "",
                                            CodSituacao = j2 != null ? j2.CodSituacao : "",
                                            IdAccount = j2 != null ? j2.IdAccount : "",
                                            Cpf = j2 != null ? j2.Cpf : arquivo.Cpf,
                                            IdAccountParent = j2 != null ? j2.IdAccountParent : "",
                                            Saldo = j2 != null ? j2.Saldo : ""
                                        }).ToList();
                    }
                    else if (idCliente == 2)
                    {
                        arquivoItens = (from arquivo in arquivoItens
                                        join resProc in listResProc on arquivo.CardId equals resProc.CardId into j1
                                        from j2 in j1.DefaultIfEmpty()
                                        select new ArquivoItem
                                        {
                                            CompanyId = arquivo.CompanyId,
                                            DescricaoProcessamento = arquivo.DescricaoProcessamento,
                                            IdArquivo = arquivo.IdArquivo,
                                            IdArquivoItem = arquivo.IdArquivoItem,
                                            Identificador = arquivo.Identificador,
                                            Limite = arquivo.Limite,
                                            Recharge = arquivo.Recharge,
                                            RegionId = arquivo.RegionId,
                                            VlRecarga = arquivo.VlRecarga,
                                            CardId = j2 != null ? j2.CardId : "",
                                            CodSituacao = j2 != null ? j2.CodSituacao : "",
                                            IdAccount = j2 != null ? j2.IdAccount : "",
                                            Cpf = j2 != null ? j2.Cpf : arquivo.Cpf,
                                            IdAccountParent = j2 != null ? j2.IdAccountParent : "",
                                            Saldo = j2 != null ? j2.Saldo : ""
                                        }).ToList();
                    }
                }
                catch (Exception ex)
                {

                    string msg = String.Format("Erro ao realizar consulta na Processadora. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.GetSituacao", DateTime.Now, msg, true);
                }
            }

            return arquivoItens;
        }

        public void UpdateStatusItem(string idArquivo, CashCardOrderResponse item)
        {

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;

                conn.Open();

                transaction = conn.BeginTransaction();

                try
                {
                    var query = "update arquivoitem set recharge = {0} , descricaoprocessamento = '{1}' where idarquivoitem = '{2}';";

                    string cmdText = String.Format(query, item.Success, item.Result, item.idArquivoItem);

                    MySqlCommand comm = new MySqlCommand(cmdText, conn, transaction);

                    //Atualiza informações de recarga dos pedido do arquivo
                    comm.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao atualizar dados do arquivoitem na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.UpdateStatusItem", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

        /// <summary>
        /// Atualiza informações do pedido da Orders no arquivo.
        /// </summary>
        /// <param name="idArquivo">Id do Arquivo</param>
        /// <param name="item">OrderResponse</param>
        public void UpdateStatusArquivo(string idArquivo, OrderResponse item)
        {

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;

                conn.Open();

                transaction = conn.BeginTransaction();

                try
                {
                    var query = "update `arquivo` set `order` = {0} , `dataorder` = '{1}', `databoleto` = '{2}', `responseorder` = '{3}', `totalorder` = {4}, `orderid` = {5} where `idarquivo` = '{6}';";

                    string cmdText = String.Format(query, item.Success, item.DataOrder, item.DataBoleto, item.Result, item.TotalOrder, item.OrderId, item.IdArquivo);

                    MySqlCommand comm = new MySqlCommand(cmdText, conn, transaction);

                    comm.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao atualizar dados do arquivo na CashCard, relacionado a criacao de pedido na Orders. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.UpdateStatusArquivo", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

        /// <summary>
        /// Atualiza informações de recarga no arquivo e dos seus pedidos.
        /// </summary>
        /// <param name="idArquivo">Id do arquivo</param>
        /// <param name="statusRechargeArquivo">Status da recarga, se foi ou não realizada</param>
        /// <param name="arquivoItens">Lista de pedidos do arquivo</param>
        public void UpdateStatusArquivo(String idArquivo, Boolean statusRechargeArquivo)
        {

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;

                conn.Open();

                transaction = conn.BeginTransaction();

                try
                {
                    var query = "update arquivo set recharge = {0} , datarecharge = now() where idarquivo = '{1}';";

                    MySqlCommand comm = new MySqlCommand(String.Format(query, statusRechargeArquivo, idArquivo), conn, transaction);

                    //Atualiza informações de recarga do arquivo
                    comm.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao atualizar dados do arquivo na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.UpdateStatusItens", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

        /// <summary>
        /// Atualiza informações de exportação no arquivo.
        /// </summary>
        /// <param name="idArquivo">Id do arquivo</param>
        /// <param name="statusExportArquivo">Status da exportação, se foi ou não realizada</param>
        public void UpdateStatusExport(String idArquivo, Boolean statusExportArquivo)
        {
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;

                conn.Open();

                transaction = conn.BeginTransaction();

                try
                {
                    var query = "update arquivo set export = {0}, dataexport = now() where idarquivo = '{1}';";

                    MySqlCommand comm = new MySqlCommand(String.Format(query, statusExportArquivo, idArquivo), conn, transaction);

                    comm.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao atualizar dados na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.UpdateStatusExport", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

        /// <summary>
        /// Lista os pedidos do arquivo que estão aptos para serem exportados
        /// </summary>
        /// <param name="idArquivo">Id do arquivo</param>
        /// <returns>Lista dos pedidos a serem exportados</returns>
        public List<ArquivoToExport> GetArquivosReprocessedToExport(string idArquivo)
        {
            List<ArquivoToExport> lArquivoToExport = new List<ArquivoToExport>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = String.Format(@"select 
                                a.idcliente, 
                                a.nomearquivo, 
                                a.datarecharge, 
                                ai.cardid, 
                                ai.cpf, 
                                ai.identificador, 
                                ai.limite, 
                                ai.saldo, 
                                ai.descricaoprocessamento, 
                                ai.recharge, 
                                ai.vlrecarga 
                        from arquivo a inner join arquivoitem ai on a.idarquivo = ai.idarquivo 
                        where a.idarquivo = '{0}'", idArquivo);

                    using (MySqlCommand comm = new MySqlCommand(query, conn))
                    {
                        MySqlDataReader reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            ArquivoToExport arquivoExport = new ArquivoToExport();
                            arquivoExport.IdCliente = reader["idcliente"].ToString();
                            arquivoExport.NomeArquivo = reader["nomearquivo"].ToString();
                            arquivoExport.DataRecarga = reader["datarecharge"].ToString();
                            arquivoExport.CardId = reader["cardid"].ToString();
                            arquivoExport.Cpf = reader["cpf"].ToString();
                            arquivoExport.Identificador = reader["identificador"].ToString();
                            arquivoExport.Limite = reader["limite"].ToString();
                            arquivoExport.Saldo = reader["saldo"].ToString();
                            arquivoExport.DescricaoProcessamento = reader["descricaoprocessamento"].ToString();
                            arquivoExport.Recharge = reader["recharge"].ToString() == "1" ? true : false;
                            arquivoExport.VlRecarga = reader["vlrecarga"].ToString();

                            lArquivoToExport.Add(arquivoExport);
                        }
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {
                string msg = String.Format("Erro ao consultar dados na CashCard. ERRO: {0}", ex.Message);

                Instance.SaveLog("CashCard.GetArquivosToExport", DateTime.Now, msg, true);
            }

            return lArquivoToExport;
        }

        /// <summary>
        /// Lista os pedidos do arquivo que estão aptos para serem exportados
        /// </summary>
        /// <param name="idArquivo">Id do arquivo</param>
        /// <returns>Lista dos pedidos a serem exportados</returns>
        public List<ArquivoToExport> GetArquivosToExport(string idArquivo)
        {
            List<ArquivoToExport> lArquivoToExport = new List<ArquivoToExport>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = String.Format(@"select 
                                a.idcliente, 
                                a.nomearquivo, 
                                a.datarecharge, 
                                ai.cardid, 
                                ai.cpf, 
                                ai.identificador, 
                                ai.limite, 
                                ai.saldo, 
                                ai.descricaoprocessamento, 
                                ai.recharge, 
                                ai.vlrecarga, 
                                ai.regionid, 
                                ai.companyid 
                            from arquivo a 
                                inner join arquivoitem ai 
                                    on a.idarquivo = ai.idarquivo 
                            where a.idarquivo = '{0}'", idArquivo);

                    using (MySqlCommand comm = new MySqlCommand(query, conn))
                    {
                        MySqlDataReader reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            ArquivoToExport arquivoExport = new ArquivoToExport();
                            arquivoExport.IdCliente = reader["idcliente"].ToString();
                            arquivoExport.RegionId = reader["regionid"].ToString();
                            arquivoExport.CompanyId = reader["companyid"].ToString();
                            arquivoExport.NomeArquivo = reader["nomearquivo"].ToString();
                            arquivoExport.DataRecarga = reader["datarecharge"].ToString();
                            arquivoExport.CardId = reader["cardid"].ToString();
                            arquivoExport.Cpf = reader["cpf"].ToString();
                            arquivoExport.Identificador = reader["identificador"].ToString();
                            arquivoExport.Limite = reader["limite"].ToString();
                            arquivoExport.Saldo = reader["saldo"].ToString();
                            arquivoExport.DescricaoProcessamento = reader["descricaoprocessamento"].ToString();
                            arquivoExport.Recharge = reader["recharge"].ToString() == "1" ? true : false;
                            arquivoExport.VlRecarga = reader["vlrecarga"].ToString();


                            lArquivoToExport.Add(arquivoExport);
                        }
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {
                string msg = String.Format("Erro ao consultar dados na CashCard. ERRO: {0}", ex.Message);

                Instance.SaveLog("CashCard.GetArquivosToExport", DateTime.Now, msg, true);
            }

            return lArquivoToExport;
        }

        /// <summary>
        /// Lista todos os pedidos no banco a serem processados para recarga/exportação, de um cliente específico, de acordo ao nome do arquivo (opcional).
        /// </summary>
        /// <param name="field">Ação a ser verificada: Recharge ou Export</param>
        /// <param name="idCliente">Código do cliente</param>
        /// <param name="nomeArquivo">Nome do arquivo (opcional)</param>
        /// <returns>Lista de pedidos a serem processados para recarga/exportação</returns>
        public List<string> GetArquivosByStatus(string field, int idCliente, string nomeArquivo)
        {
            List<string> lArquivos = new List<string>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = String.Format("select a.idarquivo from arquivo a where a.idcliente = {0} and (a.{1} is null or a.{1} = 0)", idCliente, field);

                    if (field == "recharge")
                    {
                        query += " and a.import = 1 and a.export is null";
                    }
                    else if (field == "export")
                    {
                        query += " and a.datarecharge is not null";
                    }

                    if (!String.IsNullOrEmpty(nomeArquivo))
                    {
                        query += String.Format(" and a.nomearquivo = {0}", nomeArquivo);
                    }

                    using (MySqlCommand comm = new MySqlCommand(query, conn))
                    {
                        MySqlDataReader reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            string idArquivo = reader["idarquivo"].ToString();
                            lArquivos.Add(idArquivo);
                        }
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {
                string msg = String.Format("Erro ao consultar dados na CashCard. ERRO: {0}", ex.Message);

                Instance.SaveLog("CashCard.GetArquivosByStatus", DateTime.Now, msg, true);
            }

            return lArquivos;
        }

        /// <summary>
        /// Salva o log do sistema
        /// </summary>
        /// <param name="titulo">Título</param>
        /// <param name="date">Data</param>
        /// <param name="message">Menssagem</param>
        /// <param name="isError">Se foi um erro ou não</param>
        public void SaveLog(String titulo, DateTime date, String message, Boolean isError)
        {
            try
            {
                String idLog = Guid.NewGuid().ToString();

                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    conn.Open();

                    var query = "insert log (idlog, titulo, date, message, iserror) values ('{0}','{1}','{2}','{3}',{4})";

                    string cmdText = String.Format(query, idLog, titulo, date.ToString("yyyy-MM-dd HH:mm:ss"), message, isError);

                    using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                    {
                        comm.ExecuteNonQuery();
                    }
                    conn.Close();

                }
            }
            catch (Exception ex)
            {
                string msg = String.Format("Erro ao salvar dados na CashCard. ERRO: {0}. ", ex.Message);

                Console.WriteLine(msg + DateTime.Now.ToString());
            }
        }

        /// <summary>
        /// Lista todos os pedidos do arquivo que serão processados na recarga.
        /// </summary>
        /// <param name="idArquivo">Código do arquivo</param>
        /// <returns>Lista de pedidos do arquivo que serão processados na recarga</returns>
        public List<ArquivoResponse> GetArquivoToRecharge(string idArquivo)
        {
            List<ArquivoResponse> lArquivoResponse = new List<ArquivoResponse>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {

                    try
                    {
                        conn.Open();

                        MySqlCommand command = conn.CreateCommand();
                        command.Connection = conn;

                        var query = @"select 
                    a.idarquivo, 
                    ai.idarquivoitem, 
                    ai.cardid, 
                    ai.cpf, 
                    ai.vlrecarga, 
                    ai.idaccount, 
                    ai.codsituacao,
                    ai.identificador, 
                    ai.limite,
                    ai.idaccountparent,
                    ai.saldo
                from arquivo as a 
                    inner join arquivoitem as ai on a.idarquivo = ai.idarquivo 
                where a.idarquivo = '{0}' and a.import = true 
                    and (a.recharge = false or a.recharge is null) 
                    and (ai.recharge = false or ai.recharge is null)
                    and ai.cardid is not null
                order by idaccount asc";

                        command.CommandText = String.Format(query, idArquivo);

                        MySqlDataReader reader = command.ExecuteReader();

                        while (reader.Read())
                        {
                            ArquivoResponse arquivoResponse = new ArquivoResponse();
                            arquivoResponse.IdArquivo = reader["idarquivo"].ToString();
                            arquivoResponse.IdArquivoItem = reader["idarquivoitem"].ToString();

                            arquivoResponse.CardId = !string.IsNullOrEmpty(reader["cardid"].ToString()) ? reader["cardid"].ToString() : string.Empty;

                            arquivoResponse.Cpf = !string.IsNullOrEmpty(reader["cpf"].ToString()) ? reader["cpf"].ToString() : string.Empty;

                            if (!string.IsNullOrEmpty(reader["vlrecarga"].ToString()))
                            {
                                arquivoResponse.VlRecarga = Convert.ToDecimal(reader["vlrecarga"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["idaccount"].ToString()))
                            {
                                arquivoResponse.IdAccount = Convert.ToInt64(reader["idaccount"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["idaccountparent"].ToString()))
                            {
                                arquivoResponse.IdAccountParent = Convert.ToInt64(reader["idaccountparent"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["codsituacao"].ToString()))
                            {
                                arquivoResponse.CodSituacao = Convert.ToInt32(reader["codsituacao"].ToString());
                            }

                            arquivoResponse.Identificador = !string.IsNullOrEmpty(reader["identificador"].ToString()) ? reader["identificador"].ToString() : string.Empty;

                            if (!string.IsNullOrEmpty(reader["limite"].ToString()))
                            {
                                arquivoResponse.Limite = Convert.ToDecimal(reader["limite"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["saldo"].ToString()))
                            {
                                arquivoResponse.Saldo = Convert.ToDecimal(reader["saldo"].ToString());
                            }

                            lArquivoResponse.Add(arquivoResponse);
                        }

                        conn.Close();
                    }
                    catch (Exception ex)
                    {

                        string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                        Instance.SaveLog("Cabify.GetArquivoToRecharge", DateTime.Now, msg, true);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return lArquivoResponse;

        }

        /// <summary>
        /// Lista todos os pedidos do arquivo que serão processados na recarga.
        /// </summary>
        /// <param name="idArquivo">Código do arquivo</param>
        /// <returns>Lista de pedidos do arquivo que serão processados na recarga</returns>
        public List<ArquivoResponse> GetArquivosToReprocessRecharge(string idArquivo)
        {
            List<ArquivoResponse> lArquivoResponse = new List<ArquivoResponse>();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
                {
                    try
                    {
                        conn.Open();

                        MySqlCommand command = conn.CreateCommand();
                        command.Connection = conn;

                        var query = @"select 
                    a.idarquivo, 
                    ai.idarquivoitem, 
                    ai.cardid, 
                    ai.cpf, 
                    ai.vlrecarga, 
                    ai.idaccount, 
                    ai.codsituacao,
                    ai.identificador, 
                    ai.limite,
                    ai.saldo,
                    ai.idaccountparent,
                    a.idcliente
                 from arquivo as a 
                    inner join arquivoitem as ai on a.idarquivo = ai.idarquivo 
                 where
                    ai.idarquivo = '{0}' and (ai.recharge is null or ai.recharge = 0)
                 order by idaccount asc";

                        command.CommandText = String.Format(query, idArquivo);

                        MySqlDataReader reader = command.ExecuteReader();

                        while (reader.Read())
                        {
                            ArquivoResponse arquivoResponse = new ArquivoResponse();
                            arquivoResponse.IdArquivo = reader["idarquivo"].ToString();
                            arquivoResponse.IdArquivoItem = reader["idarquivoitem"].ToString();

                            arquivoResponse.CardId = !string.IsNullOrEmpty(reader["cardid"].ToString()) ? reader["cardid"].ToString() : string.Empty;

                            arquivoResponse.Cpf = !string.IsNullOrEmpty(reader["cpf"].ToString()) ? reader["cpf"].ToString() : string.Empty;

                            if (!string.IsNullOrEmpty(reader["vlrecarga"].ToString()))
                            {
                                arquivoResponse.VlRecarga = Convert.ToDecimal(reader["vlrecarga"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["idaccount"].ToString()))
                            {
                                arquivoResponse.IdAccount = Convert.ToInt64(reader["idaccount"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["codsituacao"].ToString()))
                            {
                                arquivoResponse.CodSituacao = Convert.ToInt32(reader["codsituacao"].ToString());
                            }

                            arquivoResponse.Identificador = !string.IsNullOrEmpty(reader["identificador"].ToString()) ? reader["identificador"].ToString() : string.Empty;

                            if (!string.IsNullOrEmpty(reader["limite"].ToString()))
                            {
                                arquivoResponse.Limite = Convert.ToDecimal(reader["limite"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["saldo"].ToString()))
                            {
                                arquivoResponse.Saldo = Convert.ToDecimal(reader["saldo"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["idaccountparent"].ToString()))
                            {
                                arquivoResponse.IdAccountParent = Convert.ToInt64(reader["idaccountparent"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["saldo"].ToString()))
                            {
                                arquivoResponse.Saldo = Convert.ToDecimal(reader["saldo"].ToString());
                            }

                            if (!string.IsNullOrEmpty(reader["idcliente"].ToString()))
                            {
                                arquivoResponse.IdCliente = Convert.ToInt32(reader["idcliente"].ToString());
                            }

                            lArquivoResponse.Add(arquivoResponse);
                        }

                        conn.Close();
                    }
                    catch (Exception ex)
                    {

                        string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                        Instance.SaveLog("Cabify.GetArquivoToReeprocess", DateTime.Now, msg, true);

                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return lArquivoResponse;

        }

        public List<InfoEmail> GetInfoEmail(int idCliente)
        {
            List<InfoEmail> listInfoEmail = new List<InfoEmail>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                try
                {
                    conn.Open();

                    MySqlCommand command = conn.CreateCommand();
                    command.Connection = conn;

                    var query = @"SELECT
                a.idarquivo,
                a.nomearquivo,
                a.dataarquivo as dtinicio,
                a.dataexport as dtfinal,
                a.linhas,
                a.recharge,
                t1.notrecharge,
                t2.isrecharge,
                t3.situacaonaoaut,
                t4.naoencontrado,
                t5.superior
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo left join (

            SELECT 
                a.idarquivo,
                count(a.idarquivo) as notrecharge
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
            where ai.recharge = 0 
            group by a.idarquivo
            ) as t1 on t1.idarquivo = a.idarquivo left join (

            SELECT 
                a.idarquivo,
                count(a.idarquivo) as isrecharge
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
            where ai.recharge = 1 
            group by a.idarquivo
            ) as t2 on t2.idarquivo = a.idarquivo left join (

            SELECT 
                a.idarquivo,
                count(a.idarquivo) as situacaonaoaut
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
            where ai.recharge = 0 and ai.descricaoprocessamento like '%situacao%' 
            group by a.idarquivo
            ) as t3 on t3.idarquivo = a.idarquivo  left join (

            SELECT 
                a.idarquivo,
                count(a.idarquivo) as naoencontrado
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
            where ai.recharge = 0 and ai.descricaoprocessamento like '%encontrado%' 
            group by a.idarquivo
            ) as t4 on t4.idarquivo = a.idarquivo  left join (

           SELECT 
                a.idarquivo,
                count(a.idarquivo) as superior
            FROM arquivo as a inner join arquivoitem as ai on a.idarquivo = ai.idarquivo
            where ai.recharge = 0 and ai.descricaoprocessamento like '%superior%' 
            group by a.idarquivo
            ) as t5 on t5.idarquivo = a.idarquivo

            where a.idcliente = {0} and a.email is null
            group by a.idarquivo";

                    command.CommandText = String.Format(query, idCliente);

                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        InfoEmail infoEmail = new InfoEmail();

                        infoEmail.IdArquivo = reader["idarquivo"].ToString();
                        infoEmail.NomeArquivo = reader["nomearquivo"].ToString();

                        if (!string.IsNullOrEmpty(reader["dtinicio"].ToString()))
                        {
                            infoEmail.DtInicio = Convert.ToDateTime(reader["dtinicio"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["dtfinal"].ToString()))
                        {
                            infoEmail.DtFinal = Convert.ToDateTime(reader["dtfinal"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["linhas"].ToString()))
                        {
                            infoEmail.Linhas = Convert.ToInt32(reader["linhas"].ToString());

                        }

                        if (!string.IsNullOrEmpty(reader["recharge"].ToString()))
                        {
                            infoEmail.Recharge = Convert.ToBoolean(reader["recharge"]);
                        }

                        if (!string.IsNullOrEmpty(reader["isrecharge"].ToString()))
                        {
                            infoEmail.IsRecharge = Convert.ToInt32(reader["isrecharge"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["notrecharge"].ToString()))
                        {
                            infoEmail.NotRecharge = Convert.ToInt32(reader["notrecharge"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["situacaonaoaut"].ToString()))
                        {
                            infoEmail.SituacaoNaoAut = Convert.ToInt32(reader["situacaonaoaut"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["naoencontrado"].ToString()))
                        {
                            infoEmail.NaoEncontrado = Convert.ToInt32(reader["naoencontrado"].ToString());
                        }

                        if (!string.IsNullOrEmpty(reader["superior"].ToString()))
                        {
                            infoEmail.Superior = Convert.ToInt32(reader["superior"].ToString());
                        }

                        infoEmail.Outros = infoEmail.Linhas - infoEmail.IsRecharge - (infoEmail.NaoEncontrado + infoEmail.SituacaoNaoAut + infoEmail.Superior);

                        listInfoEmail.Add(infoEmail);
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string msg = String.Format("Erro ao realizar consulta na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("Cabify.GetInfoEmail", DateTime.Now, msg, true);
                }
            }

            return listInfoEmail;
        }

        public void UpdateEmailCashCard(Boolean IsSendEmail, string idArquivo)
        {
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["CashCard"].ConnectionString))
            {
                MySqlTransaction transaction = null;

                conn.Open();

                transaction = conn.BeginTransaction();

                try
                {
                    var query = String.Format(@"update arquivo set 
                email = {0},
                dataemail = now() 
              where idarquivo = '{1}'", IsSendEmail, idArquivo);

                    using (MySqlCommand comm = new MySqlCommand(query, conn, transaction))
                    {
                        comm.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    string msg = String.Format("Erro ao atualizar dados na CashCard. ERRO: {0}", ex.Message);

                    Instance.SaveLog("CashCard.UpdateEmailInCashCard", DateTime.Now, msg, true);
                }

                conn.Close();
            }

        }

    }
}

﻿using CashCard.Model;
using Renci.SshNet;
using System;
using System.IO;
using System.Text;

namespace CashCard.Util
{
    public class FtpService
    {
        private static FtpService oFtpService;

        public static FtpService Instance { get { oFtpService = oFtpService ?? new FtpService(); return oFtpService; } }

        /// <summary>
        /// Verifica se a conexão sftp é válida
        /// </summary>
        /// <param name="sftp">Informações do sftp</param>
        /// <param name="remoteDir">Nome do diretório remoto</param>
        /// <returns>Se foi ou não possível realizar a conexão sftp</returns>
        public Boolean CheckConnect(SftpClient sftp, string remoteDir)
        {
            Boolean success = false;

            try
            {
                using (sftp)
                {
                    sftp.KeepAliveInterval = TimeSpan.FromSeconds(60);

                    try
                    {
                        sftp.Connect();

                        success = sftp.Exists(remoteDir);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        success = false;
                    }
                    finally
                    {
                        if (sftp.IsConnected)
                        {
                            sftp.Disconnect();
                            sftp.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                string message = string.Format("Erro ao checar conexão sftp. ERRO: {0}.", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.CheckConnect", DateTime.Now, message, true);
            }

            return success;
        }

        /// <summary>
        /// Envia o arquivo csv informado, via sftp, de um diretório local para um diretório remoto
        /// </summary>
        /// <param name="sftp">Informações do sftp</param>
        /// <param name="remoteDir">Nome do diretório remoto</param>
        /// <param name="localDir">Nome do diretório local</param>
        /// <param name="fileName">Nome do documento</param>
        /// <returns>Se foi ou não realizada o envio do arquivo csv</returns>
        public Boolean SendFile(SftpClient sftp, string remoteDir, string localDir, string fileName)
        {
            Boolean sucess = false;

            using (sftp)
            {
                FileStream fileStream = null;

                try
                {
                    sftp.KeepAliveInterval = TimeSpan.FromSeconds(60);

                    sftp.Connect();

                    fileStream = new FileStream(localDir, FileMode.Open);

                    if (fileStream != null)
                    {
                        FileInfo fileInfo = new FileInfo(localDir);

                        //TODO Itau
                        //sftp.UploadFile(fileStream, String.Concat(remoteDir, "/", fileName), true, null);

                        sucess = true;
                    }
                }
                catch (Exception ex)
                {
                    string message = string.Format("Erro ao enviar o arquivo de retorno {0} via sftp. ERRO: {1}.", fileName, ex.Message);

                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.SendFile", DateTime.Now, message, true);

                    sucess = false;
                }
                finally
                {
                    fileStream.Close();
                    sftp.Disconnect();
                    sftp.Dispose();
                }
            }

            return sucess;

        }

        /// <summary>
        /// Realiza do downloading do arquivo csv do diretório remoto para o diretório local, via sftp.
        /// O nome do arquivo deve conter o "nome do cliente", a palavra "input" e o formato "csv" em seu nome, por exemplo cabify_recarga_yyyy-MM-dd_input.csv.
        /// Pode conter outras informações ou códigos das empresa, por exemplo cabify_recarga_{outros}_input.csv.
        /// </summary>
        /// <param name="config">Informações de configuração de um cliente específico</param>
        public void DownloadDirectory(JsonConfiguration.Configuration config)
        {
            string fileName = "";

            foreach (var source in config.Sources)
            {
                string remoteDir = source.FtpDirectory;

                string localDir = source.LocalPath;

                SftpClient sftp = Instance.GetConnectionInfo(source);

                try
                {
                    using (sftp)
                    {
                        sftp.KeepAliveInterval = TimeSpan.FromSeconds(60);

                        sftp.Connect();

                        var files = sftp.ListDirectory(remoteDir);

                        if (!File.Exists(localDir))
                            Directory.CreateDirectory(localDir);

                        int processed = 0;

                        foreach (var file in files)
                        {
                            fileName = file.Name;

                            //Só devem ser baixados arquivos que contenham o nome do cliente, a palavra input e o tipo de arquivo csv
                            if (file.Name.Contains("_input") && file.Name.Contains(config.Cliente) && file.Name.Contains("csv") &&
                                !file.IsDirectory && !file.IsSymbolicLink)
                            {
                                using (Stream fileStream = File.OpenWrite(Path.Combine(localDir, file.Name)))
                                {
                                    sftp.DownloadFile(file.FullName, fileStream);
                                }

                                string message = string.Format("Dowloading do arquivo {0} realizado com sucesso.", file.FullName);

                                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.DownloadDirectory", DateTime.Now, message, false);

                                //Uma vez feito o downloading, se renomeia o arquivo para que ele não volte a ser baixado, trocando o input pelo proc
                                string newName = remoteDir + "/" + file.Name.Replace("_input.csv", "_proc.csv");

                                sftp.RenameFile(file.FullName, newName);

                                processed += 1;
                            }
                        }

                        if (processed == 0)
                        {
                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.DownloadDirectory", DateTime.Now, "Não foi encontrado nenhum arquivo para downloading.", false);
                        }
                    }
                }
                catch (Exception ex)
                {
                    string message = string.Format("Falha no dowloading do arquivo {0}. ERRO: {1}", fileName, ex.Message);
                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.DownloadDirectory", DateTime.Now, message, true);
                }
            }
        }

        public SftpClient GetConnectionInfo(JsonConfiguration.Configuration.Source source)
        {
            try
            {
                KeyboardInteractiveAuthenticationMethod kauth = new KeyboardInteractiveAuthenticationMethod(source.FtpUser);

                PasswordAuthenticationMethod pauth = new PasswordAuthenticationMethod(source.FtpUser, source.FtpPwd);

                kauth.AuthenticationPrompt += new EventHandler<Renci.SshNet.Common.AuthenticationPromptEventArgs>((obj, args) => HandleKeyEvent(obj, args, source));

                ConnectionInfo connectionInfo = new ConnectionInfo(source.FtpUrl, source.FtpPort, source.FtpUser, pauth, kauth);

                var sftp = new SftpClient(connectionInfo);

                return sftp;
            }
            catch (Exception ex)
            {

                string message = string.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.GetConnectionInfo", DateTime.Now, message, true);

                return null;
            }

        }

        void HandleKeyEvent(Object sender, Renci.SshNet.Common.AuthenticationPromptEventArgs e, JsonConfiguration.Configuration.Source source)
        {
            try
            {
                foreach (Renci.SshNet.Common.AuthenticationPrompt prompt in e.Prompts)
                {
                    if (prompt.Request.IndexOf("Password:", StringComparison.InvariantCultureIgnoreCase) != -1)
                    {
                        prompt.Response = source.FtpPwd;
                    }
                }
            }
            catch (Exception ex)
            {

                string message = string.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("FtpService.HandleKeyEvent", DateTime.Now, message, true);
            }

        }
    }
}

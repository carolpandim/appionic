﻿using CashCard.Model;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace CashCard.Util
{
	public class CsvHelper
	{
		private static CsvHelper oCsvHelper;

		public static CsvHelper Instance { get { oCsvHelper = oCsvHelper ?? new CsvHelper(); return oCsvHelper; } }

		/// <summary>
		/// Se extrai as informações do arquivo csv para uma tabela, recuperando apenas os dados necessários para o seu posterior processamento.
		/// As colunas do arquivo csv devem, obrigatóriamente, estarem separados por ";"
		/// E devem ter as respectivas colunas ou headers, definidos no arquivo de configuração do cliente, no objeto HeadersInput
		/// </summary>
		/// <param name="config">Informações de configuração de um cliente específico</param>
		/// <param name="fileInfo">~Informações sobre as propriedades e métodos do arquivo a ser extraído</param>
		/// <returns></returns>
		public DataTable ExtractFomCSV(JsonConfiguration.Configuration config, FileInfo fileInfo)
		{
			DataTable dataTable = new DataTable();

			try
			{
				using (TextReader reader = File.OpenText(fileInfo.FullName))
				{					
					CsvReader csv = new CsvReader(reader);

					//Os dados das colunas serão extraídos considerando o delimitador ";"
					csv.Configuration.Delimiter = ";";

					csv.Read();

					csv.ReadHeader();

                    //Extraio apenas os headers do arquivo csv
                    //List<string> headers = csv.Context.HeaderRecord.Select(x => x.ToLower().Replace(" ", "")).ToList();
                    List<string> headers = csv.Context.HeaderRecord.Select(x => x.Trim()).ToList();
					
					Boolean hasAllColumns = true;

					//Percorro pelos headers de input, definidos no arquivo de configuração
					for (int i = 0; i < config.HeadersInput.Count; i++)
					{
						//Comparo se o header de input atual está incluso entre os headers recuperados do arquivo csv
						if (!headers.Contains(config.HeadersInput[i].Trim()))
						{
							hasAllColumns = false;
						}
					}

					//Se tiverem todos os headers presentes
					if (hasAllColumns)
					{
						//Começo a alimentar minha tabela, começando pelos headers
						foreach (string header in config.HeadersInput)
						{
							dataTable.Columns.Add(new DataColumn(header));
						}

						//Logo, pelas respectivas informações, de acordo com o header da coluna
						while (csv.Read())
						{
							DataRow row = dataTable.NewRow();

							foreach (DataColumn column in dataTable.Columns)
							{
								row[column.ColumnName] = csv.GetField(column.DataType, column.ColumnName).ToString();

							}

							dataTable.Rows.Add(row);

						}

						string message = string.Format("Leitura do arquivo {0} realizada com sucesso. Foram extraídos {1} registros.", fileInfo.Name, dataTable.Rows.Count);

						CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CsvHelper.ExtractFomCSV", DateTime.Now, message, false);
					}
					else
					{
						string message = string.Format("Arquivo '{0}' não contém os headers requeridos.", fileInfo.Name);

						CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CsvHelper.ExtractFomCSV", DateTime.Now, message, true);
					}
				}
			}
			catch (Exception ex)
			{
				dataTable = null;

				string message = string.Format("Não foi possível realizar a leitura do arquivo '{0}'. ERRO: .", fileInfo.Name, ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CsvHelper.ExtractFomCSV", DateTime.Now, message, true);
			}

			return dataTable;
		}

    }
}

﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Response;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CashCard.Util
{
	public class ExportData
	{
		private static ExportData oExportData;

		public static ExportData Instance { get { oExportData = oExportData ?? new ExportData(); return oExportData; } }
        
        /// <summary>
        /// Realiza a montagem do arquivo csv com as informações de retorno da recarga e, as exporta para um diretório remoto
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        /// <returns></returns>
        public void ProcessFile(JsonConfiguration.Configuration config)
		{
			Boolean sucess = false;
			string message = "";

			List<ArquivoToExport> lArquivoToExport = new List<ArquivoToExport>();

			try
			{
				//Lista todos os pedidos no banco a serem processados para exportação, de um cliente específico, de acordo ao nome do arquivo(opcional).
				List<string> lArquivo = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosByStatus("export", config.IdCliente, null);

				if (lArquivo.Count > 0)
				{
					foreach (var item in lArquivo)
					{
						//Lista os pedidos do arquivo que estão aptos para serem exportados
						lArquivoToExport = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosToExport(item);

						List<JsonConfiguration.Configuration.Source> sources = config.Sources;

						//Monta a string a ser incluída no arquivo csv, separada por ";", de acordo com as informações do HeadersOutput do arquivo de configuração do cliente
						string csv = CsvGenerate.GetCSV(lArquivoToExport, config);

						//Renomeia o arquivo 
						string fileName = lArquivoToExport[0].NomeArquivo.Replace("_input.csv", "_output.csv");

						//diretório local
						string localDir = sources[0].LocalPath + "\\" + fileName;

						using (StreamWriter outputFile = new StreamWriter(localDir))
						{
							//Monta o arquivo csv
							var output = outputFile.WriteAsync(csv);
                            output.Wait();
						}

						//diretório remoto
						string remoteDir = sources[0].FtpDirectory;

						SftpClient sftp = FtpService.Instance.GetConnectionInfo(sources[0]);

                        //Envia o arquivo csv informado, via sftp, do diretório local para diretório remoto
                        sucess = FtpService.Instance.SendFile(sftp, remoteDir, localDir, fileName);

						if (sucess)
						{
							CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusExport(item, true);

							message = string.Format("Arquivo de retorno {0} exportado com sucesso.", item);

							CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ExportData.ProcessFile", DateTime.Now, message, false);
						}
						else
						{
							CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusExport(item, false);

							message = string.Format("Arquivo de retorno {0} não foi exportado.", item);

							CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ExportData.ProcessFile", DateTime.Now, message, true);
						}
					}
				}
				else
				{
					CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ExportData.ProcessFile", DateTime.Now, "Não foram encontrados arquivos para exportação.", false);
				}

			}
			catch (Exception ex)
			{
				message = string.Format("Erro na exportação. ERRO: {0}.", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ExportData.ProcessFile", DateTime.Now, message, true);

			}

		}
	}
}

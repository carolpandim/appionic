﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Request;
using CashCardDB.DataBase.Model.Response;
using Newtonsoft.Json;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CashCard.Util
{
    public class Reprocess
    {
        private static Reprocess oReprocess;

        public static Reprocess Instance { get { oReprocess = oReprocess ?? new Reprocess(); return oReprocess; } }

        /// <summary>
        /// Reprocessa os pedidos que não foram realizados recarga.
        /// </summary>
        /// <param name="idArquivo">Arquivo a ser reprocessado</param>
        public void ReprocessFileToRecharge(string idArquivo)
        {
            string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"configuration.js");

            string config = File.ReadAllText(path);

            var configuration = JsonConvert.DeserializeObject<JsonConfiguration>(config);

            List<ArquivoResponse> lArquivoToReprocess = new List<ArquivoResponse>();
            List<CashCardOrderResponse> lCashCardOrderResponse = new List<CashCardOrderResponse>();

            try
            {
                lArquivoToReprocess = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosToReprocessRecharge(idArquivo);

                if (lArquivoToReprocess.Count > 0)
                {
                    object Lock = new object();

                    Parallel.ForEach(lArquivoToReprocess,
                        item =>
                        {
                            lock (Lock)
                            {
                                JsonConfiguration.Configuration jConfig = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == item.IdCliente).FirstOrDefault();

                                //Se for Itaú
                                if (item.IdCliente == 2)
                                {
                                    if (item.Limite > item.Saldo)
                                    {
                                        //Se calcula a recomposição de limite no valor da recarga
                                        item.VlRecarga = item.Limite - item.Saldo;
                                    }
                                    else
                                    {
                                        //Se não, deixa zerado o valor da recarga
                                        item.VlRecarga = 0;
                                    }

                                    //Atualiza valor de recarga e o saldo no pedido do arquivo.
                                    CashCardDB.DataBase.Mysql.Procedures.Itau.Instance.UpdateRecargaItens(item);

                                    if (item.CodSituacao.HasValue && jConfig.SituacaoRecargaPermitida.Contains(item.CodSituacao.Value))
                                    {
                                        //Se houver valor de recarga, se realiza a recomposição de limite
                                        if (item.VlRecarga > 0)
                                        {
                                            CashCardOrderRequest cashCardOrderRequest = new CashCardOrderRequest();
                                            cashCardOrderRequest.id = item.IdAccountParent;
                                            cashCardOrderRequest.amount = item.VlRecarga.Value;
                                            cashCardOrderRequest.summary = "CashCard";
                                            cashCardOrderRequest.toAccount = item.IdAccount.ToString();

                                            CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                            //Envia o request para a web api da accounts pra realizar a recarga transferindo o dinheiro da conta matriz(Itaucred) para o beneficiário
                                            var response = HttpClientService.Instance.Transfer(item.IdAccountParent.ToString(), cashCardOrderRequest);
                                            cashCardOrderResponse.Success = response.Result.Success;
                                            cashCardOrderResponse = response.Result;
                                            cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            //cashCardOrderResponse.Success = true;
                                            //cashCardOrderResponse.Result = "TesteReprocesso";
                                            //cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            //cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            //Adiciona a resposta do post do pedido à uma lista de resultados
                                            lCashCardOrderResponse.Add(cashCardOrderResponse);

                                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                        }
                                        //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                        else
                                        {
                                            CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                            cashCardOrderResponse.Success = false;
                                            cashCardOrderResponse.Result = "Cartao com saldo superior ou igual ao limite informado.";
                                            cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            lCashCardOrderResponse.Add(cashCardOrderResponse);

                                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                        }
                                    }
                                    //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                    else
                                    {
                                        CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                        cashCardOrderResponse.Success = false;
                                        cashCardOrderResponse.Result = "Situacao do cartao nao permitida. Recarga nao realizada.";
                                        cashCardOrderResponse.idArquivo = item.IdArquivo;
                                        cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                        lCashCardOrderResponse.Add(cashCardOrderResponse);

                                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                    }

                                }
                                else ///Se Cabify
                                {
                                    if (item.CodSituacao.HasValue && jConfig.SituacaoRecargaPermitida.Contains(item.CodSituacao.Value))
                                    {
                                        CashCardOrderRequest cashCardOrderRequest = new CashCardOrderRequest();
                                        cashCardOrderRequest.id = item.IdAccountParent;
                                        cashCardOrderRequest.amount = item.VlRecarga.Value;
                                        cashCardOrderRequest.summary = "CashCard";
                                        cashCardOrderRequest.toAccount = item.IdAccount.ToString();
                                        Console.WriteLine(item.IdAccount.ToString());

                                        CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                        //Envia o request para a web api da accounts pra realizar a recarga
                                        var response = HttpClientService.Instance.Transfer(item.IdAccountParent.ToString(), cashCardOrderRequest);
                                        cashCardOrderResponse.Success = response.Result.Success;
                                        cashCardOrderResponse = response.Result;
                                        cashCardOrderResponse.idArquivo = item.IdArquivo;
                                        cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;


                                        //cashCardOrderResponse.Success = true;
                                        //cashCardOrderResponse.Result = "TesteReprocesso";
                                        //cashCardOrderResponse.idArquivo = item.IdArquivo;
                                        //cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                        //Adiciona a resposta do post do pedido à uma lista de resultados
                                        lCashCardOrderResponse.Add(cashCardOrderResponse);

                                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                    }
                                    //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                    else
                                    {
                                        CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                        cashCardOrderResponse.Success = false;
                                        cashCardOrderResponse.Result = "Situacao do cartao nao permitida. Recarga nao realizada.";
                                        cashCardOrderResponse.idArquivo = item.IdArquivo;
                                        cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                        lCashCardOrderResponse.Add(cashCardOrderResponse);

                                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                    }
                                }
                            }
                        });

                    //Verifica se foram processados todos os arquivos
                    var statusArquivo = (lCashCardOrderResponse.Where(x => x.Success).Count() == lCashCardOrderResponse.Count());

                    //Atualiza as informações de recarga no arquivo e nos seus pedidos, com as respectivas informações da lista de resultados, montada ao longo do precesso
                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusArquivo(idArquivo, statusArquivo);

                    if (statusArquivo)
                    {
                        string message = string.Format("Pedidos de recarga do arquivo {0} reprocessados com sucesso.", idArquivo);

                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToRecharge", DateTime.Now, message, false);

                        Console.WriteLine(message);
                    }
                    else
                    {
                        string message = string.Format("Não foram reprocessados todos os pedidos de recarga do arquivo {0}.", idArquivo);

                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToRecharge", DateTime.Now, message, false);

                        Console.WriteLine(message);
                    }
                }
                else
                {
                    string message = string.Format("Não foi encontrado o arquivo inserido {0}.", idArquivo);

                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToRecharge", DateTime.Now, message, false);

                    Console.WriteLine(message);
                }
            }
            catch (Exception ex)
            {

                string message = string.Format("Erro no reprocessamento da recarga do arquivo {0}. ERRO: {1}.", idArquivo, ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToRecharge", DateTime.Now, message, true);

                Console.WriteLine(message);
            }
        }

        /// <summary>
        /// Realiza a montagem do arquivo csv com as informações de retorno da recarga e, as exporta para um diretório remoto
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        /// <returns></returns>
        public void ReprocessFileToExport(JsonConfiguration configuration, string idArquivo)
        {
            Boolean sucess = false;
            string message = "";

            List<ArquivoToExport> lArquivoToExport = new List<ArquivoToExport>();

            try
            {
                //Lista os pedidos do arquivo que estão aptos para serem exportados
                lArquivoToExport = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosReprocessedToExport(idArquivo);

                int idCliente = Convert.ToInt32(lArquivoToExport.FirstOrDefault().IdCliente);

                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == idCliente).FirstOrDefault();

                List<JsonConfiguration.Configuration.Source> sources = config.Sources;

                //Monta a string a ser incluída no arquivo csv, separada por ";", de acordo com as informações do HeadersOutput do arquivo de configuração do cliente
                string csv = CsvGenerate.GetCSV(lArquivoToExport, config);

                //Renomeia o arquivo 
                string fileName = lArquivoToExport[0].NomeArquivo.Replace("_input.csv", "_output.csv");

                //diretório local
                string localDir = sources[0].LocalPath + "\\" + fileName;

                using (StreamWriter outputFile = new StreamWriter(localDir))
                {
                    //Monta o arquivo csv
                    var output = outputFile.WriteAsync(csv);
                    output.Wait();
                }

                //diretório remoto
                string remoteDir = sources[0].FtpDirectory;

                SftpClient sftp = FtpService.Instance.GetConnectionInfo(sources[0]);

                //Envia o arquivo informado csv, via sftp, de diretório local para diretório remoto informado
                sucess = FtpService.Instance.SendFile(sftp, remoteDir, localDir, fileName);

                if (sucess)
                {
                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusExport(idArquivo, true);

                    message = string.Format("Arquivo de retorno {0}, do reprocesso, exportado com sucesso.", idArquivo);

                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToExport", DateTime.Now, message, false);
                }
                else
                {
                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusExport(idArquivo, false);

                    message = string.Format("Arquivo de retorno {0}, do reprocesso, não foi exportado.", idArquivo);

                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToExport", DateTime.Now, message, true);
                }
            }
            catch (Exception ex)
            {
                message = string.Format("Erro na exportação do arquivo reprocessado. ERRO: {0}.", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Reprocess.ReprocessFileToExport", DateTime.Now, message, true);
            }
        }
    }
}

﻿using CashCard.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace CashCard.Util
{
	public class ImportData
	{
		private static ImportData oImportData;

		public static ImportData Instance { get { oImportData = oImportData ?? new ImportData(); return oImportData; } }

		/// <summary>
		/// Processa o arquivo csv, extraindo todas as informações e importando-as pro banco
		/// </summary>
		/// <param name="config">Informções de configuração de um cliente específico</param>
		public void ProcessFile(JsonConfiguration.Configuration config)
		{
			String result = "";

			string fileName = "";

			try
			{
				List<JsonConfiguration.Configuration.Source> sources = config.Sources.ToList();

				foreach (var source in sources)
				{
					string localDir = source.LocalPath;

					//Se recupera todos os arquivos no diretório local
					string[] fileEntries = Directory.GetFiles(localDir);

					if (fileEntries.Count() > 0)
					{
						foreach (string file in fileEntries)
						{
							FileInfo fileInfo = new FileInfo(file);

							fileName = fileInfo.Name;

							//Só devem ser importados arquivos que contenham o nome do cliente, input e o tipo de arquivo csv
							if (file.Contains("_input") && file.Contains(config.Cliente) && file.Contains("csv"))
							{
								//Verifica no banco se esse arquivo já foi importado
								var wasImported = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.CheckIfWasImported(config.IdCliente, fileName);

								//Se não foi, então importa
								if (!wasImported)
								{
									//Se extrai as informações do arquivo csv para uma tabela, recuperando apenas os dados necessários para o processo de recarga, 
									DataTable dt = CsvHelper.Instance.ExtractFomCSV(config, fileInfo);
									
									if (dt != null && dt.Rows.Count > 0)
									{
										//Salvamos as informações extraídas em modelos de dados e salvamos no banco
										switch (config.IdCliente)
										{
											case 1:												
												result = CabifyService.Instance.CreateArquivoCabify(config, dt, fileName);
												break;
											case 2:
												result = ItauService.Instance.CreateArquivoItau(config, dt, fileName);
												break;
											default:
												break;
										}
									}

									if (result == "OK")
									{
										string message = string.Format("Arquivo {0} importado com sucesso.", fileName);

										CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ImportData.ProcessFile", DateTime.Now, message, false);
									}
									else
									{
										string message = string.Format("Não foi possível importar o arquivo {0}. {1}", fileName, result);

										CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ImportData.ProcessFile", DateTime.Now, message, false);
									}
								}
								else
								{
									string message = string.Format("O arquivo {0} já foi importado anteriormente.", fileName);

									CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ImportData.ProcessFile", DateTime.Now, message, true);
								}
							}						
						}
					}
					else
					{
						CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ImportData.ProcessFile", DateTime.Now, "Diretório local vázio. Nenhuma importação foi realizada.", false);
					}
				}
			}
			catch (Exception ex)
			{
				string message = string.Format("Falha na importação do arquivo {0}. ERRO: {1}", fileName, ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ImportData.ProcessFile", DateTime.Now, message, true);
			}

		}
	}
}

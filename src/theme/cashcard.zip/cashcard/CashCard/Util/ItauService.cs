﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Request;
using CashCardDB.DataBase.Model.Response;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CashCard.Util
{
    public class ItauService
    {
        private static ItauService oItauService;

        public static ItauService Instance { get { oItauService = oItauService ?? new ItauService(); return oItauService; } }

        /// <summary>
        /// Preenchemos os modelos de dados das tabelas Arquivo e ArquivoItem, 
        /// com as respectivas informações de recarga do Itaú, e as salvamos no banco.
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        /// <param name="dataTable">Tabela preenchida com os dados extraídos do arquivo csv</param>
        /// <param name="pathName">Nome do arquivo</param>
        /// <returns>Retorna uma msg dizendo se foi possível ou não salvar/importar as informações no banco.</returns>
        public String CreateArquivoItau(JsonConfiguration.Configuration config, DataTable dataTable, string pathName)
        {
            String sucess = "";

            int companyId = config.CompanyId;
            int productId = config.ProductId;

            try
            {
                String idArquivo = Guid.NewGuid().ToString();

                Arquivo arquivo = new Arquivo();
                arquivo.IdArquivo = idArquivo;
                arquivo.NomeArquivo = pathName;
                arquivo.IdCliente = config.IdCliente;
                arquivo.DataArquivo = DateTime.Now;
                arquivo.Linhas = dataTable.Rows.Count;
                arquivo.Import = true;
                arquivo.DataImport = DateTime.Now;

                List<ArquivoItem> arquivoItens = new List<ArquivoItem>();

                foreach (DataRow row in dataTable.Rows)
                {

                    ArquivoItem item = new ArquivoItem();
                    item.IdArquivoItem = Guid.NewGuid().ToString();
                    item.IdArquivo = idArquivo;
                    item.Identificador = row["identificador"].ToString();
                    item.Limite = row["limite"].ToString().Replace(",", ".");
                    item.Cpf = "";
                    arquivoItens.Add(item);

                    Thread.Sleep(10);
                }

                //Recupera código do cartão e do cpf na Self e atualiza lista de pedidos
                arquivoItens = CashCardDB.DataBase.Mysql.Procedures.Itau.Instance.GetCardId(arquivoItens, companyId, productId);

                //Salva os pedidos de recarga no banco CashCard, nas tabelas Arquivo e ArquivoItem
                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SalvarArquivo(arquivo, arquivoItens, config.AccountIdMatriz);

                sucess = "OK";
            }
            catch (Exception ex)
            {
                sucess = "ERRO: " + ex.Message;

                string message = string.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauService.CreateArquivoItau", DateTime.Now, message, true);
            }

            return sucess;
        }

        /// <summary>
        /// Realizo a recarga dos pedidos que foram importados, que não foram ainda processados na recarga, considerando a situação do cartão.
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        public void Recharge(JsonConfiguration.Configuration config)
        {
            List<ArquivoResponse> lArquivoToRecharge = new List<ArquivoResponse>();
            List<CashCardOrderResponse> lCashCardOrderResponse = new List<CashCardOrderResponse>();

            string idArquivo = "";

            try
            {
                //Lista todos os pedidos do Itaú a serem processados para recarga
                List<string> lArquivo = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosByStatus("recharge", config.IdCliente, null);

                if (lArquivo.Count > 0)
                {
                    foreach (var arquivo in lArquivo)
                    {
                        idArquivo = arquivo;

                        //Lista todos os pedidos do arquivo que serão processados na recarga
                        lArquivoToRecharge = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivoToRecharge(arquivo);

                        if (lArquivoToRecharge.Count > 0)
                        {
                            object Lock = new object();

                            Parallel.ForEach(lArquivoToRecharge,
                                item =>
                                {
                                    lock (Lock)
                                    {
                                        //Se o limite for maior que o saldo
                                        if (item.Limite > item.Saldo)
                                        {
                                            //Se calcula a recomposição de limite no valor da recarga
                                            item.VlRecarga = item.Limite - item.Saldo;
                                        }
                                        else
                                        {
                                            //Se não, deixa zerado o valor da recarga
                                            item.VlRecarga = 0;
                                        }

                                        //Atualiza valor de recarga e o saldo no pedido do arquivo.
                                        CashCardDB.DataBase.Mysql.Procedures.Itau.Instance.UpdateRecargaItens(item);

                                        //Verifica no arquivo de configuração se a situação do cartão é permitida
                                        if (config.SituacaoRecargaPermitida.Contains(item.CodSituacao.Value))
                                        {
                                            //Se houver valor de recarga, se realiza a recomposição de limite
                                            if (item.VlRecarga > 0)
                                            {
                                                CashCardOrderRequest cashCardOrderRequest = new CashCardOrderRequest();
                                                cashCardOrderRequest.id = config.AccountIdMatriz;
                                                cashCardOrderRequest.amount = item.VlRecarga.Value;
                                                cashCardOrderRequest.summary = "CashCard";
                                                cashCardOrderRequest.toAccount = item.IdAccount.ToString();

                                                CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                                //Envia o request para a web api da accounts pra realizar a recarga transferindo o dinheiro da conta matriz(Itaucred) para o beneficiário
                                                var response = HttpClientService.Instance.Transfer(config.AccountIdMatriz.ToString(), cashCardOrderRequest);
                                                cashCardOrderResponse.Success = response.Result.Success;
                                                cashCardOrderResponse = response.Result;
                                                cashCardOrderResponse.idArquivo = item.IdArquivo;
                                                cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                                //cashCardOrderResponse.Success = true;
                                                //cashCardOrderResponse.Result = "Teste";
                                                //cashCardOrderResponse.idArquivo = item.IdArquivo;
                                                //cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                                //Adiciona a resposta do post do pedido à uma lista de resultados
                                                lCashCardOrderResponse.Add(cashCardOrderResponse);

                                                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                            }
                                            //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                            else
                                            {
                                                CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                                cashCardOrderResponse.Success = false;
                                                cashCardOrderResponse.Result = "Cartao com saldo superior ou igual ao limite informado.";
                                                cashCardOrderResponse.idArquivo = item.IdArquivo;
                                                cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                                lCashCardOrderResponse.Add(cashCardOrderResponse);

                                                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                            }

                                        }
                                        //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                        else
                                        {
                                            CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                            cashCardOrderResponse.Success = false;
                                            cashCardOrderResponse.Result = "Situacao do cartao nao permitida. Recarga nao realizada.";
                                            cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            lCashCardOrderResponse.Add(cashCardOrderResponse);

                                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                        }

                                    }
                                });

                            //Verifica se foram processados todos os arquivos
                            var statusArquivo = (lCashCardOrderResponse.Where(x => x.Success).Count() == lCashCardOrderResponse.Count());

                            if (!statusArquivo)
                            {
                                Reprocess.Instance.ReprocessFileToRecharge(idArquivo);
                            }
                            else
                            {
                                //Atualiza as informações de recarga no arquivo, com as respectivas informações da lista de resultados, montada ao longo do precesso
                                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusArquivo(idArquivo, statusArquivo);

                                if (statusArquivo)
                                {
                                    string message = string.Format("Pedidos de recarga do arquivo {0} processados com sucesso.", idArquivo);

                                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauService.Recharge", DateTime.Now, message, false);
                                }
                                else
                                {
                                    string message = string.Format("Não foram processados todos os pedidos de recarga do arquivo {0}.", idArquivo);

                                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauService.Recharge", DateTime.Now, message, false);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = string.Format("Erro na recarga do arquivo {0}. ERRO: {1}.", idArquivo, ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauService.Recharge", DateTime.Now, message, true);
            }
        }
    }
}

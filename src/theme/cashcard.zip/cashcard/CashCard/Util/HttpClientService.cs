﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Request;
using CashCardDB.DataBase.Model.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CashCard.Util
{
	public class HttpClientService
	{
		private static HttpClientService oHttpClientService;

		public static HttpClientService Instance { get { oHttpClientService = oHttpClientService ?? new HttpClientService(); return oHttpClientService; } }

        /// <summary>
        /// Realiza a recarga através da webapi da Accounts. Método utilizado qdo o dinheiro será transferido desde a matriz.
        /// </summary>
        /// <param name="configuration">Configurações do cliente</param>
        /// <param name="cashCardOrderRequest">Request do pedido</param>
        /// <returns>Resposta do post de recarga</returns>
        public async Task<CashCardOrderResponse> Transfer(String accountIdMatriz, CashCardOrderRequest cashCardOrderRequest)
		{
			CashCardOrderResponse result = new CashCardOrderResponse();
				
			string urlAccounts = String.Format(ConfigurationManager.AppSettings["urlCardsAccounts"], accountIdMatriz);

			string json = "";

			try
			{
				using (HttpClient httpClient = new HttpClient())
				{

					HttpClient client = new HttpClient();
					
					client.DefaultRequestHeaders.Accept.Clear();
					client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

					json = JsonConvert.SerializeObject(cashCardOrderRequest);
					var buffer = Encoding.UTF8.GetBytes(json);
					var byteContent = new ByteArrayContent(buffer);
					byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

					var response = await client.PostAsync(urlAccounts, byteContent);

					if (response.StatusCode == System.Net.HttpStatusCode.OK)
					{
						result.Success = true;
					}
					else
					{
						result.Success = false;
					}

					result.Result = await response.Content.ReadAsStringAsync();
				}
			}
			catch (Exception ex)
			{
				result.Success = false;

				string message = string.Format("Erro ao realizar a recarga pela api urlCardsAccounts. ERRO: {0}. JSON: {1}", ex.Message, json);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("HttpClientService.Transfer", DateTime.Now, message, true);

			}

			return result;
		}

        public async Task<OrderResponse> Orders(OrderRequest orderRequest)
        {
            OrderResponse result = new OrderResponse();

            string urlOrders = ConfigurationManager.AppSettings["urlOrders"].ToString();

            string json = "";

            try
            {
                using (HttpClient httpClient = new HttpClient())
                {

                    HttpClient client = new HttpClient();

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    json = JsonConvert.SerializeObject(orderRequest);
                    var buffer = Encoding.UTF8.GetBytes(json);
                    var byteContent = new ByteArrayContent(buffer);
                    byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    var response = await client.PostAsync(urlOrders, byteContent);

                    if (response.StatusCode == System.Net.HttpStatusCode.Created)
                    {
                        result.Success = "true";
                    }
                    else
                    {
                        result.Success = "false";
                    }

                    result.Result = await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                result.Success = "false";

                string message = string.Format("Erro ao realizar o pedido pela api urlOrders. ERRO: {0}. JSON: {1}", ex.Message, json);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("HttpClientService.Orders", DateTime.Now, message, true);

            }

            return result;
        }

        /// <summary>
        /// Recupera o saldo pela webapi da accounts
        /// </summary>
        /// <param name="idAccount">Id da accounts</param>
        /// <returns>Saldo do cartão</returns>
        // public async Task<Decimal> GetSaldo(Int64 idAccount)
        //{
        //	Decimal saldo = 0;

        //	string urlAccountBalance = String.Format(ConfigurationManager.AppSettings["urlAccountBalance"], idAccount);

        //	try
        //	{
        //		using (var client = new HttpClient())
        //		{
        //			using (var response = await client.GetAsync(new Uri(urlAccountBalance), HttpCompletionOption.ResponseHeadersRead))
        //			{
        //				if (response.IsSuccessStatusCode)
        //				{
        //					JObject result = JsonConvert.DeserializeObject<JObject>(await response.Content.ReadAsStringAsync());

        //					if (!String.IsNullOrEmpty(result["balance"].ToString()))
        //					{
        //						saldo = Convert.ToDecimal(result["balance"].ToString());
        //					}
        //				}	
        //			}
        //		}
        //	}
        //	catch (Exception ex)
        //	{

        //		string message = string.Format("Erro ao consultar saldo pela api urlAccountBalance. ERRO: {0}.", ex.Message);

        //		CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("HttpClientService.GetSaldo", DateTime.Now, message, true);
        //	}

        //	return saldo;
        //}
    }
}

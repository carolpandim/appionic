update webstore..tbl_order set cd_new_order_context = null where cd_order=53051691
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 124427809
update webstore..tbl_order set cd_new_order_context = 631838 where cd_order = 53051882
update webstore..tbl_order_item set cd_new_context_order_item_id = 1098311 where cd_order_items = 124428275
update Orders..[CardItem] set CardId = 4677369, TruncatedNumber = '511623******9071' where Id = 631838
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4677369,631838,73629,'511623******9071',0)
update webstore..tbl_order set cd_new_order_context = null where cd_order=22552570
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 57999952
update webstore..tbl_order set cd_new_order_context = 24773 where cd_order = 62358622
update webstore..tbl_order_item set cd_new_context_order_item_id = 129032 where cd_order_items = 145274155
update Orders..[CardItem] set CardId = 5365553, TruncatedNumber = '511623******9926' where Id = 24773
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5365553,24773,73622,'511623******9926',0)
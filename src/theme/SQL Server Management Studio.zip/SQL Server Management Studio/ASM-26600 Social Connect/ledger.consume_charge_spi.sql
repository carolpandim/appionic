SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [ledger].[consume_charge_spi]
  @account_id bigint,
  @tchannel varchar(50),
  @date_ref datetime2,
  @transaction_ref bigint,
  @amount money,
  @properties varchar(4000) = NULL,
  @summary varchar(4000) = NULL,
  @peer_account_id bigint = NULL,
  @ledger_logs_parent_id bigint = NULL,
  @idempotency_key VARCHAR(70) = NULL,
  @return_value varchar(2) = '00' OUTPUT
  AS
  DECLARE @id bigint
  DECLARE @Erro int
  DECLARE @ErrorMsg varchar
  DECLARE @tchannel_id int
  DECLARE @allow_provision_debit bit
  DECLARE @date_ref_balance datetime
  DECLARE @Now datetime
  DECLARE @balance money
  DECLARE @limit_days int = NULL
  DECLARE @limit_value money  = NULL
  DECLARE @limit_date_started_to_use datetime  = NULL
  DECLARE @limit_id int
  DECLARE @social_connect_account_id AS BIGINT
  DECLARE @lock MONEY
  
  SET NOCOUNT ON

  SET @return_value = '00'

  IF NULLIF(@transaction_ref, '') IS NULL
    BEGIN
      SET @return_value = '12'
      SELECT 0 AS id, @return_value as response_code
      RETURN 12
    END

  IF @amount IS NULL OR @amount < '0.00'
    BEGIN
      SET @return_value = '10'
    SELECT 0 AS id, @return_value as response_code
    RETURN 10  
  END

  SELECT @date_ref_balance = ab.date_ref, @tchannel_id = tc.id, @allow_provision_debit = tc.allow_provision_debit, @limit_id = a.account_limit_id, @social_connect_account_id = a.social_connect_account_id
  FROM [ledger].[accounts] a (NOLOCK)
  INNER JOIN [ledger].[profile_allowed_transactions] pat (NOLOCK) ON pat.profile_id=a.profile_id
  INNER JOIN [ledger].[transaction_channels] tc (NOLOCK) ON tc.id=pat.tchannel_id
  INNER JOIN [ledger].[account_balances] ab (NOLOCK) ON ab.account_id=a.id
  WHERE tc.identifier=@tchannel
    AND a.id=@account_id
 
  IF @limit_id IS NOT NULL
      SELECT @limit_days = al.days, @limit_value = al.value, @limit_date_started_to_use = al.started_to_use
      FROM [ledger].[account_limits] al (NOLOCK) 
      WHERE al.id = @limit_id
 
  IF @date_ref_balance IS NULL
      BEGIN
      SET @return_value = '20'
      SELECT 0 AS id, @return_value as response_code
      RETURN 20
    END
  SET @Now = GETDATE()
  IF @date_ref IS NULL OR @date_ref < DATEADD(s, -1, @Now)
      SET @date_ref = @Now
  IF @date_ref > @Now AND @allow_provision_debit=0
      SET @date_ref = @Now                       

  BEGIN TRAN
 
    BEGIN TRY
	
		SET @lock = (SELECT TOP 1 id FROM [ledger].[ledger_logs] (HOLDLOCK) WHERE [entry_type] = 'D' AND [account_id] = @account_id order by 1 desc)
		SET @balance = 0

		IF @date_ref_balance <= GETDATE()
			SET @balance = ISNULL((SELECT SUM([amount]) FROM [ledger].[ledger_logs] WHERE [account_id] = @account_id),0)

		IF @limit_value IS NOT NULL
			SET @balance = @balance + @limit_value
		
	 
	   --TODO: Só chamar se for necessario. Dentro dela retirar o UPDLOCK e ROWLOCK e deixar sem hint
	   IF @social_connect_account_id IS NOT NULL AND @balance < @amount 
	   BEGIN

		   EXEC [ledger].[transfer_social_connect] 	@social_connect_account_id,
													@account_id,
													@amount,
                                                    @properties,
													@date_ref_balance,
													@transaction_ref,
													@Now,
													@balance OUT
	   END
														
		IF @balance < @amount
		  BEGIN
			ROLLBACK
			SET @return_value = '15'
			SELECT 0 AS id, @return_value as response_code
			RETURN 15
		END      
    
        INSERT INTO [ledger].[ledger_logs]
               ([account_id], [date_ref], [entry_type], [tchannel_id], [transaction_ref], [amount]    , [properties], [summary], [created_at], [peer_account_id], [ledger_logs_parent_id], [idempotency_key])
        VALUES (@account_id , @date_ref , 'D'         , @tchannel_id , @transaction_ref , @amount * -1,  @properties,  @summary , @Now , @peer_account_id , @ledger_logs_parent_id, @idempotency_key)
    
		SET @id = SCOPE_IDENTITY()
		
		SET @balance = @balance - @amount
		
		IF @balance < 0 AND @limit_date_started_to_use IS NULL
			UPDATE ledger.account_limits SET started_to_use = GETDATE() WHERE id = @limit_id
		
    END TRY
    BEGIN CATCH
	
	  ROLLBACK

      IF ERROR_NUMBER() = 2601
        BEGIN
          SELECT id, '00' as response_code FROM [ledger].[ledger_logs] (NOLOCK) WHERE idempotency_key = @idempotency_key AND account_id = @account_id AND entry_type = 'D'
          RETURN 0;
        END
	  ELSE
		BEGIN

			RAISERROR(N'Fail consuming charge. Rowcount:%d Error: %d', 0, 1, @@ROWCOUNT, @@ERROR)
			SET @return_value = '30'
			SELECT 0 AS id, @return_value as response_code
			RETURN @return_value

		END
	  
    END CATCH 
    
  COMMIT TRAN

  -- RETORNA O ID DO DEBITO NA LEDGER_LOGS
  SELECT @id AS id, @return_value as response_code


GO

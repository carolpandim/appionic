SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [ledger].[transfer_social_connect]
	@social_connect_account_id AS BIGINT,
	@account_id AS BIGINT,
	@amount MONEY,
    @properties varchar(4000) = NULL,
	@date_ref_balance DATETIME,
	@transaction_ref BIGINT,
	@Now DATETIME,
	@balance MONEY OUT
AS
    
    DECLARE @lock MONEY

    IF @balance < @amount 
    BEGIN	

		IF @social_connect_account_id is not null	
		BEGIN
		
			SET @lock = (SELECT TOP 1 id FROM [ledger].[ledger_logs] (HOLDLOCK) WHERE [entry_type] = 'D' AND [account_id] = @social_connect_account_id order by 1 desc)

	    	DECLARE @peer_amount AS MONEY = @balance - @amount
			  
			IF @date_ref_balance <= GETDATE()
	    		SET @balance = @balance + ISNULL((SELECT SUM([amount]) FROM [ledger].[ledger_logs] WHERE [account_id] = @social_connect_account_id),0)					
	    	
	    	IF @balance >= @amount
			BEGIN
							
				DECLARE @tchannel_debit_id AS BIGINT
				SELECT @tchannel_debit_id = id FROM [ledger].[transaction_channels] WITH (NOLOCK) WHERE identifier = 'social_connect_debit'
				
				INSERT INTO [ledger].[ledger_logs] ([account_id], [date_ref], [entry_type], [tchannel_id], [transaction_ref],[amount], [properties], [summary], [created_at], [peer_account_id], [ledger_logs_parent_id])
				VALUES (@social_connect_account_id,GETDATE(),'D',@tchannel_debit_id, @transaction_ref , @peer_amount,  @properties,  'Débito Social Connect' , @Now , @account_id , NULL)
					    
			    
				SET @peer_amount = @peer_amount *-1
				EXEC [ledger].[add_charge_spi]  @account_id,
												@tchannel = 'social_connect_credit',
												@date_ref = @Now,
												@transaction_ref = @transaction_ref,
												@amount	= @peer_amount,
												@summary  = 'Crédito Social Connect',
												@properties  = NULL,
												@peer_account_id  = @social_connect_account_id,
												@ledger_logs_parent_id = NULL,
												@idempotency_key  = NULL,
												@response_code = NULL
				
				SET @balance = 0
												
				IF @date_ref_balance <= GETDATE()
					SET @balance = ISNULL((SELECT SUM([amount]) FROM [ledger].[ledger_logs] WHERE [account_id] = @account_id),0)												
				
			END 
    	END
	END


GO

--mercadopago
--545377
--itau
--522157
--Paypaxx
--530551

declare @bin varchar(6) = '530551'
declare @dataInicial datetime = '2018-06-01'
declare @dataFinal datetime = '2018-06-30'
 
 
--Autorizadas
select DATEPART(MONTH, t.DataAutorizacao) Mes, DATEPART(DAY, t.DataAutorizacao) Dia, DATEPART(HOUR, t.DataAutorizacao) Hora, count(*) Qtde from transacoes t
inner join vw_cartoes c on c.CodigoCartao = t.CodigoCartao
where left(c.NumeroTruncado,6) collate SQL_Latin1_General_CP1_CI_AS = @bin
and cast(t.DataAutorizacao as date) between @dataInicial and @dataFinal and t.Situacao in ('A', 'L') and t.CodigoTipoTransacao in (2, 13)
group by DATEPART(MONTH, t.DataAutorizacao), DATEPART(DAY, t.DataAutorizacao), DATEPART(HOUR, t.DataAutorizacao)
order by DATEPART(MONTH, t.DataAutorizacao), DATEPART(DAY, t.DataAutorizacao), DATEPART(HOUR, t.DataAutorizacao) asc
 
--N�o Autorizadas
select DATEPART(MONTH, t.DataAutorizacao) Mes, DATEPART(DAY, t.DataAutorizacao) Dia, DATEPART(HOUR, t.DataAutorizacao) Hora, count(*) Qtde from transacoes t
inner join vw_cartoes c on c.CodigoCartao = t.CodigoCartao
where left(c.NumeroTruncado,6) = @bin
and cast(t.DataAutorizacao as date) between @dataInicial and @dataFinal and t.Situacao not in ('A', 'L') and t.CodigoTipoTransacao in (2, 13)
group by DATEPART(MONTH, t.DataAutorizacao), DATEPART(DAY, t.DataAutorizacao), DATEPART(HOUR, t.DataAutorizacao)
order by DATEPART(MONTH, t.DataAutorizacao), DATEPART(DAY, t.DataAutorizacao), DATEPART(HOUR, t.DataAutorizacao) asc
 
 
--Standins
select DATEPART(MONTH, aut_t.DATA_HORA_GMT) Mes, DATEPART(DAY, aut_t.DATA_HORA_GMT) Dia, DATEPART(HOUR, aut_t.DATA_HORA_GMT) Hora, count(*) Qtde from autorizadora..transacoes aut_t
where TIPO_TRANSACAO = 'transacao_credito_avs'
and cast(aut_t.DATA_HORA_GMT as date) between @dataInicial and @dataFinal
and exists (select 1 from vw_cartoes where left(NumeroTruncado,6) = @bin and CodigoCartao = aut_t.CODIGO_CARTAO)
group by DATEPART(MONTH, aut_t.DATA_HORA_GMT), DATEPART(DAY, aut_t.DATA_HORA_GMT), DATEPART(HOUR, aut_t.DATA_HORA_GMT)
order by DATEPART(MONTH, aut_t.DATA_HORA_GMT), DATEPART(DAY, aut_t.DATA_HORA_GMT), DATEPART(HOUR, aut_t.DATA_HORA_GMT) asc
 

-- using processadora
declare @cd_order int  =54643500
declare @cartao int  =4272770
declare @cd_order_reissue int = 145056
declare @cd_order_item int = 128035946
declare @CodigoContaTitular int 
declare @via int
select
	@CodigoContaTitular=CodigoContaTitular  
from 
	processadora.dbo.Cartoes 
where 
	CodigoCartao=@cartao 
select
	@via=MAX(Via)
from
	processadora.dbo.cartoes where
	codigocontaTitular=(@CodigoContaTitular) 
	if	exists(select 0 from processadora.dbo.Cartoes 
				where CodigoContaTitular=@CodigoContaTitular 
					and Via=@via 
					and Via >1
					and CodigoSituacao=2)
		begin

		select 
			'insert into tbl_order_item_card (cd_order_items,cd_card,fl_active,ds_truncated_card) values ('+ Cast(@cd_order_item as varchar) + ','+CAST(CodigoCartao as varchar)+',1,'+''''+CAST(NumeroTruncado as varchar)+''')' as 'InsertWebStore'
			 , CodigoCartao, NumeroTruncado, CodigoModalidade, Via, CodigoSituacao 
			 from
				processadora.dbo.Cartoes 
			where
				CodigoContaTitular=@CodigoContaTitular 
				and Via=@via 
				and Via >1
				and CodigoSituacao=2
		end
	else
begin
select
	'delete from Webstore.dbo.tbl_order_reissue where cd_order_reissue='+Cast(@cd_order_reissue as varchar) 'Delete WebStore',
	'insert into tbl_order_tracking select cd_order, null, 5, GETDATE(), ''Reemiss�o com erro. Gerar nova reemiss�o'', 3, 0, 0, null from tbl_order where cd_order='+cast(@cd_order as varchar) 'WebStore',
	'update tbl_order set cd_status = 5, dt_updated = GETDATE() where cd_order='+cast(@cd_order as varchar) 'WebStore' 
end

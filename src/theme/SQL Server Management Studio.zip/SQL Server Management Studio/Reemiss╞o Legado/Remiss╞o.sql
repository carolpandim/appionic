--- using webstore
select
oi.nr_document, s.ds_status, o.cd_status, o.dt_sale, ori.cd_generated_order  'cd_order',
ori.cd_origin_card CardIdOrigem, ori.cd_order_reissue 'cd_order_reissue',
ori.cd_generated_order_item 'cd_order_item',
	iif(oic.cd_card is null,'Item  sem cart�o','OK')
		as
			'Status',
			'update tbl_order_item set cd_status = 17 where cd_order =' + cast(ori.cd_generated_order	as varchar)+'and cd_order_item_base is null',
			'insert into tbl_order_tracking select cd_order, null, 17, GETDATE(), ''Corre��o de problema na reemiss�o'', 3, 0, 0, null from tbl_order where cd_order =' + cast(ori.cd_generated_order as varchar), 
			'update tbl_order set cd_status = 17, dt_updated = GETDATE() where cd_order='+cast(ori.cd_generated_order as varchar)
from
	Webstore.dbo.tbl_order_reissue ori 
	inner join  Webstore.dbo.tbl_order o 
		on o.cd_order = ori.cd_generated_order 
	inner join  Webstore.dbo.tbl_status s 
		on s.cd_status = o.cd_status 
	inner join Webstore.dbo.tbl_customer c 
		on c.cd_customer = o.cd_customer 
	inner join Webstore.dbo.tbl_order_item oi 
		on o.cd_order = oi.cd_order 
		   and oi.cd_order_item_base is null
	left join Webstore.dbo.tbl_order_item_card oic 
		on oi.cd_order_items = oic.cd_order_items 
where o.cd_order = 54643500


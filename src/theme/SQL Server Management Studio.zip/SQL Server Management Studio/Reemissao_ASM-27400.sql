update webstore..tbl_order set cd_new_order_context = null where cd_order=34230455
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 82905498
update webstore..tbl_order set cd_new_order_context = 74933 where cd_order = 46956575
update webstore..tbl_order_item set cd_new_context_order_item_id = 318966 where cd_order_items = 110513059
update Orders..[CardItem] set CardId = 4206665, TruncatedNumber = '545377******2042' where Id = 74933
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4206665,74933,484650,'545377******2042',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=50788427
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 119074740
update webstore..tbl_order set cd_new_order_context = 539009 where cd_order = 54336593
update webstore..tbl_order_item set cd_new_context_order_item_id = 890339 where cd_order_items = 127329942
update Orders..[CardItem] set CardId = 4763260, TruncatedNumber = '545377******4175' where Id = 539009
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4763260,539009,1162292,'545377******4175',0)

update Orders..Reissue set Status = 67 where Id=27180

update Orders..Reissue set Status = 67 where Id=30611

update Orders..Reissue set Status = 67 where Id=27801

update Orders..Reissue set Status = 67 where Id=27799

update Orders..Reissue set Status = 67 where Id=26235

update Orders..Reissue set Status = 67 where Id=32413

update Orders..Reissue set Status = 67 where Id=33886

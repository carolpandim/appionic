--pedidos na order com status invalido
select 
*
from [order] o
	inner join AccountItem a
		on o.id = a.Order_Id
where 
	o.accountid  =1327817 
--	and o.status =12 
order by 1 desc


--pedidos pendentes
select sum(Totals_CreditAmount) from [order] where accountid  =1327817
and Status =6

select * from [order] where accountid  =1327817
and Status =6

select top 10 * 
from [Orders]..[Order] (nolock) as l1 inner join [Orders]..[OrderPayment] (nolock) as l2 on l1.Id = l2.OrderId
inner join [Orders]..[Payment] (nolock) as l3 on l2.OrderId = l2.OrderId
where l1.AccountId = 1327817
order by l2.OrderId desc

select top 10
       o.id, s.Serialized
from 
       [order] o
             inner join   payment p
                    on o.id = p.OrderId
                           inner join SerializedOrder s
                                  on o.id = s.OrderId
                                        inner join AccountItem a
                                               on a.Order_Id = o.Id
                                               and a.AccountId = o.AccountId
where 
p.type = 4
and o.status = 13
and o.Totals_CreditCount = 1
and o.Totals_CardCount = 0
and o.AccountId = 1327817
order by 1 desc
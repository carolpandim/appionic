select * from vw_cartoes where codigocartao in (2414357)
select * from vw_cartoes where codigocontatitular = 4956582
select * from contassaldos where codigocontatitular = 4956582
select * from LogRecargaPedidosCartoes where codigocartao = 2414357 -- antigo contexto
select * from Transacoes where codigocartao = 2665163 order by 1 desc
select * from TiposTransacoes
select * from SituacoesCartoes
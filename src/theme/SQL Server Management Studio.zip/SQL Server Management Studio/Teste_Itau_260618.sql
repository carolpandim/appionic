--select ledger.get_account_balance_fn (835561)
select 
	c.CodigoCartao,
	c.NumeroTruncado,
    c.CodigoSituacao,
    acc.id as Account,
    doc.document as CPF,
    ledger.get_account_balance_fn (acc.id ) as Saldo
from
    cartoes c
    inner join ContasSaldos saldos  (nolock) on c.CodigoContaTitular = saldos.CodigoContaTitular
    inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
    inner join accounts.Person per  (nolock) on acc.person_id = per.id
    inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id										
where c.CodigoCartao in (
4815524
)

select * from ledger.ledger_logs where account_id = 1424763 order by 1 desc

select * from ledger.ledger_logs where transaction_ref = 988152 order by 1 desc

select * from cashinout.transfers where to_account = 1424763 order by 1 desc

{"debitId":17022933,"creditId":17022935}
update Orders..Reissue set Status = 67 where Id=27808

update webstore..tbl_order set cd_new_order_context = null where cd_order=43999540
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 104136311
update webstore..tbl_order set cd_new_order_context = 395345 where cd_order = 46985484
update webstore..tbl_order_item set cd_new_context_order_item_id = 625802 where cd_order_items = 110584146
update Orders..[CardItem] set CardId = 4209027, TruncatedNumber = '545377******1715' where Id = 395345
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4209027,395345,891643,'545377******1715',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=32350809
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 78859469
update webstore..tbl_order set cd_new_order_context = 56755 where cd_order = 50388566
update webstore..tbl_order_item set cd_new_context_order_item_id = 283883 where cd_order_items = 118199992
update Orders..[CardItem] set CardId = 4428528, TruncatedNumber = '545377******2637' where Id = 56755
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4428528,56755,415152,'545377******2637',0)

update Orders..Reissue set Status = 67 where Id=27800

update Orders..Reissue set Status = 67 where Id=34471
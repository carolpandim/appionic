insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64616242,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64616242
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64616418,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64616418
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64619457,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64619457
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64624187,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64624187
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64624575,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64624575
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64625079,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64625079
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64625083,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64625083
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64625562,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64625562
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64625785,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64625785
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64626278,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64626278
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64626996,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64626996
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64627659,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64627659
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64627740,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64627740
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64628502,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64628502
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64628703,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64628703
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64628913,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64628913
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64629549,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64629549
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64630096,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64630096
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64630423,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64630423
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64630424,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64630424
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64630760,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64630760
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64631099,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64631099
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64631822,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64631822
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64632040,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64632040
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64632271,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64632271
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64633572,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64633572
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64634523,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64634523
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64634526,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64634526
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64634919,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64634919
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64635130,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64635130
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64636092,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64636092
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64636094,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64636094
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64636810,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64636810
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64636811,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64636811
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64637887,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64637887
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64639722,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64639722
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64640622,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64640622
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64641108,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64641108
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64642895,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64642895
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64643203,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64643203
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64644241,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64644241
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64644626,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64644626
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64645942,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64645942
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64645943,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64645943
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64646012,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64646012
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64646080,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64646080
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64647196,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64647196
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64647367,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64647367
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64647873,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64647873
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64649561,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64649561
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64650307,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64650307
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64650704,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64650704
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64651118,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64651118
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64652180,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64652180
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64704661,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64704661
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64705227,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64705227
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64705813,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64705813
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64706991,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64706991
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64707280,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64707280
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64707281,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64707281
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64711211,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64711211
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64714595,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64714595
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64715625,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64715625
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64718794,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64718794
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64719522,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64719522
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64719884,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64719884
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64720513,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64720513
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64722527,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64722527
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64722528,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64722528
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64722777,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64722777
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64723382,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64723382
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64723867,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64723867
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724034,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64724034
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724226,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64724226
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724375,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64724375
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724977,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64724977
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64725799,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64725799
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64725938,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64725938
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64726218,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64726218
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727643,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64727643
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727709,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64727709
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727710,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64727710
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727860,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64727860
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64728768,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64728768
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64729092,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64729092
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64729320,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64729320
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64729694,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64729694
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64731682,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64731682
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64734287,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64734287
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64737533,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64737533
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64737621,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64737621
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64739603,3,getdate(),'Aprova��o Autom�tica [ASM-26844]',3,201,1)	
update tbl_order set cd_status = 3 where cd_order = 64739603
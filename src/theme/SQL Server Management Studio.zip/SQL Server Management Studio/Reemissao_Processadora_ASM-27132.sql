Use processadora
Go

exec AlteraSituacaoCartao 5535163, 2, 'Erro de processamento',null
exec AlteraSituacaoCartao 5125735, 2, 'Erro de processamento',null
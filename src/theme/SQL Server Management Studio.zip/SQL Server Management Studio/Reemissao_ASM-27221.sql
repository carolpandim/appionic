update Orders..Reissue set Status = 67 where Id = 28725
update Orders..Reissue set Status = 67 where Id = 30055

update webstore..tbl_order set cd_new_order_context = null where cd_order=26285623
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 65944772
update webstore..tbl_order set cd_new_order_context = 31695 where cd_order = 29109581
update webstore..tbl_order_item set cd_new_context_order_item_id = 179514 where cd_order_items = 71953151
update Orders..[CardItem] set CardId = 3019223, TruncatedNumber = '545377******0114' where Id = 31695
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3019223,31695,157947,'545377******0114',0)

update Orders..Reissue set Status = 67 where Id = 30763

update Orders..Reissue set Status = 67 where Id = 28660

update Orders..Reissue set Status = 67 where Id = 28400

update Orders..Reissue set Status = 67 where Id = 28725

update Orders..Reissue set Status = 67 where Id = 30977

update Orders..Reissue set Status = 67 where Id = 31496

update Orders..Reissue set Status = 67 where Id = 27785

update webstore..tbl_order set cd_new_order_context = null where cd_order=48257021
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 113425948
update webstore..tbl_order set cd_new_order_context = 474571 where cd_order = 51044283
update webstore..tbl_order_item set cd_new_context_order_item_id = 768803 where cd_order_items = 119690299
update Orders..[CardItem] set CardId = 4482187, TruncatedNumber = '545377******2703' where Id = 474571
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4482187,474571,1052288,'545377******2703',0)

update Orders..Reissue set Status = 67 where Id=28660

update webstore..tbl_order set cd_new_order_context = null where cd_order=43927074
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 103979813
update webstore..tbl_order set cd_new_order_context = 394190 where cd_order = 51559500
update webstore..tbl_order_item set cd_new_context_order_item_id = 623931 where cd_order_items = 120961711
update Orders..[CardItem] set CardId = 4538115, TruncatedNumber = '545377******2889' where Id = 394190
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4538115,394190,890322,'545377******2889',0)

update Orders..Reissue set Status = 67 where Id=28725

update webstore..tbl_order set cd_new_order_context = null where cd_order=43793226
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 103684647
update webstore..tbl_order set cd_new_order_context = 391150 where cd_order = 47463882
update webstore..tbl_order_item set cd_new_context_order_item_id = 618352 where cd_order_items = 111599249
update Orders..[CardItem] set CardId = 4227733, TruncatedNumber = '545377******1861' where Id = 391150
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4227733,391150,886131,'545377******1861',0)

update Orders..Reissue set Status = 67 where Id=33682

update webstore..tbl_order set cd_new_order_context = null where cd_order=39107914
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 93440242
update webstore..tbl_order set cd_new_order_context = 336977 where cd_order = 52429037
update webstore..tbl_order_item set cd_new_context_order_item_id = 476888 where cd_order_items = 122954479
update Orders..[CardItem] set CardId = 4603090, TruncatedNumber = '545377******3484' where Id = 336977
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4603090,336977,721079,'545377******3484',0)

update Orders..Reissue set Status = 67 where Id=27769

update Orders..Reissue set Status = 67 where Id=30055

update webstore..tbl_order set cd_new_order_context = null where cd_order=45951958
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 108381945
update webstore..tbl_order set cd_new_order_context = 424827 where cd_order = 51250253
update webstore..tbl_order_item set cd_new_context_order_item_id = 686750 where cd_order_items = 120237516
update Orders..[CardItem] set CardId = 4511133, TruncatedNumber = '545377******2864' where Id = 424827
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4511133,424827,942391,'545377******2864',0)

update Orders..Reissue set Status = 67 where Id=28010

update Orders..Reissue set Status = 67 where Id=30340

update webstore..tbl_order set cd_new_order_context = null where cd_order=35565333
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 85766145
update webstore..tbl_order set cd_new_order_context = 96298 where cd_order = 39121731
update webstore..tbl_order_item set cd_new_context_order_item_id = 354785 where cd_order_items = 93469471
update Orders..[CardItem] set CardId = 3735219, TruncatedNumber = '545377******0806' where Id = 96298
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3735219,96298,559574,'545377******0806',0)

update Orders..Reissue set Status = 67 where Id=27766

update webstore..tbl_order set cd_new_order_context = null where cd_order=34489251
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 83457984
update webstore..tbl_order set cd_new_order_context = 80191 where cd_order = 48237448
update webstore..tbl_order_item set cd_new_context_order_item_id = 327019 where cd_order_items = 113378345
update Orders..[CardItem] set CardId = 4295772, TruncatedNumber = '545377******1957' where Id = 80191
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4295772,80191,509537,'545377******1957',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=30737032
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 75458795
update webstore..tbl_order set cd_new_order_context = 40444 where cd_order = 51131682
update webstore..tbl_order_item set cd_new_context_order_item_id = 247834 where cd_order_items = 119947198
update Orders..[CardItem] set CardId = 4498590, TruncatedNumber = '545377******2813' where Id = 40444
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4498590,40444,275568,'545377******2813',0)






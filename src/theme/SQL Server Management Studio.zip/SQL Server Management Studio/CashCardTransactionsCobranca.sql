select sum(amount) from ledger.ledger_logs where account_id=1327817 and (summary = 'CashCard')


select * 
from ledger.ledger_logs 
where account_id=1327817 
and (summary = 'CashCard') 
and date_ref >= '20180716 00:00:00.000' and date_ref < '20180717 00:00:00.000'

select * from ledger.accounts where id = 1327817

--Limite da conta cabify
select * from ledger.account_limits where id = 53


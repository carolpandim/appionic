select * from Contract where Contracting_Name like '%Cabify%'







select a.*
from 
       [Orders]..[order] o
       left join [Orders]..AccountItem a on o.id = a.Order_Id
       left join [Orders]..CardItem c on c.AccountItem_Id = a.id
where 1=1
and cardid =  4430240

1327817


select 
	c.*
from 
       [Orders]..[order] o
       left join [Orders]..AccountItem a on o.id = a.Order_Id
       left join [Orders]..CardItem c on c.AccountItem_Id = a.id
where 
	Contract_Id in(
		select id from Contract where Contracting_Document = '24866506000146'
	) 
	and o.AccountId = 1327817
	and c.CardId is not null
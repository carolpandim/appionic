Use Webstore
Go

update Orders..Reissue set Status = 67 where Id=28409
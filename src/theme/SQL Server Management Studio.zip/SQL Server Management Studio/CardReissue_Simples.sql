select 	st1.cd_order,
		st1.cd_new_order_context,
		st2.cd_new_context_order_item_id,
		st1.cd_channel,
		st2.cd_order_items,
		st3.cd_card,
		st3.ds_truncated_card,
		st2.nr_document
		,st4.id as OrderId,
		st5.Id as CardItemId,
		st5.CardId,
		st5.TruncatedNumber
from tbl_order st1 (nolock)
inner join tbl_order_item st2 (nolock) on st1.cd_order = st2.cd_order and st2.cd_order_item_base is null
inner join tbl_order_item_card st3 (nolock) on st3.cd_order_items = st2.cd_order_items
inner join Orders..[order] st4 (nolock) on st4.Id = st1.cd_new_order_context
inner join Orders..[CardItem] st5 (nolock) on st4.Id = st5.Order_Id 
inner join [Orders]..AccountItem st6 (nolock) on st4.id = st6.Order_Id
where 		st1.cd_order in 
(
53578320 
)



--update tbl_order_item_card set cd_card=4786161, ds_truncated_card='511623******9706'
--where cd_orderitem_card=2223550

select * from  tbl_order where cd_new_order_context=942736

select * from tbl_order_reissue st1 (nolock) where st1.cd_origin_card = 583472

select * from tbl_channel where cd_channel=13069

select 	st1.Id as OrderId,
		st2.Id as CardItemId,
		st2.CardId,
		st2.TruncatedNumber,
		*
from Orders..[order] st1 (nolock) 
inner join Orders..[CardItem] st2 (nolock) on st2.Order_Id = st1.Id
where st2.CardId = 4705453
--where st1.Id = 942736


select top 1 * from Orders..Reissue st1 (nolock) where st1.OriginalCard_Id = 4705453  order by 1 desc
select * from Orders..ReissueReason
select * from Orders..StatusHistory where Order_Id = 877661


--L�
select * from Orders..Card s where s.Id = 4705453
select * from tbl_order_item as s where s.cd_order_items=125577300
select * from  tbl_order where cd_order=53578320 --se veio da nova plataforma, o campo cd_new_order_context tem que estar preenchido, sen�o foi reemitido no legado



select 
	ca.cd_card,
	ca.ds_truncated_card,
	item.cd_order_items,
	item.cd_new_context_order_item_id,
	o.cd_order,
	o.cd_new_order_context
from 
	tbl_order_item_card as ca
	inner join tbl_order_item as item on ca.cd_order_items = item.cd_order_items
	inner join tbl_order as o on item.cd_order = o.cd_order
where 
	ca.cd_card=4705453


--Encontrar todos os pedidos do cpf no canal
select 
	t1.cd_order,
	t1.cd_order_items,
	t2.cd_order,
	t2.cd_new_order_context,
	t1.cd_new_context_order_item_id
from 
	tbl_order_item t1
	inner join tbl_order t2 on t1.cd_order = t2.cd_order and t2.cd_new_order_context is not null and t2.cd_channel = 7106
where
	t1.cd_order_item_base is null
	and t1.nr_document = '38638470835'
order by
	t2.cd_order desc
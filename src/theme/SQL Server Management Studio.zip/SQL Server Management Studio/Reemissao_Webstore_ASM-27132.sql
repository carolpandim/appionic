Use Webstore
Go

declare 
@cd_order int,
@cd_order_items int,
@cd_card int,
@truncated varchar(128);
�
set @cd_order=64714775
set @cd_order_items =150520441
set @cd_card =5535163
set @truncated ='538740******0220'
�
insert into tbl_order_item_card (cd_order_items,cd_card,fl_active,ds_truncated_card) values (@cd_order_items, @cd_card, 1, @truncated)
�
update tbl_order_item set cd_status = 17 where cd_order = @cd_order and cd_order_item_base is null

insert into tbl_order_tracking select cd_order, null, 17, GETDATE(), 'Corre��o de problema na reemiss�o', 3, 83, 0, null from tbl_order where cd_order =@cd_order

update tbl_order set cd_status = 17, dt_updated = GETDATE() where cd_order =@cd_order

set @cd_order=58973144
set @cd_order_items =137832569
set @cd_card =5125735
set @truncated ='538740******0191'

insert into tbl_order_item_card (cd_order_items,cd_card,fl_active,ds_truncated_card) values (@cd_order_items, @cd_card, 1, @truncated)
�
update tbl_order_item set cd_status = 17 where cd_order = @cd_order and cd_order_item_base is null

insert into tbl_order_tracking select cd_order, null, 17, GETDATE(), 'Corre��o de problema na reemiss�o', 3, 83, 0, null from tbl_order where cd_order =@cd_order

update tbl_order set cd_status = 17, dt_updated = GETDATE() where cd_order =@cd_order
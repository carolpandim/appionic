declare @codigocontatitular int
declare @codigomodalidade int
declare @codigocartao int
declare @codigocanal int
declare @codigoProduto int

select @codigocartao = codigocartao, @codigocontatitular = CodigoContaTitular, @codigomodalidade = CodigoModalidade from cartoes where codigocartao in (5023601)

select @codigocanal = CodigoCanal from cartoes_valepresente where codigocartao = @codigocartao

select @codigoProduto = codigoProduto from modalidades where CodigoModalidade = @codigomodalidade

select top 1 Valor from (
select ctp.Valor,p.CodigoParametro, 4 as Peso from ProdutosParametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
where CodigoProduto = @codigoProduto and p.CodigoParametro = 26
union all
select ctp.Valor, p.CodigoParametro, 3 as Peso from ModalidadesParametros ctp (nolock) inner join  parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
where CodigoModalidade = @codigomodalidade and p.CodigoParametro = 26
union all
select ctp.Valor, p.CodigoParametro, 2 as Peso from canaisparametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
where codigocanal = @codigocanal and p.CodigoParametro = 26
union all
select ctp.Valor, p.CodigoParametro, 1 as Peso from contastitularesparametros ctp (nolock) inner join parametros p (nolock) on ctp.codigoparametro = p.codigoparametro
where codigocontatitular = @codigocontatitular and p.CodigoParametro = 26
) as t order by Peso ASC
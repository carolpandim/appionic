update webstore..tbl_order set cd_new_order_context = null where cd_order=49292768
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 115715810
update webstore..tbl_order set cd_new_order_context = 495723 where cd_order = 53578320
update webstore..tbl_order_item set cd_new_context_order_item_id = 811626 where cd_order_items = 125577300
update Orders..[CardItem] set CardId = 4705453, TruncatedNumber = '545377******3759' where Id = 495723
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4705453,495723,1086749,'545377******3759',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=39469709
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 94246520
update webstore..tbl_order set cd_new_order_context = 341031 where cd_order = 45833010
update webstore..tbl_order_item set cd_new_context_order_item_id = 490558 where cd_order_items = 108125702
update Orders..[CardItem] set CardId = 4136601, TruncatedNumber = '545377******1800' where Id = 341031
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4136601,341031,731985,'545377******1800',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=50966059
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 119495244
update webstore..tbl_order set cd_new_order_context = 545840 where cd_order = 51053243
update webstore..tbl_order_item set cd_new_context_order_item_id = 899934 where cd_order_items = 119715998
update Orders..[CardItem] set CardId = 4483410, TruncatedNumber = '545377******2814' where Id = 545840
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4483410,545840,1172754,'545377******2814',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=47615382
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 111953812
update webstore..tbl_order set cd_new_order_context = 450889 where cd_order = 52450229
update webstore..tbl_order_item set cd_new_context_order_item_id = 728149 where cd_order_items = 123007557
update Orders..[CardItem] set CardId = 4606590, TruncatedNumber = '545377******3522' where Id = 450889
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4606590,450889,1009290,'545377******3522',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=45441409
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 107279517
update webstore..tbl_order set cd_new_order_context = 397165 where cd_order = 56058004
update webstore..tbl_order_item set cd_new_context_order_item_id = 630890 where cd_order_items = 131177708
update Orders..[CardItem] set CardId = 5015878, TruncatedNumber = '511623******0010' where Id = 397165
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5015878,397165,897145,'511623******0010',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=47901993
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 112653079
update webstore..tbl_order set cd_new_order_context = 468043 where cd_order = 50866021
update webstore..tbl_order_item set cd_new_context_order_item_id = 756958 where cd_order_items = 119260249
update Orders..[CardItem] set CardId = 4465017, TruncatedNumber = '545377******2949' where Id = 468043
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4465017,468043,1031451,'545377******2949',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=42441130
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 100829926
update webstore..tbl_order set cd_new_order_context = 371523 where cd_order = 50932292
update webstore..tbl_order_item set cd_new_context_order_item_id = 588383 where cd_order_items = 119407272
update Orders..[CardItem] set CardId = 4469545, TruncatedNumber = '545377******2671' where Id = 371523
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4469545,371523,812609,'545377******2671',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=48338279
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 113595558
update webstore..tbl_order set cd_new_order_context = 475257 where cd_order = 50937421
update webstore..tbl_order_item set cd_new_context_order_item_id = 769558 where cd_order_items = 119419109
update Orders..[CardItem] set CardId = 4469803, TruncatedNumber = '545377******2767' where Id = 475257
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4469803,475257,1053007,'545377******2767',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=41986206
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 99801462
update webstore..tbl_order set cd_new_order_context = 366998 where cd_order = 52215682
update webstore..tbl_order_item set cd_new_context_order_item_id = 576237 where cd_order_items = 122456689
update Orders..[CardItem] set CardId = 4585389, TruncatedNumber = '545377******3322' where Id = 366998
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4585389,366998,806012,'545377******3322',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=34484822
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 83445301
update webstore..tbl_order set cd_new_order_context = 79233 where cd_order = 40856437
update webstore..tbl_order_item set cd_new_context_order_item_id = 326061 where cd_order_items = 97244376
update Orders..[CardItem] set CardId = 3806508, TruncatedNumber = '545377******1043' where Id = 79233
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3806508,79233,508588,'545377******1043',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=47713515
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 112171910
update webstore..tbl_order set cd_new_order_context = 455166 where cd_order = 51025532
update webstore..tbl_order_item set cd_new_context_order_item_id = 733874 where cd_order_items = 119646805
update Orders..[CardItem] set CardId = 4480821, TruncatedNumber = '545377******2711' where Id = 455166
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4480821,455166,1014037,'545377******2711',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=50413900
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 118262382
update webstore..tbl_order set cd_new_order_context = 529531 where cd_order = 51903222
update webstore..tbl_order_item set cd_new_context_order_item_id = 872869 where cd_order_items = 121795092
update Orders..[CardItem] set CardId = 5052114, TruncatedNumber = '545377******5796' where Id = 529531
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5052114,529531,1140046,'545377******5796',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=49891982
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 117069938
update webstore..tbl_order set cd_new_order_context = 511377 where cd_order = 55694791
update webstore..tbl_order_item set cd_new_context_order_item_id = 845027 where cd_order_items = 130325041
update Orders..[CardItem] set CardId = 4836158, TruncatedNumber = '545377******4545' where Id = 511377
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4836158,511377,1114279,'545377******4545',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=35276769
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 85140888
update webstore..tbl_order set cd_new_order_context = 93095 where cd_order = 49031292
update webstore..tbl_order_item set cd_new_context_order_item_id = 345903 where cd_order_items = 115164298
update Orders..[CardItem] set CardId = 4344508, TruncatedNumber = '545377******2270' where Id = 93095
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4344508,93095,523213,'545377******2270',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=28860353
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 71438860
update webstore..tbl_order set cd_new_order_context = 35387 where cd_order = 37600666
update webstore..tbl_order_item set cd_new_context_order_item_id = 216847 where cd_order_items = 90129494
update Orders..[CardItem] set CardId = 3619370, TruncatedNumber = '545377******0711' where Id = 35387
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3619370,35387,200812,'545377******0711',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=34641215
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 83794347
update webstore..tbl_order set cd_new_order_context = 84508 where cd_order = 49788114
update webstore..tbl_order_item set cd_new_context_order_item_id = 333660 where cd_order_items = 116837396
update Orders..[CardItem] set CardId = 4386491, TruncatedNumber = '545377******2435' where Id = 84508
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4386491,84508,513977,'545377******2435',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=48803195
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 114672073
update webstore..tbl_order set cd_new_order_context = 485255 where cd_order = 50937238
update webstore..tbl_order_item set cd_new_context_order_item_id = 796001 where cd_order_items = 119418633
update Orders..[CardItem] set CardId = 4469801, TruncatedNumber = '545377******2995' where Id = 485255
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4469801,485255,1074186,'545377******2995',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=44011350
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 104162397
update webstore..tbl_order set cd_new_order_context = 395653 where cd_order = 47743488
update webstore..tbl_order_item set cd_new_context_order_item_id = 626370 where cd_order_items = 112254104
update Orders..[CardItem] set CardId = 4250864, TruncatedNumber = '545377******2264' where Id = 395653
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4250864,395653,891931,'545377******2264',0)

update webstore..tbl_order set cd_new_order_context = null where cd_order=15047357
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 41989280
update webstore..tbl_order set cd_new_order_context = 21354 where cd_order = 26290798
update webstore..tbl_order_item set cd_new_context_order_item_id = 20524 where cd_order_items = 65955945
update Orders..[CardItem] set CardId = 2899957, TruncatedNumber = '511623******5413' where Id = 21354
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (2899957,21354,6879,'511623******5413',0)





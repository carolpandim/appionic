select 
    c.CodigoCartao,
    c.CodigoSituacao,
    acc.id as account,
    doc.document,
    ledger.get_account_balance_fn (acc.id ) as saldo
from
    cartoes c
    inner join ContasSaldos saldos  (nolock) on c.CodigoContaTitular = saldos.CodigoContaTitular
    inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
    inner join accounts.Person per  (nolock) on acc.person_id = per.id
    inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id										
where c.CodigoCartao in (3849323)
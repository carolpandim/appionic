select 
	car.CodigoCartao,
	car.CodigoSituacao,
	acc.id as account,
	doc.document,
	acc.product_id	,
	acc.contract_id,
	acc.account_parent_id,
	car.DataSituacaoConfeccao
from cartoes car (nolock)
	inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
	inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
	inner join accounts.Person per  (nolock) on acc.person_id = per.id
	inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
where 
	doc.document in ('25122561893','21964193893')
-- and car.CodigoExterno like '%combust�vel%' --and  acc.account_parent_id = 2631
--and car.Situacao = 'A'
--and acc.product_id =3
order by car.CodigoCartao asc

select
	t1.CodigoCartao,
	CodigoSituacao,
	acc.id as account,
	t2.document,
	acc.product_id	,
	acc.contract_id,
	acc.account_parent_id,
	*
from 
	cartoes t1
	inner join ContasSaldos saldos  (nolock) on t1.CodigoContaTitular = saldos.CodigoContaTitular
	inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
	inner join (

  select
	Max(car.codigoCartao) as cardId,
	doc.document
	from cartoes car (nolock)
	inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
	inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
	inner join accounts.Person per  (nolock) on acc.person_id = per.id
	inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
	where 
		--car.codigoCartao in (4430241,4430240)
		doc.document in ('25122561893','21964193893')
		--and acc.product_id=3
		 --car.CodigoExterno like '%Despesas%'
		--and  acc.account_parent_id = 2631 
		--and car.Situacao = 'A'
	group by doc.document
) as t2 on t1.CodigoCartao = t2.cardId 


select
	Max(car.codigoCartao) as cardId,
	doc.document
	from cartoes car (nolock)
	inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
	inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
	inner join accounts.Person per  (nolock) on acc.person_id = per.id
	inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
	where 
		--car.codigoCartao in (4430241,4430240)
		doc.document in ('21964193893','25122561893') 
		--and acc.product_id=3
		 --car.CodigoExterno like '%Despesas%'
		--and  acc.account_parent_id = 2631 
		--and car.Situacao = 'A'
	group by doc.document

--select distinct car.CodigoExterno ,acc.product_id	
--from cartoes car (nolock)
--	inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
--	inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
--		inner join accounts.Person per  (nolock) on acc.person_id = per.id
--	inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
----where  acc.account_parent_id = 2631 --doc.document in ('21964193893','25122561893') and 
--where car.CodigoExterno like '%Despesas%'
----order by car.CodigoExterno asc

--select * from ledger.accounts acc
--inner join accounts.Person per on acc.person_id = per.id
--inner join accounts.Document doc on doc.person_id =  per.id
--where doc.document in ('21964193893','25122561893') and doc.type = 'CPF' and product_id = 3



select * from SituacoesCartoes


select
*
from cartoes car (nolock)
inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
inner join accounts.Person per  (nolock) on acc.person_id = per.id
inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
where car.COdigoCartao = 4791329



select
*
from cartoes car (nolock)
inner join ContasSaldos saldos  (nolock) on car.CodigoContaTitular = saldos.CodigoContaTitular
inner join ledger.accounts acc  (nolock) on acc.id = saldos.CodigoContaSaldo
inner join accounts.Person per  (nolock) on acc.person_id = per.id
inner join accounts.Document doc  (nolock) on per.identifier_document_id = doc.id
where   account_parent_id = 1327817 and document = '04394791936' 



select * from 
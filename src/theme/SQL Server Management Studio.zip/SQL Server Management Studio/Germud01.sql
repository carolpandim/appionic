update webstore..tbl_order set cd_new_order_context = null where cd_order = 37955016;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 90913271;
update webstore..tbl_order set cd_new_order_context = 323852 where cd_order = 41392192;
update webstore..tbl_order_item set cd_new_context_order_item_id = 440991 where cd_order_items = 98534689;
update Orders..[CardItem] set CardId =3854472, TruncatedNumber = '545377******1038' where Id = 378882;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3854472,323852,632705,'545377******1038',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 37799961;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 90567940;
update webstore..tbl_order set cd_new_order_context = 319213 where cd_order = 43226475;
update webstore..tbl_order_item set cd_new_context_order_item_id = 433370 where cd_order_items = 102490140;
update Orders..[CardItem] set CardId =3965199, TruncatedNumber = '545377******1158' where Id = 371557;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3965199,319213,625838,'545377******1158',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 31243517;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 76522035;
update webstore..tbl_order set cd_new_order_context = 43772 where cd_order = 43251554;
update webstore..tbl_order_item set cd_new_context_order_item_id = 254162 where cd_order_items = 102545596;
update Orders..[CardItem] set CardId =3966383, TruncatedNumber = '545377******1245' where Id = 230901;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (3966383,43772,300766,'545377******1245',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 39406887;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 94120466;
update webstore..tbl_order set cd_new_order_context = 340780 where cd_order = 43375292;
update webstore..tbl_order_item set cd_new_context_order_item_id = 490307 where cd_order_items = 102808382;
update Orders..[CardItem] set CardId =4000453, TruncatedNumber = '545377******1210' where Id = 422794;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4000453,340780,731771,'545377******1210',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 43341942;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 102734402;
update webstore..tbl_order set cd_new_order_context = 380374 where cd_order = 45619540;
update webstore..tbl_order_item set cd_new_context_order_item_id = 606607 where cd_order_items = 107670172;
update Orders..[CardItem] set CardId =4129269, TruncatedNumber = '545377******1662' where Id = 525108;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4129269,380374,847445,'545377******1662',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 38936489;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 93048380;
update webstore..tbl_order set cd_new_order_context = 334839 where cd_order = 48128180;
update webstore..tbl_order_item set cd_new_context_order_item_id = 469721 where cd_order_items = 113122512;
update Orders..[CardItem] set CardId =4276995, TruncatedNumber = '545377******2036' where Id = 403939;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4276995,334839,695292,'545377******2036',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 38276811;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 91637351;
update webstore..tbl_order set cd_new_order_context = 327669 where cd_order = 48571568;
update webstore..tbl_order_item set cd_new_context_order_item_id = 451345 where cd_order_items = 114148636;
update Orders..[CardItem] set CardId =4318237, TruncatedNumber = '545377******2233' where Id = 387577;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4318237,327669,673409,'545377******2233',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 47702133;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 112141239;
update webstore..tbl_order set cd_new_order_context = 453607 where cd_order = 48984935;
update webstore..tbl_order_item set cd_new_context_order_item_id = 732167 where cd_order_items = 115062311;
update Orders..[CardItem] set CardId =4342938, TruncatedNumber = '545377******2251' where Id = 630850;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4342938,453607,1012253,'545377******2251',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 34731620;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 83984486;
update webstore..tbl_order set cd_new_order_context = 85545 where cd_order = 49128626;
update webstore..tbl_order_item set cd_new_context_order_item_id = 335198 where cd_order_items = 115367566;
update Orders..[CardItem] set CardId =4348322, TruncatedNumber = '545377******2692' where Id = 300577;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4348322,85545,515100,'545377******2692',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 46249277;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 108991915;
update webstore..tbl_order set cd_new_order_context = 427801 where cd_order = 49694456;
update webstore..tbl_order_item set cd_new_context_order_item_id = 690384 where cd_order_items = 116643432;
update Orders..[CardItem] set CardId =4382809, TruncatedNumber = '545377******2424' where Id = 595647;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4382809,427801,945494,'545377******2424',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 43933677;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 103993642;
update webstore..tbl_order set cd_new_order_context = 394283 where cd_order = 50398335;
update webstore..tbl_order_item set cd_new_context_order_item_id = 624034 where cd_order_items = 118224707;
update Orders..[CardItem] set CardId =4429461, TruncatedNumber = '545377******2803' where Id = 538776;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4429461,394283,890411,'545377******2803',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 47383164;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 111426492;
update webstore..tbl_order set cd_new_order_context = 445505 where cd_order = 50594753;
update webstore..tbl_order_item set cd_new_context_order_item_id = 720131 where cd_order_items = 118659281;
update Orders..[CardItem] set CardId =4451498, TruncatedNumber = '545377******2680' where Id = 620870;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4451498,445505,1001801,'545377******2680',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 44135507;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 104445723;
update webstore..tbl_order set cd_new_order_context = 397761 where cd_order = 50618360;
update webstore..tbl_order_item set cd_new_context_order_item_id = 632801 where cd_order_items = 118724311;
update Orders..[CardItem] set CardId =4454554, TruncatedNumber = '545377******2640' where Id = 546018;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4454554,397761,899541,'545377******2640',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 35246361;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 85078287;
update webstore..tbl_order set cd_new_order_context = 92800 where cd_order = 51465772;
update webstore..tbl_order_item set cd_new_context_order_item_id = 345601 where cd_order_items = 120708071;
update Orders..[CardItem] set CardId =4523286, TruncatedNumber = '545377******2939' where Id = 309429;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4523286,92800,522941,'545377******2939',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 50496633;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 118439233;
update webstore..tbl_order set cd_new_order_context = 531592 where cd_order = 51466053;
update webstore..tbl_order_item set cd_new_context_order_item_id = 876797 where cd_order_items = 120709398;
update Orders..[CardItem] set CardId =4523408, TruncatedNumber = '545377******3081' where Id = 759742;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4523408,531592,1152314,'545377******3081',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 46488019;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 109492393;
update webstore..tbl_order set cd_new_order_context = 430964 where cd_order = 51466075;
update webstore..tbl_order_item set cd_new_context_order_item_id = 696186 where cd_order_items = 120709487;
update Orders..[CardItem] set CardId =4523442, TruncatedNumber = '545377******2903' where Id = 600402;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4523442,430964,971056,'545377******2903',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 47394315;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 111451431;
update webstore..tbl_order set cd_new_order_context = 445839 where cd_order = 51555832;
update webstore..tbl_order_item set cd_new_context_order_item_id = 720464 where cd_order_items = 120947989;
update Orders..[CardItem] set CardId =4536738, TruncatedNumber = '545377******3098' where Id = 621203;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4536738,445839,1002127,'545377******3098',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 47126129;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 110874253;
update webstore..tbl_order set cd_new_order_context = 441667 where cd_order = 51758643;
update webstore..tbl_order_item set cd_new_context_order_item_id = 713919 where cd_order_items = 121452218;
update Orders..[CardItem] set CardId =4561399, TruncatedNumber = '545377******3188' where Id = 615282;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4561399,441667,996282,'545377******3188',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 45660529;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 107759165;
update webstore..tbl_order set cd_new_order_context = 420476 where cd_order = 51780987;
update webstore..tbl_order_item set cd_new_context_order_item_id = 679087 where cd_order_items = 121512629;
update Orders..[CardItem] set CardId =4564542, TruncatedNumber = '545377******3311' where Id = 586280;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4564542,420476,936579,'545377******3311',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 40281503;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 96009568;
update webstore..tbl_order set cd_new_order_context = 351013 where cd_order = 52429476;
update webstore..tbl_order_item set cd_new_context_order_item_id = 514375 where cd_order_items = 122955469;
update Orders..[CardItem] set CardId =4603224, TruncatedNumber = '545377******3260' where Id = 444128;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4603224,351013,752995,'545377******3260',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 44916695;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 106136789;
update webstore..tbl_order set cd_new_order_context = 409408 where cd_order = 58508770;
update webstore..tbl_order_item set cd_new_context_order_item_id = 656609 where cd_order_items = 136811414;
update Orders..[CardItem] set CardId =5081961, TruncatedNumber = '545377******6574' where Id = 567335;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5081961,409408,917851,'545377******6574',0);

update webstore..tbl_order set cd_new_order_context = null where cd_order = 52463860;
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 123037673;
update webstore..tbl_order set cd_new_order_context = 613619 where cd_order = 59205957;
update webstore..tbl_order_item set cd_new_context_order_item_id = 1043557 where cd_order_items = 138345002;
update Orders..[CardItem] set CardId =5139627, TruncatedNumber = '545377******6049' where Id = 913979;
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5139627,613619,1273893,'545377******6049',0);
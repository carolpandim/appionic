insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008439,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008436,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008279,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008277,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008274,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008273,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008272,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008271,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008187,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008186,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008185,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008184,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008183,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008182,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007980,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007978,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007976,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007975,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007947,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007945,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64971330,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64895348,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64895149,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64870024,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64704661,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64652180,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64651118,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008956,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008955,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008870,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008869,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008850,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008822,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008821,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008768,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008767,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008766,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008705,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009865,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009907,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009909,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009910,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009911,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009913,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009914,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009940,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009941,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009942,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009943,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009944,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009945,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009946,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009947,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009948,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009965,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009978,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009981,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009983,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009984,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009985,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009987,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009988,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010002,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010006,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010007,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010008,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010009,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010010,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010011,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010012,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008704,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008510,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008509,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008508,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008365,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008363,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008362,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008361,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008115,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008114,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008113,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008053,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008052,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007893,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65007598,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65006018,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65004262,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65001482,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65001000,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64998095,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64993603,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64990602,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64987787,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64986798,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64983732,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64975818,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64975006,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64969962,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64969838,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64966696,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64914642,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64907806,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64905298,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64902979,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64900444,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64889354,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64887018,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64883936,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64882945,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64882863,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64880554,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64880367,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64879476,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64878696,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64876271,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64873070,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64868713,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64868659,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64867987,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64867846,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64866552,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64865908,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64865082,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64864096,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64862958,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64860241,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64860240,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64859543,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64856664,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64851676,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64786302,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64784595,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64783849,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64783691,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64781898,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64779001,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64778136,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64777929,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64777038,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64775786,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64774924,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64773328,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64771507,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64771172,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64770845,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64769945,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64769523,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64769293,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64768938,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64766362,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64766041,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64765131,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64763432,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64762926,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64762408,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64762210,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64761576,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64761273,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64760585,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64760185,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64760094,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64758432,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64757361,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64755546,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64754636,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64754564,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64754248,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64752573,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64751097,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64750777,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64750102,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64750017,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64749861,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64749702,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64749556,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64748519,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64745928,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64742667,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64741991,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64740988,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64740490,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64739603,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64737621,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64737533,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64734287,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64731682,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64729694,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64728768,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727860,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727710,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727709,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64727643,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64726218,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64725938,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64725799,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724977,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724375,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64724034,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64723867,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64723382,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64722777,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64722527,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64720513,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64719884,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64718794,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64715625,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64714595,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64711211,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64707281,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64707280,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64706991,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(64705813,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009398,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009344,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009343,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009341,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009284,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009283,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009282,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009281,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009223,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009222,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009221,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009220,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009219,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009194,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009193,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009115,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009114,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009112,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009048,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009046,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009045,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009044,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009043,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009041,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009040,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009039,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009038,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008994,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009833,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009834,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008953,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008951,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008950,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008948,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008947,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008946,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008908,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008907,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65008904,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009835,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009846,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009850,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009851,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009852,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009862,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009863,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009864,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009399,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009400,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009401,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009455,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009530,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009531,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009532,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009533,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009564,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009595,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009596,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009597,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009598,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009599,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009600,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009601,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009602,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009603,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009604,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009605,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009618,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009632,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009689,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009690,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009691,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009819,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65009832,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010014,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010016,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65010123,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65013046,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65013078,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65013103,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65013116,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65039575,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65040358,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65041101,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65042598,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65042808,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65044502,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65044989,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65046080,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)
insert into tbl_order_tracking(cd_order,cd_status_order,dt_order_history,ds_remarks,cd_order_history_type,cd_affiliate,fl_show_customer) values(65046890,3,getdate(),'Aprova��o Autom�tica [ASM-26860]',3,201,1)

update tbl_order set cd_status = 3 where cd_order = 65008439
update tbl_order set cd_status = 3 where cd_order = 65008436
update tbl_order set cd_status = 3 where cd_order = 65008279
update tbl_order set cd_status = 3 where cd_order = 65008277
update tbl_order set cd_status = 3 where cd_order = 65008274
update tbl_order set cd_status = 3 where cd_order = 65008273
update tbl_order set cd_status = 3 where cd_order = 65008272
update tbl_order set cd_status = 3 where cd_order = 65008271
update tbl_order set cd_status = 3 where cd_order = 65008187
update tbl_order set cd_status = 3 where cd_order = 65008186
update tbl_order set cd_status = 3 where cd_order = 65008185
update tbl_order set cd_status = 3 where cd_order = 65008184
update tbl_order set cd_status = 3 where cd_order = 65008183
update tbl_order set cd_status = 3 where cd_order = 65008182
update tbl_order set cd_status = 3 where cd_order = 65007980
update tbl_order set cd_status = 3 where cd_order = 65007978
update tbl_order set cd_status = 3 where cd_order = 65007976
update tbl_order set cd_status = 3 where cd_order = 65007975
update tbl_order set cd_status = 3 where cd_order = 65007947
update tbl_order set cd_status = 3 where cd_order = 65007945
update tbl_order set cd_status = 3 where cd_order = 64971330
update tbl_order set cd_status = 3 where cd_order = 64895348
update tbl_order set cd_status = 3 where cd_order = 64895149
update tbl_order set cd_status = 3 where cd_order = 64870024
update tbl_order set cd_status = 3 where cd_order = 64704661
update tbl_order set cd_status = 3 where cd_order = 64652180
update tbl_order set cd_status = 3 where cd_order = 64651118
update tbl_order set cd_status = 3 where cd_order = 65008956
update tbl_order set cd_status = 3 where cd_order = 65008955
update tbl_order set cd_status = 3 where cd_order = 65008870
update tbl_order set cd_status = 3 where cd_order = 65008869
update tbl_order set cd_status = 3 where cd_order = 65008850
update tbl_order set cd_status = 3 where cd_order = 65008822
update tbl_order set cd_status = 3 where cd_order = 65008821
update tbl_order set cd_status = 3 where cd_order = 65008768
update tbl_order set cd_status = 3 where cd_order = 65008767
update tbl_order set cd_status = 3 where cd_order = 65008766
update tbl_order set cd_status = 3 where cd_order = 65008705
update tbl_order set cd_status = 3 where cd_order = 65009865
update tbl_order set cd_status = 3 where cd_order = 65009907
update tbl_order set cd_status = 3 where cd_order = 65009909
update tbl_order set cd_status = 3 where cd_order = 65009910
update tbl_order set cd_status = 3 where cd_order = 65009911
update tbl_order set cd_status = 3 where cd_order = 65009913
update tbl_order set cd_status = 3 where cd_order = 65009914
update tbl_order set cd_status = 3 where cd_order = 65009940
update tbl_order set cd_status = 3 where cd_order = 65009941
update tbl_order set cd_status = 3 where cd_order = 65009942
update tbl_order set cd_status = 3 where cd_order = 65009943
update tbl_order set cd_status = 3 where cd_order = 65009944
update tbl_order set cd_status = 3 where cd_order = 65009945
update tbl_order set cd_status = 3 where cd_order = 65009946
update tbl_order set cd_status = 3 where cd_order = 65009947
update tbl_order set cd_status = 3 where cd_order = 65009948
update tbl_order set cd_status = 3 where cd_order = 65009965
update tbl_order set cd_status = 3 where cd_order = 65009978
update tbl_order set cd_status = 3 where cd_order = 65009981
update tbl_order set cd_status = 3 where cd_order = 65009983
update tbl_order set cd_status = 3 where cd_order = 65009984
update tbl_order set cd_status = 3 where cd_order = 65009985
update tbl_order set cd_status = 3 where cd_order = 65009987
update tbl_order set cd_status = 3 where cd_order = 65009988
update tbl_order set cd_status = 3 where cd_order = 65010002
update tbl_order set cd_status = 3 where cd_order = 65010006
update tbl_order set cd_status = 3 where cd_order = 65010007
update tbl_order set cd_status = 3 where cd_order = 65010008
update tbl_order set cd_status = 3 where cd_order = 65010009
update tbl_order set cd_status = 3 where cd_order = 65010010
update tbl_order set cd_status = 3 where cd_order = 65010011
update tbl_order set cd_status = 3 where cd_order = 65010012
update tbl_order set cd_status = 3 where cd_order = 65008704
update tbl_order set cd_status = 3 where cd_order = 65008510
update tbl_order set cd_status = 3 where cd_order = 65008509
update tbl_order set cd_status = 3 where cd_order = 65008508
update tbl_order set cd_status = 3 where cd_order = 65008365
update tbl_order set cd_status = 3 where cd_order = 65008363
update tbl_order set cd_status = 3 where cd_order = 65008362
update tbl_order set cd_status = 3 where cd_order = 65008361
update tbl_order set cd_status = 3 where cd_order = 65008115
update tbl_order set cd_status = 3 where cd_order = 65008114
update tbl_order set cd_status = 3 where cd_order = 65008113
update tbl_order set cd_status = 3 where cd_order = 65008053
update tbl_order set cd_status = 3 where cd_order = 65008052
update tbl_order set cd_status = 3 where cd_order = 65007893
update tbl_order set cd_status = 3 where cd_order = 65007598
update tbl_order set cd_status = 3 where cd_order = 65006018
update tbl_order set cd_status = 3 where cd_order = 65004262
update tbl_order set cd_status = 3 where cd_order = 65001482
update tbl_order set cd_status = 3 where cd_order = 65001000
update tbl_order set cd_status = 3 where cd_order = 64998095
update tbl_order set cd_status = 3 where cd_order = 64993603
update tbl_order set cd_status = 3 where cd_order = 64990602
update tbl_order set cd_status = 3 where cd_order = 64987787
update tbl_order set cd_status = 3 where cd_order = 64986798
update tbl_order set cd_status = 3 where cd_order = 64983732
update tbl_order set cd_status = 3 where cd_order = 64975818
update tbl_order set cd_status = 3 where cd_order = 64975006
update tbl_order set cd_status = 3 where cd_order = 64969962
update tbl_order set cd_status = 3 where cd_order = 64969838
update tbl_order set cd_status = 3 where cd_order = 64966696
update tbl_order set cd_status = 3 where cd_order = 64914642
update tbl_order set cd_status = 3 where cd_order = 64907806
update tbl_order set cd_status = 3 where cd_order = 64905298
update tbl_order set cd_status = 3 where cd_order = 64902979
update tbl_order set cd_status = 3 where cd_order = 64900444
update tbl_order set cd_status = 3 where cd_order = 64889354
update tbl_order set cd_status = 3 where cd_order = 64887018
update tbl_order set cd_status = 3 where cd_order = 64883936
update tbl_order set cd_status = 3 where cd_order = 64882945
update tbl_order set cd_status = 3 where cd_order = 64882863
update tbl_order set cd_status = 3 where cd_order = 64880554
update tbl_order set cd_status = 3 where cd_order = 64880367
update tbl_order set cd_status = 3 where cd_order = 64879476
update tbl_order set cd_status = 3 where cd_order = 64878696
update tbl_order set cd_status = 3 where cd_order = 64876271
update tbl_order set cd_status = 3 where cd_order = 64873070
update tbl_order set cd_status = 3 where cd_order = 64868713
update tbl_order set cd_status = 3 where cd_order = 64868659
update tbl_order set cd_status = 3 where cd_order = 64867987
update tbl_order set cd_status = 3 where cd_order = 64867846
update tbl_order set cd_status = 3 where cd_order = 64866552
update tbl_order set cd_status = 3 where cd_order = 64865908
update tbl_order set cd_status = 3 where cd_order = 64865082
update tbl_order set cd_status = 3 where cd_order = 64864096
update tbl_order set cd_status = 3 where cd_order = 64862958
update tbl_order set cd_status = 3 where cd_order = 64860241
update tbl_order set cd_status = 3 where cd_order = 64860240
update tbl_order set cd_status = 3 where cd_order = 64859543
update tbl_order set cd_status = 3 where cd_order = 64856664
update tbl_order set cd_status = 3 where cd_order = 64851676
update tbl_order set cd_status = 3 where cd_order = 64786302
update tbl_order set cd_status = 3 where cd_order = 64784595
update tbl_order set cd_status = 3 where cd_order = 64783849
update tbl_order set cd_status = 3 where cd_order = 64783691
update tbl_order set cd_status = 3 where cd_order = 64781898
update tbl_order set cd_status = 3 where cd_order = 64779001
update tbl_order set cd_status = 3 where cd_order = 64778136
update tbl_order set cd_status = 3 where cd_order = 64777929
update tbl_order set cd_status = 3 where cd_order = 64777038
update tbl_order set cd_status = 3 where cd_order = 64775786
update tbl_order set cd_status = 3 where cd_order = 64774924
update tbl_order set cd_status = 3 where cd_order = 64773328
update tbl_order set cd_status = 3 where cd_order = 64771507
update tbl_order set cd_status = 3 where cd_order = 64771172
update tbl_order set cd_status = 3 where cd_order = 64770845
update tbl_order set cd_status = 3 where cd_order = 64769945
update tbl_order set cd_status = 3 where cd_order = 64769523
update tbl_order set cd_status = 3 where cd_order = 64769293
update tbl_order set cd_status = 3 where cd_order = 64768938
update tbl_order set cd_status = 3 where cd_order = 64766362
update tbl_order set cd_status = 3 where cd_order = 64766041
update tbl_order set cd_status = 3 where cd_order = 64765131
update tbl_order set cd_status = 3 where cd_order = 64763432
update tbl_order set cd_status = 3 where cd_order = 64762926
update tbl_order set cd_status = 3 where cd_order = 64762408
update tbl_order set cd_status = 3 where cd_order = 64762210
update tbl_order set cd_status = 3 where cd_order = 64761576
update tbl_order set cd_status = 3 where cd_order = 64761273
update tbl_order set cd_status = 3 where cd_order = 64760585
update tbl_order set cd_status = 3 where cd_order = 64760185
update tbl_order set cd_status = 3 where cd_order = 64760094
update tbl_order set cd_status = 3 where cd_order = 64758432
update tbl_order set cd_status = 3 where cd_order = 64757361
update tbl_order set cd_status = 3 where cd_order = 64755546
update tbl_order set cd_status = 3 where cd_order = 64754636
update tbl_order set cd_status = 3 where cd_order = 64754564
update tbl_order set cd_status = 3 where cd_order = 64754248
update tbl_order set cd_status = 3 where cd_order = 64752573
update tbl_order set cd_status = 3 where cd_order = 64751097
update tbl_order set cd_status = 3 where cd_order = 64750777
update tbl_order set cd_status = 3 where cd_order = 64750102
update tbl_order set cd_status = 3 where cd_order = 64750017
update tbl_order set cd_status = 3 where cd_order = 64749861
update tbl_order set cd_status = 3 where cd_order = 64749702
update tbl_order set cd_status = 3 where cd_order = 64749556
update tbl_order set cd_status = 3 where cd_order = 64748519
update tbl_order set cd_status = 3 where cd_order = 64745928
update tbl_order set cd_status = 3 where cd_order = 64742667
update tbl_order set cd_status = 3 where cd_order = 64741991
update tbl_order set cd_status = 3 where cd_order = 64740988
update tbl_order set cd_status = 3 where cd_order = 64740490
update tbl_order set cd_status = 3 where cd_order = 64739603
update tbl_order set cd_status = 3 where cd_order = 64737621
update tbl_order set cd_status = 3 where cd_order = 64737533
update tbl_order set cd_status = 3 where cd_order = 64734287
update tbl_order set cd_status = 3 where cd_order = 64731682
update tbl_order set cd_status = 3 where cd_order = 64729694
update tbl_order set cd_status = 3 where cd_order = 64728768
update tbl_order set cd_status = 3 where cd_order = 64727860
update tbl_order set cd_status = 3 where cd_order = 64727710
update tbl_order set cd_status = 3 where cd_order = 64727709
update tbl_order set cd_status = 3 where cd_order = 64727643
update tbl_order set cd_status = 3 where cd_order = 64726218
update tbl_order set cd_status = 3 where cd_order = 64725938
update tbl_order set cd_status = 3 where cd_order = 64725799
update tbl_order set cd_status = 3 where cd_order = 64724977
update tbl_order set cd_status = 3 where cd_order = 64724375
update tbl_order set cd_status = 3 where cd_order = 64724034
update tbl_order set cd_status = 3 where cd_order = 64723867
update tbl_order set cd_status = 3 where cd_order = 64723382
update tbl_order set cd_status = 3 where cd_order = 64722777
update tbl_order set cd_status = 3 where cd_order = 64722527
update tbl_order set cd_status = 3 where cd_order = 64720513
update tbl_order set cd_status = 3 where cd_order = 64719884
update tbl_order set cd_status = 3 where cd_order = 64718794
update tbl_order set cd_status = 3 where cd_order = 64715625
update tbl_order set cd_status = 3 where cd_order = 64714595
update tbl_order set cd_status = 3 where cd_order = 64711211
update tbl_order set cd_status = 3 where cd_order = 64707281
update tbl_order set cd_status = 3 where cd_order = 64707280
update tbl_order set cd_status = 3 where cd_order = 64706991
update tbl_order set cd_status = 3 where cd_order = 64705813
update tbl_order set cd_status = 3 where cd_order = 65009398
update tbl_order set cd_status = 3 where cd_order = 65009344
update tbl_order set cd_status = 3 where cd_order = 65009343
update tbl_order set cd_status = 3 where cd_order = 65009341
update tbl_order set cd_status = 3 where cd_order = 65009284
update tbl_order set cd_status = 3 where cd_order = 65009283
update tbl_order set cd_status = 3 where cd_order = 65009282
update tbl_order set cd_status = 3 where cd_order = 65009281
update tbl_order set cd_status = 3 where cd_order = 65009223
update tbl_order set cd_status = 3 where cd_order = 65009222
update tbl_order set cd_status = 3 where cd_order = 65009221
update tbl_order set cd_status = 3 where cd_order = 65009220
update tbl_order set cd_status = 3 where cd_order = 65009219
update tbl_order set cd_status = 3 where cd_order = 65009194
update tbl_order set cd_status = 3 where cd_order = 65009193
update tbl_order set cd_status = 3 where cd_order = 65009115
update tbl_order set cd_status = 3 where cd_order = 65009114
update tbl_order set cd_status = 3 where cd_order = 65009112
update tbl_order set cd_status = 3 where cd_order = 65009048
update tbl_order set cd_status = 3 where cd_order = 65009046
update tbl_order set cd_status = 3 where cd_order = 65009045
update tbl_order set cd_status = 3 where cd_order = 65009044
update tbl_order set cd_status = 3 where cd_order = 65009043
update tbl_order set cd_status = 3 where cd_order = 65009041
update tbl_order set cd_status = 3 where cd_order = 65009040
update tbl_order set cd_status = 3 where cd_order = 65009039
update tbl_order set cd_status = 3 where cd_order = 65009038
update tbl_order set cd_status = 3 where cd_order = 65008994
update tbl_order set cd_status = 3 where cd_order = 65009833
update tbl_order set cd_status = 3 where cd_order = 65009834
update tbl_order set cd_status = 3 where cd_order = 65008953
update tbl_order set cd_status = 3 where cd_order = 65008951
update tbl_order set cd_status = 3 where cd_order = 65008950
update tbl_order set cd_status = 3 where cd_order = 65008948
update tbl_order set cd_status = 3 where cd_order = 65008947
update tbl_order set cd_status = 3 where cd_order = 65008946
update tbl_order set cd_status = 3 where cd_order = 65008908
update tbl_order set cd_status = 3 where cd_order = 65008907
update tbl_order set cd_status = 3 where cd_order = 65008904
update tbl_order set cd_status = 3 where cd_order = 65009835
update tbl_order set cd_status = 3 where cd_order = 65009846
update tbl_order set cd_status = 3 where cd_order = 65009850
update tbl_order set cd_status = 3 where cd_order = 65009851
update tbl_order set cd_status = 3 where cd_order = 65009852
update tbl_order set cd_status = 3 where cd_order = 65009862
update tbl_order set cd_status = 3 where cd_order = 65009863
update tbl_order set cd_status = 3 where cd_order = 65009864
update tbl_order set cd_status = 3 where cd_order = 65009399
update tbl_order set cd_status = 3 where cd_order = 65009400
update tbl_order set cd_status = 3 where cd_order = 65009401
update tbl_order set cd_status = 3 where cd_order = 65009455
update tbl_order set cd_status = 3 where cd_order = 65009530
update tbl_order set cd_status = 3 where cd_order = 65009531
update tbl_order set cd_status = 3 where cd_order = 65009532
update tbl_order set cd_status = 3 where cd_order = 65009533
update tbl_order set cd_status = 3 where cd_order = 65009564
update tbl_order set cd_status = 3 where cd_order = 65009595
update tbl_order set cd_status = 3 where cd_order = 65009596
update tbl_order set cd_status = 3 where cd_order = 65009597
update tbl_order set cd_status = 3 where cd_order = 65009598
update tbl_order set cd_status = 3 where cd_order = 65009599
update tbl_order set cd_status = 3 where cd_order = 65009600
update tbl_order set cd_status = 3 where cd_order = 65009601
update tbl_order set cd_status = 3 where cd_order = 65009602
update tbl_order set cd_status = 3 where cd_order = 65009603
update tbl_order set cd_status = 3 where cd_order = 65009604
update tbl_order set cd_status = 3 where cd_order = 65009605
update tbl_order set cd_status = 3 where cd_order = 65009618
update tbl_order set cd_status = 3 where cd_order = 65009632
update tbl_order set cd_status = 3 where cd_order = 65009689
update tbl_order set cd_status = 3 where cd_order = 65009690
update tbl_order set cd_status = 3 where cd_order = 65009691
update tbl_order set cd_status = 3 where cd_order = 65009819
update tbl_order set cd_status = 3 where cd_order = 65009832
update tbl_order set cd_status = 3 where cd_order = 65010014
update tbl_order set cd_status = 3 where cd_order = 65010016
update tbl_order set cd_status = 3 where cd_order = 65010123
update tbl_order set cd_status = 3 where cd_order = 65013046
update tbl_order set cd_status = 3 where cd_order = 65013078
update tbl_order set cd_status = 3 where cd_order = 65013103
update tbl_order set cd_status = 3 where cd_order = 65013116
update tbl_order set cd_status = 3 where cd_order = 65039575
update tbl_order set cd_status = 3 where cd_order = 65040358
update tbl_order set cd_status = 3 where cd_order = 65041101
update tbl_order set cd_status = 3 where cd_order = 65042598
update tbl_order set cd_status = 3 where cd_order = 65042808
update tbl_order set cd_status = 3 where cd_order = 65044502
update tbl_order set cd_status = 3 where cd_order = 65044989
update tbl_order set cd_status = 3 where cd_order = 65046080
update tbl_order set cd_status = 3 where cd_order = 65046890
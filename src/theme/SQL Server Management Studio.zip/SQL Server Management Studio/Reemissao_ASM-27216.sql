update webstore..tbl_order set cd_new_order_context = null where cd_order=41686819
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 99184963
update webstore..tbl_order set cd_new_order_context = 365243 where cd_order = 48930352
update webstore..tbl_order_item set cd_new_context_order_item_id = 573586 where cd_order_items = 114946702
update Orders..[CardItem] set CardId = 4340060, TruncatedNumber = '545377******2296' where Id = 365243
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4340060,365243,803072,'545377******2296',0)
update webstore..tbl_order set cd_new_order_context = null where cd_order=37031740
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 88920606
update webstore..tbl_order set cd_new_order_context = 307718 where cd_order = 50841797
update webstore..tbl_order_item set cd_new_context_order_item_id = 396464 where cd_order_items = 119190313
update Orders..[CardItem] set CardId = 5015404, TruncatedNumber = '545377******5949' where Id = 307718
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (5015404,307718,610275,'545377******5949',0)
update webstore..tbl_order set cd_new_order_context = null where cd_order=45691735
update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = 107826961
update webstore..tbl_order set cd_new_order_context = 421053 where cd_order = 52220603
update webstore..tbl_order_item set cd_new_context_order_item_id = 679759 where cd_order_items = 122468783
update Orders..[CardItem] set CardId = 4585822, TruncatedNumber = '545377******3362' where Id = 421053
insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values (4585822,421053,937198,'545377******3362',0)
update Orders..Reissue set Status = 67 where Id = 28397
delete from tbl_order_item_card where cd_orderitem_card = 81959452
update Orders..Reissue set Status = 67 where Id=28466
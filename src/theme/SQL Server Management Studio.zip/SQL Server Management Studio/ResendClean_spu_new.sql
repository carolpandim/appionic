USE [Webstore]
GO
/****** Object:  StoredProcedure [dbo].[ResendClean_spu]    Script Date: 5/17/2018 10:49:32 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[ResendClean_spu]
AS
BEGIN
	IF OBJECT_ID('tempdb..#tmp') IS NOT NULL DROP TABLE #tmp
	select 
		distinct
		tbl_order_item.cd_order_items as cd_order_items,
		case 
			when ds_front_description = 0 and tbl_order_item.discriminator <> 'EmailSendPasswordOrderItem' then
				'EmailSendPasswordOrderItem'
			when ds_front_description = 1 and tbl_order_item.discriminator <> 'SMSSendPasswordOrderItem' then
				'SMSSendPasswordOrderItem'
			when ds_front_description = 2 and tbl_order_item.discriminator <> 'LetterSendPasswordOrderItem' then
				'LetterSendPasswordOrderItem'
			when ds_front_description = 3 and tbl_order_item.discriminator <> 'CartaBercoSendPasswordOrderItem' then
				'CartaBercoSendPasswordOrderItem'
		end as tipo
		into #tmp
	from 
		tbl_order_item(nolock)
		inner join tbl_order_item_customization(nolock) on tbl_order_item_customization.cd_order_items = tbl_order_item.cd_order_items
		inner join tbl_order(nolock) on tbl_order_item.cd_order = tbl_order.cd_order
	where
			  (cd_product = 1219 and ds_front_description = 0 and tbl_order_item.discriminator <> 'EmailSendPasswordOrderItem')
		   or (cd_product = 1219 and ds_front_description = 1 and tbl_order_item.discriminator <> 'SMSSendPasswordOrderItem')
		   or (cd_product = 1219 and ds_front_description = 2 and tbl_order_item.discriminator <> 'LetterSendPasswordOrderItem')
		   or (cd_product = 1219 and ds_front_description = 3 and tbl_order_item.discriminator <> 'CartaBercoSendPasswordOrderItem')
	

	update tbl_order_item set Discriminator = 'EmailSendPasswordOrderItem' where cd_order_items in( select cd_order_items from #tmp as t where t.tipo = 'EmailSendPasswordOrderItem')
	update tbl_order_item_customization set Discriminator = 'EmailSendPasswordOrderItemCustomization' where cd_order_items in(select cd_order_items from #tmp as t where t.tipo = 'EmailSendPasswordOrderItem')

	update tbl_order_item set Discriminator = 'SMSSendPasswordOrderItem' where cd_order_items in( select cd_order_items from #tmp as t where t.tipo = 'SMSSendPasswordOrderItem')
	update tbl_order_item_customization set Discriminator = 'SMSSendPasswordOrderItemCustomization' where cd_order_items in(select cd_order_items from #tmp as t where t.tipo = 'SMSSendPasswordOrderItem')

	update tbl_order_item set Discriminator = 'LetterSendPasswordOrderItem' where cd_order_items in( select cd_order_items from #tmp as t where t.tipo = 'LetterSendPasswordOrderItem')
	update tbl_order_item_customization set Discriminator = 'LetterSendPasswordOrderItemCustomization' where cd_order_items in(select cd_order_items from #tmp as t where t.tipo = 'LetterSendPasswordOrderItem')

	update tbl_order_item set Discriminator = 'CartaBercoSendPasswordOrderItem' where cd_order_items in( select cd_order_items from #tmp as t where t.tipo = 'CartaBercoSendPasswordOrderItem')
	update tbl_order_item_customization set Discriminator = 'CartaBercoSendPasswordOrderItemCustomization' where cd_order_items in(select cd_order_items from #tmp as t where t.tipo = 'CartaBercoSendPasswordOrderItem')

end;
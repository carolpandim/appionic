select --*
	item.cd_order,
	item.cd_order_items,
	item.cd_new_context_order_item_id,
	o.cd_new_order_context,
	ca.cd_card,
	ca.ds_truncated_card,
	o.cd_channel,
	item.nr_document	
from 
	tbl_order_item_card as ca
	inner join tbl_order_item as item on ca.cd_order_items = item.cd_order_items
	inner join tbl_order as o on item.cd_order = o.cd_order
where --item.nr_document = '64549313668'
--o.cd_order in (1071956) 
ca.cd_card in (4344030)
--ca.cd_card=5283178	 
--and ds_truncated_card in ('545377******1289')
--cd_channel=13572
--cd_status=59
--cd_new_order_context=null
--item.cd_order_items = 13949063
order by o.cd_order desc

--Encontrar todos os pedidos do cpf no canal
select 
	t1.cd_order,
	t1.cd_order_items,
	t1.cd_new_context_order_item_id,
	t2.cd_new_order_context,
	t2.cd_channel
--	,ca.cd_card,
--	ca.ds_truncated_card
from 
	tbl_order_item t1
	inner join tbl_order t2 on t1.cd_order = t2.cd_order 
	and t2.cd_new_order_context is not null and t2.cd_channel = 7106
	--inner join tbl_order_item_card as ca on ca.cd_order_items = t1.cd_order_items
where 
	--t1.cd_order=64714775 and
	 t1.cd_order_item_base is null 
	 and t1.nr_document = '64549313668' 
order by
	t2.cd_order desc

--Colocar em Order_Id o valor do cd_new_order_context do select anterior
select 
	Order_Id,AccountId 
from [Orders]..AccountItem 
where
	Id =629597 --cd_new_context_order_item_id
and Order_Id = 396833 --cd_new_order_context
--select top 1 * from [Orders]..AccountItem 

---outras consultas
--Qdo aparecem dois cart�es iguais, deletar um deles
select * from tbl_order_item_card where cd_card=4586482
select * from tbl_order_item where  cd_order_items = 122483551 and cd_order_item_base is null
select * from tbl_order_tracking where cd_order = 52226504 order by 1 desc
select * from tbl_order where cd_order = 52226504

--Orders (s� nova plataforma)
select * 
from Orders..Reissue as l1 (nolock) 
where 
--l1.OriginalOrder_OrderId in (2414357)
--l1.ReissuedOrderId = 2414357
l1.OriginalCard_Id in (4426474)
--l1.ReissuedCard_Id = 2414357
--l1.OriginalOrder_ItemId = 150520441
--l1.ReissuedItemId = 150520441
order by 1 desc
--update Orders..Reissue set Status = 67 where Id in (34580,34520)

--OriginalCard_Id = 4426474
--Pedido = 526405
--N�mero Truncado: 530551******7821

--RessuedOrderId: 1071956
--N�mero Truncado: 530551******1172


select 	*
from [Orders]..[Order] as o
where o.Id = 490547

select 	*
from [Orders]..[Card] as c
where c.orderid = 602176

select 	*
from [Orders]..[CardItem] as ci
where ci.Order_Id in (602176) --and ci.CardId=2665196

select * from [Orders]..StatusHistory where Order_Id = 602176 

--Webstore
select *
from [Webstore]..[tbl_order] as o
where o.cd_order = 63071582

select  *
from [Webstore]..[tbl_cardmachine_items] as ci
where ci.cd_order in (63071582) 
--ci.cd_card in ()
order by 1 desc

select * from [Webstore]..[tbl_order_reissue] where cd_generated_order = 63071582

select * from [Biro]..[OrderItem] o where o.CardId=2470580
select * from [Biro]..[Os] where id=23262

select *
from
	tbl_order_item t1
	inner join tbl_order_item_customization t2 on t1.cd_order_items = t2.cd_order_items
	inner join tbl_product t3 on t3.cd_product = t1.cd_product
where
	t1.cd_order_items in(57961521 )
order by t1.cd_order

select *
from 
	tbl_order_item t1 (nolock)
	inner join tbl_order_item_customization t2 (nolock) on t2.cd_order_items = t1.cd_order_items
	inner join tbl_order t3 (nolock) on t1.cd_order = t3.cd_order
where t1.cd_order in(52226504 )


-----Doug
select o.id as OrderId, o.status as OrderStatus, o.Totals_CardCount as TotalCartao, o.Totals_CreditAmount as TotalCredito, o.WebStoreOrderId, a.accountid as AccountId, a.status as AccountStatus, c.CardId as CardId, c.status as CardStatus
from 
	[Orders]..[order] o
	left join [Orders]..AccountItem a on o.id = a.Order_Id
	left join [Orders]..CardItem c on c.AccountItem_Id = a.id
where --c.ExternalId = '000000167' and
 o.id in(602176)

--CardId=4426474

select *
from 
	orders..CardItem
where ExternalId = '000000167'
order by Id desc

select
	o.id, o.status, o.RoutingKey, a.AccountId, c.TruncatedNumber, ExternalId, c.*
from 
	orders..[order] o
		inner join orders..AccountItem a
			on o.id = a.Order_Id
				inner join orders..CardItem c
					on c.Order_Id = o.id
where 
	o.id in (602176)
and a.AccountId = 893053


-----Pedidos na Nova Plataforma (OnNote)

select o.id as OrderId, o.status as OrderStatus, o.Totals_CardCount as TotalCartao, o.Totals_CreditAmount as TotalCredito, o.WebStoreOrderId, a.accountid as AccountId, a.status as AccountStatus, c.CardId as CardId, c.status as CardStatus
from 
	[Orders]..[order] o
	left join [Orders]..AccountItem a on o.id = a.Order_Id
	left join [Orders]..CardItem c on c.AccountItem_Id = a.id
where 1=1
and o.id in(602176) and c.CardId=4586482






select cd_new_order_context, * from webstore..tbl_order where cd_order = 59206618
select cd_new_context_order_item_id, * from webstore..tbl_order_item where cd_order_items = 138346564
select cd_new_order_context, * from webstore..tbl_order where cd_order =  59206618
select cd_new_context_order_item_id, * from webstore..tbl_order_item where cd_order_items = 138346564
select CardId,TruncatedNumber, * from Orders..[CardItem] where Id =1280286

select * from Orders..[Card] where id = 5139595


select top 1 
	'via que foi gerado no legado ou ura' as viaReemissao,
	st1.*,
	'via na nova plataforma ===>' as via,
	st2.cd_new_context_order_item_id,
	st2.cd_order_items,
	st3.cd_order,
	st3.cd_new_order_context,
	st5.cd_card,
	st4.id as orderid,
	st6.Id,
	st6.CardId,
	st6.TruncatedNumber,
	st7.AccountId,
	'update webstore..tbl_order set cd_new_order_context = null where cd_order = '+ convert(varchar(100), st3.cd_order) as Update1,
	'update webstore..tbl_order_item set cd_new_context_order_item_id = null where cd_order_items = '+ convert(varchar(100), st2.cd_order_items) as Update2,
	'update webstore..tbl_order set cd_new_order_context = '+ convert(varchar(100), st3.cd_new_order_context) +' where cd_order = '+ convert(varchar(100), st1.cd_order) as Update3,
	'update webstore..tbl_order_item set cd_new_context_order_item_id = '+ convert(varchar(100), st2.cd_new_context_order_item_id) +' where cd_order_items = '+ convert(varchar(100), st1.cd_order_items) as Update4,
	'update Orders..[CardItem] set CardId ='+ convert(varchar(100), st1.cd_card) +', TruncatedNumber = '''+ convert(varchar(100), st1.ds_truncated_card) +''' where Id = '+ convert(varchar(100), st6.Id) as Update4,
	'insert Orders..[Card] (Id,OrderId,AccountId,TruncatedNumber,IsVirtual) values ('+ convert(varchar(100), st1.cd_card) +','+  convert(varchar(100), st4.id) +','+ convert(varchar(100), st7.AccountId) +','''+convert(varchar(100), st1.ds_truncated_card)  +''',0);' as Insert1
from
(
	select
		t1.cd_order,
		t1.cd_new_order_context,
		t2.cd_new_context_order_item_id,
		t1.cd_channel,
		t2.cd_order_items,
		t3.cd_card,
		t3.ds_truncated_card,
		t2.nr_document
	from
		tbl_order t1 (nolock)
		inner join tbl_order_item t2 (nolock) on t1.cd_order = t2.cd_order and t2.cd_order_item_base is null
		inner join tbl_order_item_card t3 (nolock) on t3.cd_order_items = t2.cd_order_items
	where
		t1.cd_order in 
(
59206618

)
) as st1
	inner join tbl_order_item st2(nolock) on st2.nr_document = st1.nr_document and st2.cd_order_item_base is null
	inner join tbl_order st3 (nolock) on st2.cd_order = st3.cd_order and st3.cd_channel = st1.cd_channel and st3.cd_new_order_context is not null
	inner join Orders..[order] st4 (nolock) on st4.Id = st3.cd_new_order_context
	inner join tbl_order_item_card st5 (nolock) on st5.cd_order_items = st2.cd_order_items
	inner join Orders..[CardItem] st6 (nolock) on st6.Order_Id = st4.Id
	inner join [Orders]..AccountItem st7 (nolock) on st4.id = st7.Order_Id
order by st6.Id desc
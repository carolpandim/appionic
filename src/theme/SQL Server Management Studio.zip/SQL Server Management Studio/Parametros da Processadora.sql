DECLARE @CARTAO AS CODIGOGRANDE
SET @CARTAO = 4796143
SELECT * 
FROM (  SELECT  
BB.CodigoParametro,
BB.Identificador, 
BB.Nome,
(SELECT TOP 1 CAST(xxx.ORDEM AS VARCHAR) + ' - ' + CAST(xxx.VALOR AS VARCHAR) AS VALOR  FROM 
(
select  CTP.Valor, 1 as ORDEM
from  processadora.[dbo].[ContasTitularesParametros]  CTP
WHERE  BB.CodigoParametro = CTP.CodigoParametro 
AND  CTP.CodigoContaTitular = A.CodigoContaTitular 
AND (CTP.DataExpiracao IS NULL OR CTP.DataExpiracao > GETDATE())

UNION  

select  CP.Valor, 2 as ORDEM
from  processadora.[dbo].[CanaisParametros]  CP
INNER JOIN Cartoes_ValePresente CVP (NOLOCK) ON CVP.CodigoCanal = CP.CodigoCanal
WHERE  BB.CodigoParametro = CP.CodigoParametro 
AND  cvp.CodigoCartao = a.CodigoCartao
AND (CP.DataExpiracao IS NULL OR CP.DataExpiracao > GETDATE())

UNION  

select  MP.Valor, 3 as ORDEM
from  processadora.[dbo].[ModalidadesParametros]  MP
WHERE  BB.CodigoParametro = MP.CodigoParametro 
AND  MP.CodigoModalidade = AA.CodigoModalidade

UNION

select  PP.Valor, 4 as ORDEM
from  processadora.[dbo].[ProdutosParametros]  pp
WHERE  BB.CodigoParametro = pp.CodigoParametro 
AND  pp.CodigoProduto = aa.CodigoProduto

UNION

select  PP.Valor, 5 as ORDEM
from  processadora.[dbo].[ParametrosSistema]  pp
WHERE  BB.CodigoParametro = pp.CodigoParametro   ) xxx
ORDER BY ORDEM 

) AS VALOR
from PROCESSADORA.DBO.CARTOES A
INNER JOIN PROCESSADORA.DBO.modalidades AA ON aa.CodigoModalidade = a.CodigoModalidade,
Parametros BB
WHERE A.cODIGOcARTAO = @CARTAO ) xxxxx
WHERE NOT valor is null

--select * from processadora.[dbo].[ParametrosSistema]



select MP.*, BB.* from PROCESSADORA.DBO.CARTOES A
INNER JOIN PROCESSADORA.DBO.modalidades AA ON AA.CodigoModalidade = A.CodigoModalidade
inner join processadora.[dbo].[ModalidadesParametros]  MP on MP.CodigoModalidade = AA.CodigoModalidade
inner join processadora.[dbo].Parametros BB on BB.CodigoParametro = MP.CodigoParametro 
where A.cODIGOcARTAO = 4796143

--update processadora.[dbo].[ModalidadesParametros] set Valor = '10000' where CodigoModalidade in (244,258) and CodigoParametro = 5
--update processadora.[dbo].[ModalidadesParametros] set Valor = 'N' where CodigoModalidade in (244,258) and CodigoParametro = 3

select * from processadora.[dbo].[ModalidadesParametros] where CodigoModalidade in (244,258)

select * from processadora.[dbo].[ModalidadesParametros] where CodigoModalidade in (244,258) and CodigoParametro in (5,3)

select * from vw_cartoes c where CodigoModalidade in (244,258)
﻿using CashCard.Model;
using CashCard.Process.Interfaces;
using CashCard.Util;
using CashCardDB.DataBase.Model.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace CashCard.Process
{
    public class CabifyProcess : IProcess
    {
        private static CabifyProcess oCabifyProcess;

        public static CabifyProcess Instance { get { oCabifyProcess = oCabifyProcess ?? new CabifyProcess(); return oCabifyProcess; } }

        /// <summary>
        /// Executa todos os processos necessários para realizar a recarga dos pedidos da Cabify.
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        /// <returns></returns>
        public void Execute(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Processo Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Execute", DateTime.Now, "Inicio Processo Cabify", false);

            try
            {
                //Realiza o downloading do arquivo csv
                Download(configuration);

                //Realiza a importação dos dados baixados
                Import(configuration);

                //Realiza a recarga dos pedidos
                Recharge(configuration);

                //Realiza a exportação de um arquivo de retorno
                Export(configuration);

                //Envia email
                Email(configuration);

            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Execute", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Execute", DateTime.Now, "Fim Processo Cabify", false);

            Console.WriteLine("Fim Processo Cabify");
        }

        /// <summary>
        /// Realiza do downloading do arquivo csv.
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        public void Download(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Download Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Download", DateTime.Now, "Inicio Download Cabify", false);

            try
            {
                //Busca as informações de configuração da Cabify
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 1).FirstOrDefault();

                //Realiza o downloading
                FtpService.Instance.DownloadDirectory(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Download", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Download", DateTime.Now, "Fim Download Cabify", false);

            Console.WriteLine("Fim Download Cabify");

        }

        /// <summary>
        /// Realiza a importação do arquivo .csv que se encontra no diretório local para a banco
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        public void Import(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Import Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Import", DateTime.Now, "Inicio Import Cabify", false);

            try
            {
                //Busca as informações de configuração da Cabify
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 1).FirstOrDefault();

                //Realiza a importação
                ImportData.Instance.ProcessFile(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Import", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Import", DateTime.Now, "Fim Import Cabify", false);

            Console.WriteLine("Fim Import Cabify");

        }

        /// <summary>
        /// Realiza a recarga dos cartões que foram importados
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        public void Recharge(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Recharge Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Recharge", DateTime.Now, "Inicio Recharge Cabify", false);

            try
            {
                //Busca as informações de configuração da Cabify
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 1).FirstOrDefault();

                //Realiza a recarga
                CabifyService.Instance.Recharge(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Recharge", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Recharge", DateTime.Now, "Fim Recharge Cabify", false);

            Console.WriteLine("Fim Recharge Cabify");

        }

        /// <summary>
        /// Realiza a exportação de um arquivo de retorno, com pedidos processados na recarga, exportando-o, via sftp, para um diretório remoto.
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        /// <returns></returns>
        public void Export(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Export Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Export", DateTime.Now, "Inicio Export Cabify", false);

            try
            {
                //Busca as informações de configuração da Cabify
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 1).FirstOrDefault();

                //Realiza a exportação
                ExportData.Instance.ProcessFile(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Export", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Export", DateTime.Now, "Fim Export Cabify", false);

            Console.WriteLine("Fim Export Cabify");

        }

        /// <summary>
        /// Envia email para os responsáveis do processo da Cabify
        /// </summary>
        /// <param name="configuration">Objeto com informações de configuração de todos os clientes</param>
        public void Email(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Envio Email Cabify");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Email", DateTime.Now, "Inicio Email Cabify", false);

            try
            {
                //Busca as informações de configuração da Cabify
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 1).FirstOrDefault();

                Util.Email.Instance.ProcessEmail(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Email", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Email", DateTime.Now, "Fim Email Cabify", false);

            Console.WriteLine("Fim Email Cabify");
        }

    }
}

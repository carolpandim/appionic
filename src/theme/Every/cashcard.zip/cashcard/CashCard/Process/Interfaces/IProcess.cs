﻿using CashCard.Model;
using System;
using System.Text;
using System.Threading.Tasks;

namespace CashCard.Process.Interfaces
{
	public interface IProcess
    {
		void Download(JsonConfiguration configuration);
		void Import(JsonConfiguration configuration);
		void Recharge(JsonConfiguration configuration);
		void Export(JsonConfiguration configuration);
        void Email(JsonConfiguration configuration);
	}
}

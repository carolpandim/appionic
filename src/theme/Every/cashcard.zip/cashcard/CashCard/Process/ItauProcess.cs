﻿using CashCard.Model;
using CashCard.Process.Interfaces;
using CashCard.Util;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CashCard.Process
{
	public class ItauProcess : IProcess
	{
		private static ItauProcess oItauProcess;

		public static ItauProcess Instance { get { oItauProcess = oItauProcess ?? new ItauProcess(); return oItauProcess; } }

		public void Execute(JsonConfiguration configuration)
		{
			Console.WriteLine("Inicio Processo Itau");

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Inicio Processo Itau", false);

			try
			{
                Download(configuration);

                Import(configuration);

                Recharge(configuration);

                Export(configuration);

                Email(configuration);
			}
			catch (Exception ex)
			{
				string msg = String.Format("ERRO: {0}", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, msg, true);
			}

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Fim Processo Itau", false);

			Console.WriteLine("Fim Processo Itau");

		}

		public void Download(JsonConfiguration configuration)
		{
			Console.WriteLine("Inicio Download Itau");

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Inicio Download Itau", false);

			try
			{
				JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 2).FirstOrDefault();

				FtpService.Instance.DownloadDirectory(config);
			}
			catch (Exception ex)
			{

				string msg = String.Format("ERRO: {0}", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Download", DateTime.Now, msg, true);
			}

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Fim Download Itau", false);

			Console.WriteLine("Fim Download Itau");
		}

		public void Import(JsonConfiguration configuration)
		{
			Console.WriteLine("Inicio Import Itau");

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Inicio Import Itau", false);

			try
			{
				JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 2).FirstOrDefault();

				ImportData.Instance.ProcessFile(config);
			}
			catch (Exception ex)
			{

				string msg = String.Format("ERRO: {0}", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Import", DateTime.Now, msg, true);
			}

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Fim Import Itau", false);

			Console.WriteLine("Fim Import Itau");

		}

		public void Recharge(JsonConfiguration configuration)
		{
			Console.WriteLine("Inicio Recharge Itau");

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Inicio Recharge Itau", false);

			try
			{
				JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 2).FirstOrDefault();

				ItauService.Instance.Recharge(config);
			}
			catch (Exception ex)
			{

				string msg = String.Format("ERRO: {0}", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Recharge", DateTime.Now, msg, true);
			}

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Fim Recharge Itau", false);

			Console.WriteLine("Fim Recharge Itau");

		}

		public void Export(JsonConfiguration configuration)
		{
			Console.WriteLine("Inicio Export Itau");

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Inicio Export Itau", false);

			try
			{
				JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 2).FirstOrDefault();

				ExportData.Instance.ProcessFile(config);
			}
			catch (Exception ex)
			{

				string msg = String.Format("ERRO: {0}", ex.Message);

				CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Export", DateTime.Now, msg, true);
			}

			CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Execute", DateTime.Now, "Fim Export Itau", false);

			Console.WriteLine("Fim Export Itau");

		}

        public void Email(JsonConfiguration configuration)
        {
            Console.WriteLine("Inicio Envio Email Itaú");

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Email", DateTime.Now, "Inicio Email Itaú", false);

            try
            {
                JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true && x.IdCliente == 2).FirstOrDefault();

                Util.Email.Instance.ProcessEmail(config);
            }
            catch (Exception ex)
            {

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Email", DateTime.Now, msg, true);
            }

            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("ItauProcess.Email", DateTime.Now, "Fim Email Itaú", false);

            Console.WriteLine("Fim Email Itaú");
        }
    }
}

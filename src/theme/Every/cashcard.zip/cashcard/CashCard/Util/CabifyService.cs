﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Request;
using CashCardDB.DataBase.Model.Response;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CashCard.Util
{
    public class CabifyService
    {
        private static CabifyService oCabifyService;

        public static CabifyService Instance { get { oCabifyService = oCabifyService ?? new CabifyService(); return oCabifyService; } }

        /// <summary>
        /// Preenchemos os modelos de dados das tabelas Arquivo e ArquivoItem, 
        /// com as respectivas informações de recarga da Cabify, e as salvamos no banco.
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        /// <param name="dataTable">Tabela preenchida com os dados extraídos do arquivo csv</param>
        /// <param name="pathName">Nome do Arquivo</param>
        /// <returns>Retorna uma msg dizendo se foi possível ou não salvar/importar as informações no banco.</returns>
        public String CreateArquivoCabify(JsonConfiguration.Configuration config, DataTable dataTable, string pathName)
        {
            String result = "";

            try
            {
                String idArquivo = Guid.NewGuid().ToString();

                Arquivo arquivo = new Arquivo();
                arquivo.IdArquivo = idArquivo;
                arquivo.NomeArquivo = pathName;
                arquivo.IdCliente = config.IdCliente;
                arquivo.DataArquivo = DateTime.Now;
                arquivo.Linhas = dataTable.Rows.Count;
                arquivo.Import = true;
                arquivo.DataImport = DateTime.Now;

                List<ArquivoItem> arquivoItens = new List<ArquivoItem>();

                foreach (DataRow row in dataTable.Rows)
                {
                    String idArquivoItem = Guid.NewGuid().ToString();

                    ArquivoItem item = new ArquivoItem();
                    item.IdArquivoItem = idArquivoItem;
                    item.IdArquivo = idArquivo;
                    item.RegionId = row["RegionID"].ToString();
                    item.CompanyId = row["CompanyID"].ToString();
                    item.Cpf = row["DriverNationalIdNum"].ToString().Trim().PadLeft(11, '0');
                    item.VlRecarga = row["CostLocal"].ToString().Replace(",", ".").Replace("R$", "").Replace("-", "");

                    arquivoItens.Add(item);
                }

                //Salva os pedidos de recarga no banco CashCard, nas tabelas Arquivo e ArquivoItem
                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SalvarArquivo(arquivo, arquivoItens, config.AccountIdMatriz);

                result = "OK";
            }
            catch (Exception ex)
            {
                result = "ERRO: " + ex.Message;

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyService.CreateArquivoCabify", DateTime.Now, result, true);

            }

            return result;
        }

        /// <summary>
        /// Realizo a recarga dos pedidos que foram importados, que não foram ainda processados na recarga, considerando a situação do cartão.
        /// </summary>
        /// <param name="config">Configurações do cliente</param>
        public void Recharge(JsonConfiguration.Configuration config)
        {
            List<ArquivoResponse> lArquivoToRecharge = new List<ArquivoResponse>();
            List<CashCardOrderResponse> lCashCardOrderResponse = new List<CashCardOrderResponse>();

            string idArquivo = "";

            try
            {
                //Lista todos os pedidos da Cabify a serem processados para recarga
                List<string> lArquivo = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivosByStatus("recharge", config.IdCliente, null);

                if (lArquivo.Count > 0)
                {
                    foreach (var arquivo in lArquivo)
                    {
                        idArquivo = arquivo;

                        //Lista todos os pedidos do arquivo que serão processados na recarga
                        lArquivoToRecharge = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetArquivoToRecharge(arquivo);

                        if (lArquivoToRecharge.Count > 0)
                        {
                            object Lock = new object();

                            Parallel.ForEach(lArquivoToRecharge,
                                item =>
                                {
                                    lock (Lock)
                                    {
                                        //Verifica no arquivo de configuração se a situação do cartão é permitida
                                        if (config.SituacaoRecargaPermitida.Contains(item.CodSituacao.Value))
                                        {
                                            CashCardOrderRequest cashCardOrderRequest = new CashCardOrderRequest();
                                            cashCardOrderRequest.id = config.AccountIdMatriz;
                                            cashCardOrderRequest.amount = item.VlRecarga.Value;
                                            cashCardOrderRequest.summary = "CashCard";
                                            cashCardOrderRequest.toAccount = item.IdAccount.ToString();

                                            CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                            //Envia o request para a web api da accounts pra realizar a recarga
                                            var response = HttpClientService.Instance.Transfer(config.AccountIdMatriz.ToString(), cashCardOrderRequest);
                                            cashCardOrderResponse.Success = response.Result.Success;
                                            cashCardOrderResponse = response.Result;
                                            cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            //cashCardOrderResponse.Success = true;
                                            //cashCardOrderResponse.Result = "teste";
                                            //cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            //cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            //Adiciona a resposta do post do pedido à uma lista de resultados
                                            lCashCardOrderResponse.Add(cashCardOrderResponse);

                                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                        }
                                        //Senão, não se realiza a recarga, preenchendo apenas a lista de resultado com a informação abaixo
                                        else
                                        {
                                            CashCardOrderResponse cashCardOrderResponse = new CashCardOrderResponse();

                                            cashCardOrderResponse.Success = false;
                                            cashCardOrderResponse.Result = "Situacao do cartao nao permitida. Recarga nao realizada.";
                                            cashCardOrderResponse.idArquivo = item.IdArquivo;
                                            cashCardOrderResponse.idArquivoItem = item.IdArquivoItem;

                                            lCashCardOrderResponse.Add(cashCardOrderResponse);

                                            CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusItem(idArquivo, cashCardOrderResponse);
                                        }
                                    }
                                });

                            //Verifica se foram processados todos os arquivos
                            var statusArquivo = (lCashCardOrderResponse.Where(x => x.Success).Count() == lCashCardOrderResponse.Count());

                            if (!statusArquivo)
                            {
                                Reprocess.Instance.ReprocessFileToRecharge(idArquivo);
                            }
                            else
                            {
                                //Atualiza as informações de recarga no arquivo e nos seus pedidos, com as respectivas informações da lista de resultados, montada ao longo do precesso
                                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateStatusArquivo(idArquivo, statusArquivo);

                                if (statusArquivo)
                                {
                                    string message = string.Format("Pedidos de recarga do arquivo {0} processados com sucesso.", idArquivo);

                                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyService.Recharge", DateTime.Now, message, false);
                                }
                                else
                                {
                                    string message = string.Format("Não foram processados todos os pedidos de recarga do arquivo {0}.", idArquivo);

                                    CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyService.Recharge", DateTime.Now, message, false);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = string.Format("Falha no recarga do arquivo {0}. ERRO: {1}", idArquivo, ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyService.Recharge", DateTime.Now, message, true);
            }
        }
    }
}

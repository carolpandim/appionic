﻿using CashCard.Model;
using CashCardDB.DataBase.Model.Response;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;


namespace CashCard.Util
{
    public class Email
    {
        private static Email oEmail;

        public static Email Instance { get { oEmail = oEmail ?? new Email(); return oEmail; } }

        public void ProcessEmail(JsonConfiguration.Configuration config)
        {
            string idArquivo = string.Empty;

            StringBuilder sb = new StringBuilder();

            List<string> listArquivos = new List<string>();

            try
            {
                List<InfoEmail> listInfoEmail = CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.GetInfoEmail(config.IdCliente);

                if (listInfoEmail != null)
                {
                    string localDir = config.Sources[0].LocalPath;

                    List<Attachment> files = new List<Attachment>();

                    foreach (var infoEmail in listInfoEmail)
                    {
                        idArquivo = infoEmail.IdArquivo;

                        Console.WriteLine("Enviando Email do Arquivo: " + infoEmail.NomeArquivo);

                        sb.AppendLine("Informações sobre o processamento do arquivo " + infoEmail.NomeArquivo);

                        if (infoEmail.DtInicio.HasValue)
                        {
                            sb.AppendLine("Início da Recarga: " + infoEmail.DtInicio.Value.ToString("dd-MM-yyyy HH:mm"));
                        }

                        if (infoEmail.DtFinal.HasValue)
                        {
                            sb.AppendLine("Fim da Recarga: " + infoEmail.DtFinal.Value.ToString("dd-MM-yyyy HH:mm"));
                        }

                        if (infoEmail.Linhas >= 0)
                        {
                            sb.AppendLine("Número de Linhas Importadas: " + infoEmail.Linhas.ToString());
                        }

                        if (infoEmail.Recharge.HasValue)
                        {
                            if (infoEmail.Recharge.Value && infoEmail.Linhas == infoEmail.IsRecharge)
                            {
                                sb.AppendLine("Status: Recarga realizada com sucesso!");
                            }
                            else
                            {
                                 sb.AppendLine("Status: Não foi possível realizar todas as recargas.");

                                sb.AppendLine(String.Format("Resultado: Dos {0} pedidos de recarga, {1} foram processados com sucesso e {2} não foram possíveis realizar.",
                                        infoEmail.Linhas.ToString(), infoEmail.IsRecharge.ToString(), infoEmail.Linhas - infoEmail.IsRecharge));

                                sb.AppendLine("Motivos:");

                                if (infoEmail.SituacaoNaoAut > 0)
                                {
                                    sb.AppendLine(String.Format("- Situação de cartão não autorizada: {0}", infoEmail.SituacaoNaoAut.ToString()));
                                }

                                if (infoEmail.NaoEncontrado > 0)
                                {
                                    sb.AppendLine(String.Format("- CPF inválido, cartão não encontrado: {0}", infoEmail.NaoEncontrado.ToString()));
                                }

                                if (infoEmail.Superior > 0)
                                {
                                    sb.AppendLine(String.Format("- Saldo maior que o limite informado: {0}", infoEmail.Superior.ToString()));
                                }

                                if (infoEmail.Outros > 0)
                                {
                                    sb.AppendLine(String.Format("- Motivos diversos que precisam ser investigados: {0}", infoEmail.Outros.ToString()));
                                }
                            }
                        }

                        sb.AppendLine();

                        string filePath = localDir + "\\" + infoEmail.NomeArquivo.ToString();

                        filePath = filePath.Replace("_input", "_output");

                        Attachment attachment = new Attachment(filePath);

                        Console.WriteLine("Corpo do Email:");
                        Console.WriteLine(sb.ToString());

                        //Realiza o envio do email - Esse método só roda em produção
                        //SendEmail(config.Email, "Relatório de Recarga Cliente " + config.Cliente + " " + DateTime.Now.ToString("dd/MM/yyyy"), sb.ToString(), attachment);

                        CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateEmailCashCard(true, idArquivo);
                    }
                }
            }
            catch (Exception ex)
            {

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.UpdateEmailCashCard(false, idArquivo);

                string msg = String.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("CabifyProcess.Email", DateTime.Now, msg, true);
            }
        }

        public void SendEmail(List<String> to, String Subject, String body, Attachment attachment = null)
        {
            try
            {
                SmtpClient smtpClient = new SmtpClient();
                smtpClient.Host = ConfigurationManager.AppSettings["emailHost"];
                smtpClient.Port = Convert.ToInt32(ConfigurationManager.AppSettings["emailPort"]);
                smtpClient.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["emailUserName"], ConfigurationManager.AppSettings["emailPwd"]);
                smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["emailSsl"]);

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["emailFrom"]);

                foreach (var email in to)
                {
                    mailMessage.To.Add(new MailAddress(email));
                }

                mailMessage.Subject = Subject;
                mailMessage.Body = body;
                mailMessage.BodyEncoding = Encoding.UTF8;
                mailMessage.IsBodyHtml = true;

                if (attachment != null)
                {
                    mailMessage.Attachments.Add(attachment);
                }

                smtpClient.Send(mailMessage);

                Console.WriteLine("Email enviado com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao enviar o e-mail: " + ex);
                throw;
            }

        }
    }
}

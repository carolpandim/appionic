﻿//using CashCard.Model;
//using CashCardDB.DataBase.Model.Request;
//using CashCardDB.DataBase.Model.Response;
//using Newtonsoft.Json;
//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Text;
//using System.Threading.Tasks;

//namespace CashCard.Util
//{
//	public class HttpClientService
//	{
//		private static HttpClientService oHttpClientService;

//		public static HttpClientService Instance { get { oHttpClientService = oHttpClientService ?? new HttpClientService(); return oHttpClientService; } }

//		public async Task<CashCardOrderResponse> asyncTaskOrders(JsonConfiguration configuration, CashCardOrderRequest cashCardOrderRequest)
//		{
//			CashCardOrderResponse result = null;

//			JsonConfiguration.Configuration config = configuration.configuration.Where(x => x.Ativo == true).FirstOrDefault();

//			string url = "";
//			string urlAuthPPI = ConfigurationManager.AppSettings["urlAuthPPI"];
//			string userNamePPI = ConfigurationManager.AppSettings["userNamePPI"];
//			string pwdPPI = ConfigurationManager.AppSettings["pwdPPI"];
//			string urlCardsPPI = ConfigurationManager.AppSettings["urlCardsPPI"];
//			string conta = config.Conta;

//			try
//			{
//				using (HttpClient httpClient = new HttpClient())
//				{
//					Dictionary<string, string> tokenDetails = null;

//					HttpClient client = new HttpClient();

//					url = String.Format(urlAuthPPI, conta);

//					client.BaseAddress = new Uri(url);

//					var login = new Dictionary<string, string>
//								   {
//									   {"grant_type", "password"},
//									   {"username", userNamePPI},
//									   {"password", pwdPPI},
//								   };

//					HttpResponseMessage response = client.PostAsync("Token", new FormUrlEncodedContent(login)).Result;

//					if (response.IsSuccessStatusCode)
//					{
//						tokenDetails = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.Content.ReadAsStringAsync().Result);

//						if (tokenDetails != null && tokenDetails.Any())
//						{
//							var tokenNo = tokenDetails.FirstOrDefault().Value;

//							client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenNo);

//							client.DefaultRequestHeaders.Accept.Clear();
//							client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//							var json = JsonConvert.SerializeObject(cashCardOrderRequest);
//							var buffer = Encoding.UTF8.GetBytes(json);
//							var byteContent = new ByteArrayContent(buffer);
//							byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

//							//cashCardOrderRequest é o identifier
//							url = String.Format(urlCardsPPI, cashCardOrderRequest.transfersCode);
//							client.BaseAddress = new Uri(url);

//							response = await client.PostAsync(url, byteContent);

//							if (response.IsSuccessStatusCode)
//							{
//								result = JsonConvert.DeserializeObject<CashCardOrderResponse>(await response.Content.ReadAsStringAsync());

//							}

//						}
//					}
//				}
//			}
//			catch (Exception)
//			{
//				throw;
//			}

//			return result;
//		}
//	}
//}

﻿{
    "configuration": [
        {
            "idCliente": 1,
            "cliente": "cabify",
            "ativo": true,
            "sources":
                [
                    {
                        "ftpUrl": "sftp.paypaxx.com.br",
                        "ftpUser": "cabify",
                        "ftpPwd": "9iHDzp5U4ydJ6i6CY0eVv6QIb",
                        "ftpPort": 15022,
                        "FtpDirectory": "/cabify",

                        //Local
                        "LocalPath": "C:\\Sources\\300\\cashcard\\FTP\\Cabify"

                        //Produção
                        //"LocalPath": "C:\\Apps\\cashcard\\FTP\\Cabify"

                    }
                ],
            "HeadersInput": ["RegionID", "CompanyID", "DriverNationalIdNum", "CostLocal"],
            "HeadersOutput": ["RegionId", "CompanyId", "Cpf", "VlRecarga", "NomeArquivo", "CardId", "Recharge", "DescricaoProcessamento", "DataRecarga"],
            "SituacaoRecargaPermitida": [1, 2, 5, 6, 14, 18, 20, 21, 29],
            "AccountIdMatriz": 1327817,
            "Email": ["valenti.ana@hubfintech.com.br", "leandro.ikezili@hubfintech.com.br"]
        },
        {
            "idCliente": 2,
            "cliente": "itau",
            "ativo": true,
            "sources":
                [
                    {
                        "ftpUrl": "sftp.paypaxx.com.br",
                        "ftpUser": "cabify",
                        "ftpPwd": "9iHDzp5U4ydJ6i6CY0eVv6QIb",
                        "ftpPort": 15022,
                        "FtpDirectory": "/cabify",

                        //Local
                        "LocalPath": "C:\\Sources\\300\\cashcard\\FTP\\Itau",

                        //Produção
                        //"LocalPath": "C:\\Apps\\cashcard\\FTP\\Itau"
                    }
                ],
            "HeadersInput": ["identificador", "limite"],
            "HeadersOutput": ["NomeArquivo", "CardId", "Cpf", "Identificador", "Limite", "Saldo", "DescricaoProcessamento", "Recharge", "VlRecarga", "DataRecarga"],
            "Email": ["valenti.ana@hubfintech.com.br", "leandro.ikezili@hubfintech.com.br"],

            //Itaú
            //"SituacaoRecargaPermitida": [1, 2, 5, 6, 14, 18, 20, 21, 29],
            //"AccountIdMatriz": 776293,            
            //"CompanyId": 1142,
            //"ProductId": 30

            //Teste
            "SituacaoRecargaPermitida": [22],            
            "AccountIdMatriz": 835561,    
            "CompanyId": 26,            
            "ProductId": 36
        }
    ]
}		
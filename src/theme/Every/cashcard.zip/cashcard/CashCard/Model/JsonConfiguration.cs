﻿using System;
using System.Collections.Generic;

namespace CashCard.Model
{
	public class JsonConfiguration
    {
		public List<Configuration> configuration { get; set; }

		public class Configuration
		{
			public Int32 IdCliente { get; set; }
			public String Cliente { get; set; }
			public Boolean Ativo { get; set; }
			public List<Source> Sources { get; set; }
			public List<String> HeadersInput { get; set; }
			public List<String> HeadersOutput { get; set; }
			public List<Int32> SituacaoRecargaPermitida { get; set; }
			public Int32 AccountIdMatriz { get; set; }
            public List<String> Email { get; set; }
            public Int32 CompanyId { get; set; }
            public Int32 ProductId { get; set; }

            public class Source
			{
				public String FtpUrl { get; set; }
				public String FtpUser { get; set; }
				public String FtpPwd { get; set; }
				public String FtpDirectory { get; set; }
				public Int32 FtpPort { get; set; }
				public String LocalPath { get; set; }
			}		
		}
	}
}

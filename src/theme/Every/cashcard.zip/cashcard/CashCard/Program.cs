﻿using CashCard.Model;
using CashCard.Util;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace CashCard
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Data Inicio Processamento:" + DateTime.Now.ToString());

                Stopwatch stopWatch = new Stopwatch();

                stopWatch.Start();

                string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"configuration.js");

                string config = File.ReadAllText(path);

                var configuration = JsonConvert.DeserializeObject<JsonConfiguration>(config);

                Console.WriteLine("Digite o número do cliente para iniciar o processo de recarga: ");
                Console.WriteLine("1 - Cabify");
                Console.WriteLine("2 - Itaú");
                Console.WriteLine("3 - Reprocessar Arquivo");
                Console.WriteLine("4 - Todos");
                
                string idCliente = "";

                if (args.Length > 0)
                {
                    idCliente = args[0];
                }
                else
                {
                    idCliente = Console.ReadLine();
                }

                Console.WriteLine(idCliente);

                switch (idCliente)
                {
                    case "1":
                        Process.CabifyProcess.Instance.Execute(configuration);
                        break;
                    case "2":
                        Process.ItauProcess.Instance.Execute(configuration);
                        break;
                    case "3":
                        Console.WriteLine("Insira o id do arquivo para reprocessar a recarga:");
                        string idArquivo = Console.ReadLine();
                        Reprocess.Instance.ReprocessFileToRecharge(idArquivo);
                        Reprocess.Instance.ReprocessFileToExport(configuration, idArquivo);
                        break;
                    case "4":
                        Process.CabifyProcess.Instance.Execute(configuration);
                        Process.ItauProcess.Instance.Execute(configuration);
                        break;
                }

                stopWatch.Stop();

                TimeSpan ts = stopWatch.Elapsed;

                Console.WriteLine(String.Format("Tempo de Processamento: {0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10));

                Console.WriteLine("Data Fim Processamento:" + DateTime.Now.ToString());
            }
            catch (Exception ex)
            {
                string message = string.Format("ERRO: {0}", ex.Message);

                CashCardDB.DataBase.Mysql.Procedures.CashCard.Instance.SaveLog("Program.Main", DateTime.Now, message, true);
            }

        }
    }
}

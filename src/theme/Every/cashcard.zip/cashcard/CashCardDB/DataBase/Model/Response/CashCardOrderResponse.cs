﻿using System;

namespace CashCardDB.DataBase.Model.Response
{
	public class CashCardOrderResponse
    {
		public String idArquivoItem { get; set; }
		public String idArquivo { get; set; }
		public Boolean Success { get; set; }
		public string Result { get; set; }
    }
}

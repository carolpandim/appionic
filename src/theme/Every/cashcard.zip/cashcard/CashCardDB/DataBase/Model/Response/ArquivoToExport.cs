﻿using System;

namespace CashCardDB.DataBase.Model.Response
{
	public class ArquivoToExport
    {
		public string IdCliente { get; set; }
        public String RegionId { get; set; }
        public String CompanyId { get; set; }
        public string Cpf { get; set; }
        public string Identificador { get; set; }
        public string VlRecarga { get; set; }
        public string NomeArquivo { get; set; }
        public bool Recharge { get; set; }
        public string CardId { get; set; }
		public string Limite { get; set; }
		public string Saldo { get; set; }
		public string DescricaoProcessamento { get; set; }
		public string DataRecarga { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;

namespace CashCardDB.DataBase.Model.Response
{
    public class Arquivo
    {
		public Arquivo()
		{
			ArquivoItens = new List<ArquivoItem>();
		}

		public string IdArquivo { get; set; }
		public string NomeArquivo { get; set; }
		public int IdCliente { get; set; }
		public DateTime DataArquivo { get; set; }
		public int Linhas { get; set; }
		public Boolean? Import { get; set; }
		public DateTime? DataImport { get; set; }
		public Boolean? Recharge { get; set; }
		public DateTime? DataRecharge { get; set; }
		public Boolean? Export { get; set; }
		public DateTime? DataExport { get; set; }
		public Boolean Email { get; set; }
		public DateTime? DataEmail { get; set; }

		public List<ArquivoItem> ArquivoItens { get; set; }
	}
}

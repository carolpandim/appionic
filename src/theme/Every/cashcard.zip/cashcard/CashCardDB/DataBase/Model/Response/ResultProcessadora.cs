﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Response
{
    public class ResultProcessadora
    {
        public String Cpf { get; set; }
        public String CardId { get; set; }
        public String CodSituacao { get; set; }
        public String IdAccount { get; set; }
        public String Saldo { get; set; }
        public String IdAccountParent { get; set; }

    }
}

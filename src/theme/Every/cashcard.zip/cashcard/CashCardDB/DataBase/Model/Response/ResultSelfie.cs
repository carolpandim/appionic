﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardDB.DataBase.Model.Response
{
    public class ResultSelfie
    {
        public String Identificador { get; set; }
        public String CardId { get; set; }
        public String Cpf { get; set; }
    }
}

﻿using System;

namespace CashCardDB.DataBase.Model.Response
{
    public class ArquivoItem
    {
		public string IdArquivoItem { get; set; }
		public string IdArquivo { get; set; }
		public string DescricaoProcessamento { get; set; }
		public Boolean? Recharge { get; set; }

		//Cabify
		public string CardId { get; set; }
		public string Cpf { get; set; }
		public string VlRecarga { get; set; }

		//Itau
		public string Identificador { get; set; }
		public string Limite { get; set; }
		public string Saldo { get; set; }

		public string IdAccount { get; set; }
        public String IdAccountParent { get; set; }
        public string CodSituacao { get; set; }

        public String RegionId { get; set; }
        public String CompanyId { get; set; }
    }
}

﻿using System;

namespace CashCardDB.DataBase.Model.Request
{
	public class CashCardOrderRequest
	{
		public Int64 id { get; set; }
		public Decimal amount { get; set; }
		public String summary { get; set; }
		public String toAccount { get; set; }
		public String transactionChannel { get { return "p2p"; } }
		public DateTime ocurredOn { get { return DateTime.Now; } }
		public String idempotencyKey { get { return Guid.NewGuid().ToString(); } }

	}
}

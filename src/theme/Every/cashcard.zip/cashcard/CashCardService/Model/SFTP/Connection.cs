﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CashCardService.Model.SFTP
{
    public class Connection
    {
    }
}

﻿using CashCardDB.DataBase.Model.Response;

namespace CashCardService.Util
{
    public class CarbifyService
    {
		private static CarbifyService oCarbifyService;

		public static CarbifyService Instance { get { oCarbifyService = oCarbifyService ?? new CarbifyService(); return oCarbifyService; } }

		public void GetOrderCarbify(Model.JsonConfiguration configuration)
		{ }
	}
}

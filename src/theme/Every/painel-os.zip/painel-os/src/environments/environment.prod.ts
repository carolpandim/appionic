export const environment = {
  production: true,
  SessionKey: "PainelOS",
  Api: "http://qa-painelos-api.valepresente.net.br/api",    
  ImageApi: "",
  CDN: "",
  Bucket: "",
  ResultPerPage: 50,
  RastreioUrl:"http://qa-painelos-api.valepresente.net.br/63509"
};

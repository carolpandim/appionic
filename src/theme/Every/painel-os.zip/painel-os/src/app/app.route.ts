import { Routes, RouterModule } from '@angular/router';
import { DashBoardRoutes } from './views/dashboard/dashboard';
import { LoginRoutes } from './views/login/login';
import { SystemRoutes } from './views/system/system';
import { PedidoRoutes } from './views/pedido/pedido';
import { OrdemServicoRoutes } from './views/ordemServico/ordemServico';
import { TiposOsRoutes } from './views/tiposOs/tiposOs';
import { RangeCepRoutes } from './views/rangecep/rangecep';
import { MetodosTransportesRoutes } from './views/metodosTransportes/metodostransportes';
import { ConfigProdutoRoutes } from './views/configProduto/configProduto';


const appRoutes: Routes = [
    ...LoginRoutes,
    ...DashBoardRoutes,
    ...SystemRoutes,
    ...PedidoRoutes,
    ...OrdemServicoRoutes,
    ...TiposOsRoutes,
    ...MetodosTransportesRoutes,
    ...RangeCepRoutes,
    ...ConfigProdutoRoutes,

];

export const appRoute: any[] = [
   
];

export const routes = RouterModule.forRoot(appRoutes);
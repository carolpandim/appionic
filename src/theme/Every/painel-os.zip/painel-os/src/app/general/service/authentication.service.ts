import { Injectable } from '@angular/core';
import { AppConfig } from '../app.configuration';
Injectable()
export class AuthenticationService {

    setIsLogged(isLogged: string) {
        localStorage.setItem(AppConfig.SessionKey + "_logged", isLogged);   
    }

    getIsLogged() {
        return localStorage.getItem(AppConfig.SessionKey + "_logged");    
    }    

    setToken(token: string) {
        localStorage.setItem(AppConfig.SessionKey + "_token", token);   
    }

    getToken() {
        return localStorage.getItem(AppConfig.SessionKey + "_token");   
    }

    getUser(): any {
        let data = localStorage.getItem(AppConfig.SessionKey + "_user");
        return JSON.parse(data);
    }

    setUser(user: any) {
        localStorage.setItem(AppConfig.SessionKey + "_user", JSON.stringify(user));
    }

    getSearchCard(): any {
        let data = localStorage.getItem(AppConfig.SessionKey + "_search_card");
        return JSON.parse(data);
    }

    setSearchCard(search_card: any) {
        localStorage.setItem(AppConfig.SessionKey + "_search_card", JSON.stringify(search_card));
    }    

    getSearchPedido(): any {
        let data = localStorage.getItem(AppConfig.SessionKey + "_search_produto");
        return JSON.parse(data);
    }

    getSearchCaixa(): any {
        let data = localStorage.getItem(AppConfig.SessionKey + "_search_caixa");
        return JSON.parse(data);
    }

    setSearchCaixa(search_card: any) {
        localStorage.setItem(AppConfig.SessionKey + "_search_caixa", JSON.stringify(search_card));
    }      

    getUserPermission(PermissionId: Array<any>) {

         let permissions = this.getPermissions();

         let item = permissions.find(x => PermissionId.indexOf(x) > -1);

         if(!item)
         {
            return this.getUser().UsuarioID;
         }
         else{
            return 0;
         }
        
    }        

    setPermissions(permission: Array<any>) {
        localStorage.setItem(AppConfig.SessionKey + "_permission", JSON.stringify(permission));
    }

    getPermissions() {
        let data = localStorage.getItem(AppConfig.SessionKey + "_permission");
        return JSON.parse(data) || null;
    }


    clearSession() {
        localStorage.clear();
    }


    get isAuthenticated(): Boolean {
        return this.getIsLogged() != null;
    }
}
import { CheckPermissionDirective } from './check-permission.directive';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
    imports: [
        BrowserModule
    ],
    declarations: [
        CheckPermissionDirective
    ],
    exports: [
        CheckPermissionDirective
    ]
})

export class CheckPermissionModule { }

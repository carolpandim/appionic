import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Injectable()
export class AuthenticationGuard implements CanActivate {
    constructor(private authenticationService: AuthenticationService, private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot) {
        if (this.authenticationService.isAuthenticated) {

            return true;

            // let current_url = this.router.url;
            // let permissions = this.authenticationService.getPermissions();

            // let user = this.authenticationService.getUser();
            
            // if(route.url.length == 0) {
            //     return true;
            // }
            
            // let modulo = route.data["module"];
            // let permission = route.data["permission"];

            // let item = permissions.find(x => modulo.indexOf(x.Permissao.ModuloID) > -1 &&
            //                             permission.indexOf(x.Permissao.PermissaoID) > -1);
            
            // if(!item) {
            //     this.router.navigate(['/dashboard']);
            // }
            // else {
            //     return true;
            // }

        } else {
            this.router.navigate(['/']);
        }
    }
}

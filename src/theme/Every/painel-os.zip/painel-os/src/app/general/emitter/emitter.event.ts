import { Subject } from 'rxjs/Subject';

export class EmitterEvent extends Subject<String>{
    constructor() {
        super();
    }
    emit(value) { super.next(value); }
}

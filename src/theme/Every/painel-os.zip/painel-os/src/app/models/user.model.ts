export class UserModel {
    constructor()
    { }

    public token:string;
    public expiration: string;
    public name: string;
}
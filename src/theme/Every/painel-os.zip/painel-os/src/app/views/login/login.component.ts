import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppComponent } from "../../app.component";
import { AuthProvider } from "../../providers/auth.provider";
import { AuthenticationService } from "../../general/service/authentication.service";
import { EmitterProvider } from "../../general/emitter/emitter.provider";
import { EmitterType } from "../../general/emitter/emitter.type";
import { InputMaskModule } from 'primeng/primeng';
import { UserModel } from "../../models/user.model";
import { CookieService } from 'ng2-cookies';

declare var theme: {
    init(): void
    clean(): void
}

@Component({
    selector: 'as-login',
    templateUrl: 'login.component.html',
    providers: [AuthProvider, CookieService]
})
export class LoginComponent {
    public showLogin = true;

    loginForm: FormGroup;

    recoverForm: FormGroup;

    showError: Boolean;

    constructor(
        private router: Router,
        public formBuilder: FormBuilder,
        private appComponent: AppComponent,
        private authProvider: AuthProvider,
        private emitter: EmitterProvider,
        private authenticationService: AuthenticationService,
        public cookieService: CookieService

    ) {
        this.loginForm = formBuilder.group({
            usuario: ['', Validators.required],
            senha: ['', Validators.required],
            remember: ['']
        });

        this.recoverForm = formBuilder.group({
            email: ['', Validators.required]
        });

        if (this.cookieService.check("login")) {
            this.loginForm.patchValue(JSON.parse(this.cookieService.get("login")), { onlySelf: true });
        }

    }

    signIn() {
        let errorCallback = (error: any) => {
            this.showError = error != null;
        };

        this.authenticationService.clearSession();

        if (this.loginForm.valid) {

            this.authProvider.signIn(this.loginForm.value, null).subscribe((response) => {

                if (this.loginForm.get('remember').value == true) {
                    this.cookieService.set("login", `{"remember":true,"usuario":"${this.loginForm.get('usuario').value}"}`);
                }
                else {
                    this.cookieService.delete("login");
                }

                let dataLogged: UserModel = response;
                this.authenticationService.setUser(response);
                this.authenticationService.setToken(response.token);

                this.authenticationService.setIsLogged("1");                        
                this.emitter.base.emit(EmitterType.USER_SIGN_IN);
                this.router.navigate(['/pedido']);  
                

                // this.employeeProvider.getProfile(dataLogged.tokenU).subscribe((responseUser) => {
                //     this.userGroupProvider.get(responseUser.data.idGrupoUsuario).subscribe((permissoesResponse) => {

                //         this.authenticationService.setPermissions(permissoesResponse.data.permissoes);
                //             this.authenticationService.setIsLogged("1");                        
                //             this.emitter.base.emit(EmitterType.USER_SIGN_IN);
                //             this.appComponent.ConfigPanel();
                //             this.router.navigate(['/dashboard']);  
                //             //document.location.href = "/dashboard";                        
                //                 //registrar as tags oneginal
                //                 //theme.oneSignalRegister({usuarioID: userResponse.UsuarioID, grupoAcessoID: store.GrupoUsuarioID, lojaID: store.LojaID});
                //         });
                //     });                    
            });
        }
    }

    reenviarSenha() {

    }

    goForget() {
        this.showLogin = false;
    }

    backLogin() {
        this.showLogin = true;
    }
}
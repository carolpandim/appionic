import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { VersionComponent } from './version/version.component';


@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule
    ],
    declarations: [
        VersionComponent
    ],
    exports: [
        VersionComponent
    ]
})

export class SystemModule { }

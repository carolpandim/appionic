import { Component, NgModule, OnInit, ViewChild, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { DataTable, ConfirmationService } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppConfig } from '../../../general/app.configuration';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { ItemOsProvider } from '../../../providers/itemOs.provider';

@Component({
    selector: 'detail-os-item',
    templateUrl: './detail.component.html',
    providers: [ConfirmationService]
})
export class DetailComponent {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();
    
    form: FormGroup;
    editData: any = {};

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private confirmationService: ConfirmationService,
        private itemOsProvider: ItemOsProvider
    ) {

    }

    LoadData(idItem: any)
    {        
        if(idItem)
        {
            this.itemOsProvider.detail(idItem).subscribe((response) =>{
                if(response.success)
                {
                    this.editData = response.data;
                }
            });
        }
        else{
            this.editData = {};
        }
    }   

    ngAfterViewChecked() {
    
    }
    

}

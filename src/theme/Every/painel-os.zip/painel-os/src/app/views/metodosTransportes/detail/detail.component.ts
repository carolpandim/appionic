import { Component, NgModule, OnInit, ViewChild, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { DataTable, ConfirmationService } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppConfig } from '../../../general/app.configuration';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { MetodosTransportesProvider } from '../../../providers/metodosTransportes.provider';

@Component({
    selector: 'detail-metodo-transporte',
    templateUrl: './detail.component.html',
    providers: [MetodosTransportesProvider, ConfirmationService]
})
export class DetailComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();
    
    form: FormGroup;
    editData: any = {};

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private metodosTransportesProvider: MetodosTransportesProvider,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private confirmationService: ConfirmationService,
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            idMetodoTransporte: [''],
            nome: ['', Validators.required],
            codigoMetodoTransporte: ['', Validators.required],    
            sla: ['', Validators.required]                
        });
    }

    loadData(idMetodoTransporte: any)
    {        
        if(idMetodoTransporte)
        {
            this.metodosTransportesProvider.detail(idMetodoTransporte).subscribe((response) =>{
                if(response.success)
                {
                    this.editData = response.data;
                    this.form.patchValue(response.data);
                }
            });
        }
        else{
            this.editData = {};
            this.form.reset();
        }
    }   

    save()
    {
        if (this.form.valid) { 
            Object.assign(this.editData, this.form.value);

            this.metodosTransportesProvider.save(this.editData).subscribe((response) => {
                if (response.success) {          
                    this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
                }
                else {
                    this.saveEmitter.emit({ success: response.success, severity: 'error', detail: response.message });
                }
            });

        }
            else{
                this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }

    ngAfterViewChecked() {
    
    }
    

}

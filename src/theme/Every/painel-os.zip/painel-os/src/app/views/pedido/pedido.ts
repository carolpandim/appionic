export * from './index/index.component';
export * from './pedido.route';
export * from './pedido.module';
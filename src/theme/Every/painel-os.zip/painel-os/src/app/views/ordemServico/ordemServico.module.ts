import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule, TabViewModule, TooltipModule, KeyFilterModule, CheckboxModule, DropdownModule  } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IndexComponent } from './index/index.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';
import { TableModule } from 'primeng/table';
import { BsModalModule } from 'ng2-bs3-modal';
import { ItemsComponent } from './items/items.component';
import { DetailComponent } from './detail/detail.component';

@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule,
        TabViewModule,
        ConfirmDialogModule,
        CheckPermissionModule,
        TooltipModule,
        KeyFilterModule,
        MultiSelectModule,
        CalendarModule,
        CheckboxModule,
        TableModule,
        DropdownModule,
        BsModalModule
    ],
    declarations: [
        IndexComponent,
        ItemsComponent,
        DetailComponent
    ],
    exports: [
        IndexComponent,
        ItemsComponent,
        DetailComponent
    ]
})

export class OrdemServicoModule { }

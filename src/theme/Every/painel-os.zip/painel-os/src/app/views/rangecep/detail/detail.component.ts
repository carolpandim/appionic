import { Component, NgModule, OnInit, ViewChild, Input, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { DataTable, SelectItem, InputMaskModule } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { RangeCepProvider } from '../../../providers/rangeCep.provider';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonProvider } from '../../../providers/common.provider';

@Component({
    selector: 'rangecep-detail',
    templateUrl: './detail.component.html',
    providers: [RangeCepProvider, CommonProvider]
})
export class DetailComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    rangeCep: any = [];
    loadingItens: boolean = false;
    btAlter: boolean = false;
    form: FormGroup;
    msgBotao: String = "Incluir";
    tipe: string = ""; // I - Incluir , E - Excluir, A - Alterar.
    desabilitar: boolean = false;
    editData: any = {};

    entregas: SelectItem[] = [];
    metodos: SelectItem[] = [];

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private rangeCepProvider: RangeCepProvider,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private commonProvider: CommonProvider
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            idRangeCep: [''],
            cepInicio: ['', Validators.required],
            cepFim: ['', Validators.required],
            idTipoEntrega: ['', Validators.required],
            codigoMetodoTransporte: ['', Validators.required]
        });


        this.entregas.push({ label: "Selecione", value: "" });

        this.commonProvider.listTipoEntrega().subscribe((response) => {
            if (response.success && response.data) {
                response.data.map(o => {
                    this.entregas.push({ label: o.label, value: o.value });
                });
            }
        });

        this.metodos.push({ label: "Selecione", value: "" });
        this.commonProvider.listMetodoTransporte().subscribe((response) => {
            if (response.success && response.data) {
                response.data.map(o => {
                    this.metodos.push({ label: o.label, value: o.value });
                });                
            }
        });

     
    }


    ngAfterViewChecked() {
        //this.changeDetectorRef.detectChanges();
        
    }

    LoadData(idRangeCep: any) {

        this.btAlter = false;
        this.form.reset();
        this.desabilitar = false;
        if (this.saveEmitter.observers.length > 1) {
            this.saveEmitter.observers.pop();
        }
        if (idRangeCep) {
            this.rangeCepProvider.detail(idRangeCep).subscribe((response) => {
                if (response.success) {
                    this.editData = response.data
                    this.form.patchValue(response.data)
                }
            });
        }
    }

    Save() {
        if (this.form.valid) { 
            Object.assign(this.editData, this.form.value);

            this.rangeCepProvider.save(this.editData).subscribe((response) => {
                this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }
}


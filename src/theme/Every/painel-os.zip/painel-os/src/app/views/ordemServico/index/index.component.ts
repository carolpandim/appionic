import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef, ViewContainerRef, QueryList, ViewChildren } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { OrdemServicoProvider } from '../../../providers/ordemServico.provider';
import { ConfirmationService, ConfirmDialogModule, DialogModule, SelectItem } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { Table } from 'primeng/table';

declare var moment: any;

@Component({
  selector: 'app-ordemServico-index',
  templateUrl: './index.component.html',
  providers: [OrdemServicoProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];
  osStatus: SelectItem[] = [];

  @ViewChild('Table')
  table: Table;
  
  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;
  filterData: any = {};
  loading: boolean = false;


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private appComponent: AppComponent,
    private ordemServicoProvider: OrdemServicoProvider,
    private safePipe: SafePipe,
    private changeDetectorRef: ChangeDetectorRef,
    private notificationService: NotificationsService,
    private authenticationService: AuthenticationService,
    private confirmationService: ConfirmationService,
    private commonProvider: CommonProvider
  ) {
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
      this.form = this.formBuilder.group({
        idos: [''],
        idPedido: [''],
        dataInicio: [''],
        dataFim: [''],
        idStatus: ['']
    });

    this.commonProvider.listOsStatus().subscribe((response) => {
      if (response.success) {

        response.data.map((item) =>{
          this.osStatus.push({label: item.label, value: item.value});
        });

      }
    });    
  }

  ApplyFilter() {
    if (this.form.valid) {
      Object.assign(this.filterData, this.form.value);
      
      this.result = [];
      this.search({ first: 0 });
    }
    else {
      this.notificationService.error("Atenção", "Por favor, informe os campos obrigatórios!", { clickToClose: true });
    }
  }

  ClearForm() {
    this.form.reset();
    this.filterData = {};
    this.table.reset();
    this.search({});
    this.result.value = [];   
  }

  
  search(page: any = {}) {

    if (page.first >= 0) {
      this.page = (page.first /AppConfig.ResultPerPage) + 1;
    }
    else {
      this.page = 1;
    }

    this.result = [];
    this.loading = true;
    this.ordemServicoProvider.search(this.filterData, this.page, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        this.changeDetectorRef.detectChanges();
      }
      else
      {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
      this.loading = false;
    });
  }

  View(idOs: number){
    this.router.navigate(['/os/items/', idOs]);
  }

  Liberar(idOs: any) {

    this.confirmationService.confirm({
    message: 'Deseja Liberar a OS: ' + idOs + ' ?',
    header: 'Liberar OS!',
    key: "liberarDialog",
    accept: () => {
      this.loading = true;
      this.ordemServicoProvider.liberar(idOs).subscribe((response) => {
        if (response.success) {
          this.table.reset();
          this.search({});
          this.result.value = [];                  
          this.notificationService.success("", response.message, { clickToClose: true });
        }
        else {
          this.notificationService.error("Atenção", response.message, { clickToClose: true });
        }
        this.loading = false;
      });      
    },
    });
  }
}

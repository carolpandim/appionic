import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef, ViewChildren, QueryList } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PedidoProvider } from '../../../providers/pedido.provider';
import { DataTable, ConfirmationService, ConfirmDialogModule, DialogModule, SelectItem, Checkbox } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { BsModalComponent } from 'ng2-bs3-modal';
import { DetailComponent } from '../detail/detail.component';
import { RemoveComponent } from '../remove/remove.component';
import { TransporteComponent } from '../transporte/transporte.component';
import { Table } from 'primeng/table';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-pedido-index',
  templateUrl: './index.component.html',
  providers: [PedidoProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];
  produtos: SelectItem[] = [];
  metodos:SelectItem[] = [];

  @ViewChild('Table')
  table: Table;

  @ViewChild(DetailComponent)
  detailComponent: DetailComponent;

  @ViewChild('RemoveModal')
  removeModal: BsModalComponent;
  
  @ViewChild('EditTransportadorModal')
  editTransportadorModal: BsModalComponent;
  
  @ViewChild(RemoveComponent)
  removeComponent: RemoveComponent;
  
  @ViewChild(TransporteComponent)
  transporteComponent: TransporteComponent;  

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;
  filterData: any = {};
  loading: boolean = false;

  @ViewChild('checkedAll')
  checkedAll: Checkbox;

  ordersSelected: any[] = [];
  ordersFullSelected: any[] = [];

  @ViewChildren('OrdemServico')
  itemsCheckBox: QueryList<Checkbox>;

  temp: any[] = [];


  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private appComponent: AppComponent,
    private pedidoProvider: PedidoProvider,
    private safePipe: SafePipe,
    private changeDetectorRef: ChangeDetectorRef,
    private notificationService: NotificationsService,
    private authenticationService: AuthenticationService,
    private confirmationService: ConfirmationService,
    //private dialogModule: DialogModule
    private commonProvider: CommonProvider,
    private datePipe: DatePipe
  ) {

  }


  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      idPedido: [''],
      nomeCliente: [''],
      dataInicio: [''],
      dataFim: ['']
    });

    this.commonProvider.listOsType().subscribe((response) => {

      if (response.success) {
        response.data.map((item) => {
          this.produtos.push({ label: item.label, value: item.value });
        });
      }
    });

  }

  ApplyFilter() {
    Object.assign(this.filterData, this.form.value);

    this.table.reset();
    this.checkedAll.checked = false;
    this.temp.length = 0;
    this.ordersSelected.length = 0;
    this.ordersFullSelected.length = 0;
    this.totalRecords = 0;
    this.result.length = 0;
    this.firstPage = 0;
    this.search({ first: 0 });
    //this.authenticationService.setSearchCaixa(null);
  }

  ClearForm() {
    this.filterData = {};
    this.form.reset();
    this.table.reset();
    this.result.length = 0;
    this.checkedAll.checked = false;
    this.totalRecords = 0;
    this.temp.length = 0;
    this.ordersSelected.length = 0;
    this.ordersFullSelected.length = 0;
  }


  search(page: any = {}) {

    if (page.first >= 0) {
      this.page = (page.first / AppConfig.ResultPerPage) + 1;
    }
    else {
      this.page = 1;
    }

    this.result = [];

    if (this.checkedAll)
      this.checkedAll.checked = false;

    this.temp = [];
    if (this.ordersSelected) {
      this.ordersSelected.forEach((item) => {
        this.temp.push(item);
      });

    }

    if(this.filterData.dataInicio){
      this.filterData.dataInicio =  this.datePipe.transform(this.filterData.dataInicio,'yyyy-MM-dd');
    }
    if(this.filterData.dataFim){
      this.filterData.dataFim =  this.datePipe.transform(this.filterData.dataFim,'yyyy-MM-dd');
    }    

    this.loading = true;

    this.pedidoProvider.search(this.filterData, this.page, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        this.changeDetectorRef.detectChanges();
        
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
      this.loading = false;
    });

  }

  DialogLiberar() {
    if (this.ordersSelected.length > 0) {
      this.confirmationService.confirm({
        message: '<br> OS selecionadas: ' + this.ordersSelected.length + '<br> Deseja Liberar?',
        header: 'Liberar OS!',
        icon: "fa fa-download",
        key: "Liberar",
        accept: () => {
          this.GerarOs();
        },
      });
    }
    else {
      this.notificationService.info("Atenção", "Selecione ao menos um Pedido para Gerar OS!", { clickToClose: true });
    }
  }

  CheckedAll(event: any) {
    this.itemsCheckBox.map((item) => {
      item.checked = event;

      if (event) {
        if (this.ordersSelected.indexOf(item.value) < 0) {
          this.ordersSelected.push(item.value);
        }
      }
      else {
        let indexItem = this.ordersSelected.indexOf(item.value)

        this.ordersSelected.splice(indexItem, 1);
      }

    });
  }

  DeleteOrder(idOrder: any, idOrderItem: any) {
    this.removeComponent.saveEmitter.subscribe((response) => {
      this.removeModal.close();
      if (response.success) {
        this.notificationService.success("Parabéns", response.detail);
        this.search({});
      }
      else {
        this.notificationService.alert("Atenção", response.detail);
        this.search({});
      }

    });
    this.removeComponent.LoadData(idOrder, idOrderItem);
    this.removeModal.open('lg');
  }

  AlteraTransportadora(idOrder: any, idOrderItem: any) {
    this.transporteComponent.saveEmitter.subscribe((response) => {
      this.editTransportadorModal.close();
      if (response.success) {
        this.notificationService.success("Parabéns", response.detail);
        this.search({});
      }
      else {
        this.notificationService.alert("Atenção", response.detail);
        this.search({});
      }

    });
    this.transporteComponent.LoadData(idOrder, idOrderItem);
    this.editTransportadorModal.open('lg');
  }  

  GerarOs() {    
    if (this.ordersSelected.length > 0) {
      let data = { ids: this.ordersSelected };
      console.log(data);
      
      this.pedidoProvider.liberar(data).subscribe((response) => {
        if (response.success) {
          this.notificationService.success("Pedidos Liberados!", response.message, { clickToClose: true });
          this.ApplyFilter();
       }
        else {
          this.notificationService.error("Atenção", response.message, { clickToClose: true });
        }
      });
    }
    else {
      this.notificationService.error("Atenção", "Selecione ao menos 1 Pedido", { clickToClose: true });
    }

  }

  changeItem(event: any, itemValue: any) {    
    if (event) {
      if (this.ordersSelected.indexOf(itemValue) < 0) {
        this.ordersSelected.push(itemValue);
      }
    }
    else {
      let indexItem = this.ordersSelected.indexOf(itemValue)

      this.ordersSelected.splice(indexItem, 1);
    }
  }
}

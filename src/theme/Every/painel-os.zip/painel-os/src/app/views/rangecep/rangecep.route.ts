import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';

export const RangeCepRoutes: Routes = [
   { path: 'rangecep', component: IndexComponent, canActivate: [AuthenticationGuard] }
];
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule, TabViewModule, TooltipModule, KeyFilterModule, CheckboxModule, ToggleButtonModule, TriStateCheckboxModule } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IndexComponent } from './index/index.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { BsModalModule } from 'ng2-bs3-modal';
import { TableModule } from 'primeng/table';
import { DetailComponent } from './detail/detail.component';



@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule,
        TabViewModule,
        ConfirmDialogModule,
        CheckPermissionModule,
        TooltipModule,
        KeyFilterModule,
        BsModalModule,
        TableModule,
        CheckboxModule,
        ToggleButtonModule,
        TriStateCheckboxModule
    ],
    declarations: [
        IndexComponent,
        DetailComponent
    ],
    exports: [
        IndexComponent,
        DetailComponent
    ]
})

export class MetodosTransportesModule { }

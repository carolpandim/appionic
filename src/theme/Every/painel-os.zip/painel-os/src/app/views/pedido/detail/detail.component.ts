import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef, Input } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ConfirmationService, ConfirmDialogModule, DialogModule, SelectItem } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { PedidoProvider } from '../../../providers/pedido.provider';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { AppConfig } from '../../../general/app.configuration';
import { RemoveComponent } from '../remove/remove.component';
import { TransporteComponent } from '../transporte/transporte.component';

@Component({
  selector: 'detail-pedido',
  templateUrl: './detail.component.html',
  providers: [PedidoProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class DetailComponent implements OnInit {

  result: any = [];
  id: string;

  @ViewChild('Table')
  table: Table;
  
  @ViewChild('EditModal')
  editModal: BsModalComponent;

  @ViewChild('RemoveModal')
  removeModal: BsModalComponent;  

  @ViewChild('EditTransportadorModal')
  editTransportadorModal: BsModalComponent;  

  @ViewChild(RemoveComponent)
  removeComponent: RemoveComponent;  

  @ViewChild(TransporteComponent)
  transporteComponent: TransporteComponent;  

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;
  filterData: any = {};
  loading: boolean = false;


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private appComponent: AppComponent,
    private safePipe: SafePipe,
    private changeDetectorRef: ChangeDetectorRef,
    private notificationService: NotificationsService,
    private authenticationService: AuthenticationService,
    private confirmationService: ConfirmationService,
    private commonProvider: CommonProvider,
    private pedidoProvider: PedidoProvider
  ) {
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('idpedido');
    this.search({});
  }

  search(page: any = {}) {

    if (page.first >= 0) {
      this.page = (page.first / AppConfig.ResultPerPage) + 1;
    }
    else {
      this.page = 1;
    }
    this.result = [];
    this.loading = true;

    this.pedidoProvider.getPedidos(this.id, this.page, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
        this.changeDetectorRef.detectChanges();
        
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
      this.loading = false;
    });

  }  

  DeleteOrder(idOrder: any, idOrderItem: any) {
    this.removeComponent.saveEmitter.subscribe((response) => {
      this.removeModal.close();
      if (response.success) {
        this.notificationService.success("Parabéns", response.detail);
        this.search({});
      }
      else {
        this.notificationService.alert("Atenção", response.detail);
        this.search({});
      }

    });
    this.removeComponent.LoadData(idOrder, idOrderItem);
    this.removeModal.open('lg');
  }

  AlteraTransportadora(idOrder: any, idOrderItem: any) {
    this.transporteComponent.saveEmitter.subscribe((response) => {
      this.editTransportadorModal.close();
      if (response.success) {
        this.notificationService.success("Parabéns", response.detail);
        this.search({});
      }
      else {
        this.notificationService.alert("Atenção", response.detail);
        this.search({});
      }

    });
    this.transporteComponent.LoadData(idOrder, idOrderItem);
    this.editTransportadorModal.open('lg');
  }   

}

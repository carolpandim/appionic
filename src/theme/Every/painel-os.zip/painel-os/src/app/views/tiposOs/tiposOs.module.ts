import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule, TabViewModule, TooltipModule, KeyFilterModule, CheckboxModule, ToggleButtonModule, DropdownModule, TriStateCheckboxModule } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IndexComponent } from './index/index.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { BsModalModule } from 'ng2-bs3-modal';
import { ManutencaoTipoOsComponent } from './manutencao/manutencao-tiposOs'
import { ChannelTypeOs } from './channel/channel-typeOs'
import { TableModule } from 'primeng/table';


@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule,
        TabViewModule,
        ConfirmDialogModule,
        CheckPermissionModule,
        TooltipModule,
        KeyFilterModule,
        BsModalModule,
        TableModule,
        CheckboxModule,
        ToggleButtonModule,
        DropdownModule,
        TriStateCheckboxModule
    ],
    declarations: [
        IndexComponent,
        ManutencaoTipoOsComponent,
        ChannelTypeOs
    ],
    exports: [
        IndexComponent,
        ManutencaoTipoOsComponent,
        ChannelTypeOs
    ]
})

export class TiposOsModule { }

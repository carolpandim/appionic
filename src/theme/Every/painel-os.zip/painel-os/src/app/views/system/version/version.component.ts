import { Component, NgModule, OnInit, ViewChild } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { DataTable } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { AppConfig } from '../../../general/app.configuration';

@Component({
  selector: 'system-version',
  templateUrl: './version.component.html'
})
export class VersionComponent implements OnInit {

  constructor(
    private router: Router,
    private appComponent: AppComponent,
  ) {
  
  }

  ngOnInit() {
   
  }

}

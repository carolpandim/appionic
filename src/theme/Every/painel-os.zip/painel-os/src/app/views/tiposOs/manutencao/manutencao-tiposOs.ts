import { Component, NgModule, OnInit, ViewChild, Input, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { DataTable } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { OsTypeProvider } from '../../../providers/osType.provider';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'manutencao-tiposOs',
    templateUrl: './manutencao-tiposOs.html',
    providers: [OsTypeProvider]
})
export class ManutencaoTipoOsComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    osType: any = [];
    loadingItens: boolean = false;
    btAlter: boolean = false;
    form: FormGroup;
    msgBotao: String = "Incluir";
    tipe: string = ""; // I - Incluir , E - Excluir, A - Alterar.
    desabilitar: boolean = false;
    dataManut: any = {};

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private osTypeProvider: OsTypeProvider,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            idOsType: [''],
            template: ['', [Validators.required, Validators.maxLength(150)]],
            arquivo: ['', [Validators.required, Validators.maxLength(150)]],
            produto: ['', [Validators.required, Validators.maxLength(255)]],
            codigo: ['', [Validators.required, Validators.maxLength(50)]],
            ativo: [''],
            b2b: [''],
            preImpresso: ['']
        });
    }

    ngAfterViewChecked() {
        this.changeDetectorRef.detectChanges();
    }

    LoadData(idOsType: number) {        
        this.form.reset();
        if(idOsType)
        {
            this.osTypeProvider.selecionaTipoOs(idOsType).subscribe((response) => {
                if (response.success) {
                    this.dataManut = response.data;
                    this.form.patchValue(response.data);
                }
            });
        }
    }

    Salvar() {        
        if (this.form.valid) {
            Object.assign(this.dataManut, this.form.value);
            if(this.dataManut.ativo == null){this.dataManut.ativo = false} ;
            if(this.dataManut.b2b == null){this.dataManut.b2b = false} ;
            if(this.dataManut.preImpresso == null){this.dataManut.preImpresso = false} ;
                
            this.osTypeProvider.manutencao(this.dataManut).subscribe((response)=>{
            this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
            });
        }
        else {            
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }                
    }
}

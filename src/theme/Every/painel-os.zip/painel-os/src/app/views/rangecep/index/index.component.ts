import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PedidoProvider } from '../../../providers/pedido.provider';
import { ConfirmationService, ConfirmDialogModule, DialogModule, SelectItem } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { RangeCepProvider } from '../../../providers/rangeCep.provider';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { DetailComponent } from '../detail/detail.component';

declare var moment: any;

@Component({
  selector: 'app-rangecep-index',
  templateUrl: './index.component.html',
  providers: [PedidoProvider, CommonProvider, SafePipe, ConfirmationService,RangeCepProvider]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];
  entregas: SelectItem[] = [];
  metodos:SelectItem[] = [];

  @ViewChild('Table')
  table: Table;

  @ViewChild('RangeCepEditModal')
  rangeCepEditModal: BsModalComponent;

  @ViewChild(DetailComponent)
  detailComponent: DetailComponent;

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;  
  pageIndex: number = 1;
  totalRecord: number;
  filterData: any = {};
  checkedAll: boolean = false;
  manutOs:boolean = false;
  loading: boolean = false ;
  showDismiss: boolean = false;
  manutData: any[];
  

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private appComponent: AppComponent,
    private pedidoProvider: PedidoProvider,
    private safePipe: SafePipe,
    private notificationService: NotificationsService,
    private authenticationService: AuthenticationService,
    private confirmationService: ConfirmationService,
    private commonProvider: CommonProvider,
    private rangeCepProvider: RangeCepProvider,
    private changeDetectorRef: ChangeDetectorRef,
  ) {

  }

  ApplyFilter() {   
    Object.assign(this.filterData, this.form.value);      
    this.result = [];
    this.search({ first: 0 });
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      filtro: [''],
      cep: [''],
      tipoEntrega: [''],
      CodigoMetodoTransporte:['']
    });

    this.entregas.push({ label: "Selecione", value: "" });

    this.commonProvider.listTipoEntrega().subscribe((response) => {
      if (response.success && response.data) {
        response.data.map(o => {
          this.entregas.push({ label: o.label, value: o.value });
        });
      }
    });

    this.metodos.push({ label: "Selecione", value: "-1" });

    this.commonProvider.listMetodoTransporte().subscribe((response) => {
      if (response.success && response.data) {
        response.data.map(o => {
          this.metodos.push({ label: o.label, value: o.value });
        });
      }
    });

    this.metodos.push({ label: "Selecione", value: "" });
  }


  ClearForm(){
    this.filterData = {};
    this.form.reset();
  }

  search(page: any = {}) {
    this.loading = true;
    if (page.first > 1) {
      this.pageIndex = (page.first / AppConfig.ResultPerPage) + 1;
    }
    else {
      this.pageIndex = 1;
    }
    this.result = [];
   
    this.rangeCepProvider.list(this.filterData, this.pageIndex, AppConfig.ResultPerPage).subscribe((response) => {
      if (response.success) {          
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;        
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
    });
    this.loading = false;      
  }

  DialogRemover(id: any)
  {
   
    this.confirmationService.confirm({
      message: '<br> Deseja excluir o range de cep selecionado?',
      header: 'Excluir Range Cep!',
      icon: "fa fa-window-close-o",
      key: "desativar",
      accept: () => {
        this.Remover(id);
      },
    });
  }
  


  Edit(id: any = '')  
  {       
    this.detailComponent.saveEmitter.subscribe((response) =>{
      
      this.notificationService
      if (response.success) {     
        this.rangeCepEditModal.close();                                 
        this.notificationService.success("Parabéns", response.detail);   
      }
      else {       
        this.notificationService.error("Atenção", response.detail);                            
      }                            
      this.table.reset();
      this.search({});
    });
    
    this.detailComponent.LoadData(id)
    this.rangeCepEditModal.open()
  }

  Save(){
    this.detailComponent.Save();
  }
  
  Remover(id: any)
  {
    var dataPost = {};
    this.loading = true;

    this.rangeCepProvider.delete(id).subscribe((response) => {
        if (response.success) { 
          this.notificationService.success("Item excluído!",response.Message, { clickToClose: true });         
        }
        else {
          this.notificationService.error("Atenção", response.Message, { clickToClose: true });
        }
        this.loading = false;
        this.table.reset();     
        this.ApplyFilter();
    });
  }
}

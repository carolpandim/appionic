import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from '@angular/forms';
import { PedidoProvider } from '../../../providers/pedido.provider';
import { ConfirmationService, ConfirmDialogModule, SelectItem } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { TransportadoraProvider } from '../../../providers/transportadora.provider';
import { BsModalComponent } from 'ng2-bs3-modal';
import { Table } from 'primeng/table';
import { MetodosTransportesProvider } from '../../../providers/metodosTransportes.provider';
import { DetailComponent } from '../detail/detail.component';

@Component({
  selector: 'app-metodo-transportes-index',
  templateUrl: './index.component.html',  
  providers: [PedidoProvider,SafePipe,ConfirmationService,MetodosTransportesProvider]
})
export class IndexComponent implements OnInit {

  form: FormGroup;
  result: any = [];

  @ViewChild('DetailModal')
  detailModal: BsModalComponent;  
  @ViewChild(DetailComponent)
  detailComponent: DetailComponent;

  @ViewChild('Table')
  table: Table;

  firstPage: number = 0;
  totalRecords: number = 0;
  rows: number = 0;
  page: number = 1;  
  pageIndex: number = 1;
  totalRecord: number;
  filterData: any = {};
  loading: boolean = false ;
  showDismiss: boolean = false;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private appComponent: AppComponent,
    private pedidoProvider: PedidoProvider,
    private safePipe: SafePipe,
    private notificationService: NotificationsService,
    private authenticationService: AuthenticationService,
    private confirmationService: ConfirmationService,
    private metodosTransportesProvider: MetodosTransportesProvider,
    private changeDetectorRef: ChangeDetectorRef,
    
  ) {
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      nome: [''],
      codigoMetodoTransporte:['']
    });

    Object.assign(this.filterData, this.form.value);   
  }

  ApplyFilter() {   
      Object.assign(this.filterData, this.form.value);      
      this.result = [];
      this.search({ first: 0 });
  }

  ClearForm(){
    this.filterData = {};
    this.form.reset();
  }

  search(page: any = {}) {
    this.loading = true;
    if (page.first > 1) {
      this.pageIndex = (page.first / AppConfig.ResultPerPage) + 1;
    }
    else {
      this.pageIndex = 1;
    }
    this.result = [];
   
    this.metodosTransportesProvider.list(this.pageIndex, AppConfig.ResultPerPage,this.filterData).subscribe((response) => {
      if (response.success) {          
        this.result = response.data;
        this.rows = AppConfig.ResultPerPage;
        this.totalRecords = response.totalResultado;
      }
      else {
        this.notificationService.error("Atenção", response.Message, { clickToClose: true });
      }
    });
    this.loading = false;      
  }

  DialogRemover(id: any)
  {
   
    this.confirmationService.confirm({
      message: 'Deseja Remover o Método de Transporte?',
      header: 'Remover Método de Transporte!',
      key: "desativar",
      accept: () => {
        this.Remover(id);
      },
    });
  }

  Edit(idMetodoTransporte: any = '')
  {
    this.detailComponent.saveEmitter.subscribe((response) =>{
      if (response.success) {     
        this.detailModal.close();                                 
        this.notificationService.success("Parabéns", response.detail);   
      }
      else {       
        this.notificationService.error("Atenção", response.detail);                            
      }         

      this.table.reset();
      this.ApplyFilter();
    });

    this.detailComponent.loadData(idMetodoTransporte);
    this.detailModal.open('lg');
  }

  Save(){
    this.detailComponent.save();
  }

  
  Remover(id: any)
  {
    var dataPost = {};
    this.loading = true;

    this.metodosTransportesProvider.delete(id).subscribe((response) => {
        if (response.success) { 
          this.notificationService.success("Atenção",response.message, { clickToClose: true });         
        }
        else {
          this.notificationService.error("Atenção", response.message, { clickToClose: true });
        }
        this.table.reset();
        this.ApplyFilter();
        this.loading = false;
    });
  }

}

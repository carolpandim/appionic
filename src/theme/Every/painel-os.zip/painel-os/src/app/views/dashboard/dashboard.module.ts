import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { IndexComponent } from './index/index.component';
import { ChartModule,DataTableModule,SharedModule } from "primeng/primeng";


@NgModule({
    imports:      [
        BrowserModule,
        ChartModule,
        DataTableModule,
        SharedModule
    ],
    declarations: [
        IndexComponent
    ],
    exports: [
        IndexComponent
    ]
})

export class DashBoardModule { }

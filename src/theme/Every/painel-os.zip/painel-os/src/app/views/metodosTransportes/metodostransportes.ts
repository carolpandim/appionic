export * from './index/index.component';
export * from './metodostransportes.route';
export * from './metodostransportes.module';
import { Component, OnInit, ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router, ActivatedRoute } from "@angular/router";
import { SelectItem } from 'primeng/primeng';
import { NotificationsService } from 'angular2-notifications';
import { PedidoProvider } from '../../../providers/pedido.provider';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonProvider } from '../../../providers/common.provider';

@Component({
    selector: 'transporte-order',
    templateUrl: './transporte.component.html',
    providers: [PedidoProvider, CommonProvider]
})
export class TransporteComponent implements OnInit {

    @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    idOrderItem: any;
    idOrder: any;
    result: any;

    form: FormGroup;
    metodos: SelectItem[] = [];

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private pedidoProvider: PedidoProvider,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private formBuilder: FormBuilder,
        private commonProvider: CommonProvider
    ) {

    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            codigoMetodoTransporte: ['', Validators.required]
        });

        this.metodos.push({ label: "Selecione", value: "" });
        this.commonProvider.listMetodoTransporte().subscribe((response) => {
            if (response.success && response.data) {
                response.data.map(o => {
                    this.metodos.push({ label: o.label, value: o.value });
                });                
            }
        });     
    }

    ngAfterViewChecked() {
        //this.changeDetectorRef.detectChanges();
        
    }

    LoadData(idOrder: any, idOrderItem: any) {
        this.idOrder = idOrder;
        this.idOrderItem = idOrderItem;
    }

    Salvar() {
        
        if (this.form.valid) {
            var data = {IdPedido: this.idOrder, IdPedidoItem: this.idOrderItem, codigometodotransporte: this.form.controls["codigoMetodoTransporte"].value };
            console.log(data);
            this.pedidoProvider.alteraTransportadora(data).subscribe((response) => {

                if (response.success) {
                    this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
                }
                else {
                    this.saveEmitter.emit({ success: response.success, severity: 'alert', detail: response.message });
                }
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }
}


import { Component, NgModule, OnInit, ViewChild, ChangeDetectorRef, Input, EventEmitter, Output } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataTable, ConfirmationService, ConfirmDialogModule, DialogModule, SelectItem } from 'primeng/primeng';
import { DomSanitizer } from '@angular/platform-browser';
import { NotificationsService } from 'angular2-notifications';
import { SafePipe } from '../../../shared/util/SafePipe';
import { AppConfig } from '../../../general/app.configuration';
import { AuthenticationService } from '../../../general/service/authentication.service';
import { CommonProvider } from '../../../providers/common.provider';
import { PedidoProvider } from '../../../providers/pedido.provider';

declare var moment: any;

@Component({
    selector: 'remove-order',
    templateUrl: './remove.component.html',
    providers: [PedidoProvider, CommonProvider, SafePipe, ConfirmationService]
})
export class RemoveComponent implements OnInit {

      @Output()
    saveEmitter: EventEmitter<any> = new EventEmitter<any>();

    idOrderItem: any;
    idOrder: any;
    form: FormGroup;
    result: any;

    constructor(
        private router: Router,
        private formBuilder: FormBuilder,
        private appComponent: AppComponent,
        private safePipe: SafePipe,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationsService,
        private authenticationService: AuthenticationService,
        private confirmationService: ConfirmationService,
        private commonProvider: CommonProvider,
        private pedidoProvider: PedidoProvider
    ) {
    }

    ngAfterViewChecked() {
        this.changeDetectorRef.detectChanges();
    }

    ngOnInit() {

        this.form = this.formBuilder.group({
            description: ['', Validators.required]
        });
    }


    LoadData(idOrder: any, idOrderItem: any) {
        this.idOrder = idOrder;
        this.idOrderItem = idOrderItem;
    }

    Salvar() {
        if (this.form.valid) {
            var data = {IdPedido: this.idOrder, IdPedidoItem: this.idOrderItem, Description: this.form.controls["description"].value };

            this.pedidoProvider.delete(data).subscribe((response) => {

                if (response.success) {
                    this.saveEmitter.emit({ success: response.success, severity: 'success', detail: response.message });
                }
                else {
                    this.saveEmitter.emit({ success: response.success, severity: 'alert', detail: response.message });
                }
            });
        }
        else {
            this.notificationService.alert("Atenção", "Por favor, preencher todos os campos!");
        }
    }

}

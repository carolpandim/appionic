import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { VersionComponent } from './version/version.component';

export const SystemRoutes: Routes = [
   { path: 'system/version', component: VersionComponent, canActivate: [AuthenticationGuard] }
];

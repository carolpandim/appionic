import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule,SharedModule, DialogModule, TabViewModule, TooltipModule, KeyFilterModule, CheckboxModule, DropdownModule  } from "primeng/primeng";
import { RouterModule } from '@angular/router';
import { InputMaskModule } from 'primeng/components/inputmask/inputmask';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { IndexComponent } from './index/index.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { MultiSelectModule } from 'primeng/multiselect';
import { CalendarModule } from 'primeng/calendar';
import {TableModule} from 'primeng/table';
import { DetailComponent } from './detail/detail.component';
import { BsModalModule } from 'ng2-bs3-modal';
import { RemoveComponent } from './remove/remove.component';
import { TransporteComponent } from './transporte/transporte.component';

@NgModule({
    imports:      [
        RouterModule,
        BrowserModule,
        FormsModule,
        DialogModule,
        ReactiveFormsModule,
        InputMaskModule,        
        DataTableModule,
        SharedModule,
        TabViewModule,
        ConfirmDialogModule,
        CheckPermissionModule,
        BsModalModule,
        TooltipModule,
        KeyFilterModule,
        MultiSelectModule,
        CalendarModule,
        CheckboxModule,
        DropdownModule,
        TableModule
    ],
    declarations: [
        IndexComponent,
        DetailComponent,
        RemoveComponent,
        TransporteComponent
    ],
    exports: [
        IndexComponent,
        DetailComponent,
        RemoveComponent,
        TransporteComponent
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})

export class PedidoModule { }

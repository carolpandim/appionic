import { Component, NgModule, OnInit, ViewChild } from '@angular/core';
import { AppComponent } from "../../../app.component";
import { Router } from "@angular/router";
import {ChartModule} from 'primeng/primeng';

declare var theme: {
    init() : void
    clean() : void
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './index.component.html',
    providers: []  
})
export class IndexComponent  implements OnInit {

  constructor(
        private router: Router,
        private appComponent: AppComponent
    ) { 

    }

 ngOnInit() {    
  }    
}

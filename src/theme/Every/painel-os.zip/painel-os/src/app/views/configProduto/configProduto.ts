export * from './index/index.component';
export * from './configProduto.route';
export * from './configProduto.module';
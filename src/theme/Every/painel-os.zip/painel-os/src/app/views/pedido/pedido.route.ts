import { Routes } from '@angular/router';

import { AuthenticationGuard } from '../../general/authentication/authentication.guard';
import { IndexComponent } from './index/index.component';
import { DetailComponent } from './detail/detail.component';

export const PedidoRoutes: Routes = [
   { path: 'pedido', component: IndexComponent, canActivate: [AuthenticationGuard] },
   { path: 'pedido/pedidoItens/:idpedido', component: DetailComponent, canActivate: [AuthenticationGuard] }
];

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { SideBarComponent } from './sidebar.component';
import { CheckPermissionModule } from '../../general/authentication/check-permission.module';
import { CheckPermissionDirective } from '../../general/authentication/check-permission.directive';

@NgModule({
    imports: [
        BrowserModule,
        RouterModule,
        CheckPermissionModule
    ],
    declarations: [
        SideBarComponent
    ],
    exports: [
        SideBarComponent
    ]
})

export class SideBarModule { }

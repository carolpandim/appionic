import { DomSanitizer} from '@angular/platform-browser';
import { Injectable } from '@angular/core';

@Injectable()
export class SafePipe {
  constructor(private sanitizer: DomSanitizer) {}
  transform(url) {
    if(url)
    {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
    else{
      return "#";
    }
  }
} 
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { NavBarComponent } from './navbar.component';


@NgModule({
    imports: [
        BrowserModule,      
        RouterModule
    ],
    declarations: [
        NavBarComponent
    ],
    exports: [
        NavBarComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]   
})

export class NavBarModule { }

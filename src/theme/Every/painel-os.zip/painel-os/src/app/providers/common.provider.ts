import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class CommonProvider {

    user: UserModel;

    controllerName: String = "common";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }

    
    listOsType(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-os-type`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }  

    listProduct(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-product`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    listTipoEntrega(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-tipo-entrega`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }  
    
    listOsStatus(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-os-status`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }        
    listTransportador(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-transportador`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }  

    listMetodoTransporte(): Observable<any> {
        return this.httpService.get(`${this.controllerName}/list-metodo-transporte`,{})
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }      
}

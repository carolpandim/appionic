import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class MetodosTransportesProvider {

    user: UserModel;

    controllerName: String = "MetodosTransportes";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }

    list(pageindex:number, pagesize:number,data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/list/${pageindex}/${pagesize}/`,data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    detail(id: any): Observable<any> {
        return this.httpService.get(`${this.controllerName}/detail/${id}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }

    save(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/save`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }

    delete(id: any): Observable<any> {
        return this.httpService.delete(`${this.controllerName}/delete/${id}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    
}

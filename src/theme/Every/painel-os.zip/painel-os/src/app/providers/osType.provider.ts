import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class OsTypeProvider {

    user: UserModel;

    controllerName: String = "OsType";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }

    list(data:any, pageindex:number, pagesize:number): Observable<any> {
        return this.httpService.post(`${this.controllerName}/list/${pageindex}/${pagesize}`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    liberar(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/unLockContract`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }        

    selecionaTipoOs(idostype: any): Observable<any> {
        return this.httpService.get(`${this.controllerName}/detail/${idostype}`)
            .map((response) => {                
                return response as CustomResult<Array<any>>;
            });
            
    } 

    manutencao(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/save`, data)
            .map((response) => {                
                return response as CustomResult<Array<any>>;
            });
            
    } 
    
    remover(idOstype: any): Observable<any> {
        return this.httpService.delete(`${this.controllerName}/delete/${idOstype}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }        

}

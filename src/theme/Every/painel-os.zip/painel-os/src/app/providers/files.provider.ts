import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from '../general/service/authentication.service';
import { HttpService } from '../general/service/http.service';



@Injectable()
export class FilesProvider {

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         

    }

    listPermission(): Observable<any> {
        return this.httpService.file(`../assets/data/permission.json`);
    }  
 
}
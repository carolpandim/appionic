import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from "../general/service/authentication.service";
import { HttpService } from "../general/service/http.service";
import { UserModel } from "../models/user.model";
import { CustomResult } from '../models/customresult';

@Injectable()
export class PedidoProvider {

    user: UserModel;

    controllerName: String = "order";

    constructor(
        private httpService: HttpService,
        private authenticationService: AuthenticationService
    ) {         
    }

    search(data: any, pageIndex: number, pageSize: number): Observable<any> {
        return this.httpService.post(`${this.controllerName}/search/${pageIndex}/${pageSize}`,data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    

    getPedidos(idpedido: string, pageIndex: number, pageSize: number): Observable<any> {
        return this.httpService.get(`${this.controllerName}/get/${idpedido}/${pageIndex}/${pageSize}`)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }

    liberar(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/save`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }    
    
    delete(data: any): Observable<any> {
        return this.httpService.delete(`${this.controllerName}/delete`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }  

    alteraTransportadora(data: any): Observable<any> {
        return this.httpService.post(`${this.controllerName}/alteraTransportadora`, data)
            .map((response) => {
                return response as CustomResult<Array<any>>;
            });
    }      
}

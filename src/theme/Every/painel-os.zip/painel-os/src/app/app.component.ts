import { Component, ElementRef, HostBinding, OnInit  } from '@angular/core';
import { Router, NavigationEnd  } from "@angular/router";
import{ AuthenticationService} from "./general/service/authentication.service";
import { EmitterProvider } from "./general/emitter/emitter.provider";
import { SlimLoadingBarService } from "ng2-slim-loading-bar";
import { EmitterType } from "./general/emitter/emitter.type";

declare var $: any;

@Component({
  selector: 'body',
  templateUrl: './app.component.html',
  providers: [ ]
})
export class AppComponent implements OnInit {
    @HostBinding('class') public cssClass = 'login';

    //Option do SimpleNotification
    public simpleNotificationsOptions = { timeOut: 4000, showProgressBar: true, pauseOnHover: false, clickToClose: true, preventDuplicates: true}
    loadingCount: number = 0;

   constructor(
        private _elementRef: ElementRef,
        private emitter: EmitterProvider,
        private router: Router,
        private slimLoadingBarService: SlimLoadingBarService,
        private authenticationService : AuthenticationService
        ) {

        if (this.authenticationService.isAuthenticated) {
            this.ConfigPanel();
        }

        setTimeout(() => {
            $.MoltranApp.init();
        }, 100);
        
        this.notificationCenter();
    }

    ngOnInit() {
        this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                return;
            }
            window.scrollTo(0, 0)
        });
    }    

    notificationCenter() {
        this.emitter.base.subscribe((data) => {
            switch (data) {
                case EmitterType.LOADING_BEGIN: {
                    if (this.loadingCount == 0) {
                        this.slimLoadingBarService.start(() => {
                            //console.log('Loading complete');
                        });
                    }
                    this.loadingCount += 1;
                }
                break;
                case EmitterType.LOADING_END: {
                    this.loadingCount -= 1;
                    if (this.loadingCount == 0) {
                        this.slimLoadingBarService.complete();
                    }
                }
                break;
                case EmitterType.USER_SIGN_OUT: {
                    this.authenticationService.clearSession();
                    this.ConfigPanel();
                    this.router.navigate(['/']);
                }
            }
        });
    }
    
    ConfigPanel() {

       this.cssClass = this.authenticationService.isAuthenticated ? "fixed-left" : "";
    }


    get userLogged(): Boolean {
        return this.authenticationService.isAuthenticated;
    }
}
